# RetailOS — Full-Stack POS & Inventory Management

## Project Structure

```
retailos/
├── render.yaml              ← Render Blueprint (deploy both at once)
├── backend/                 ← Express / MongoDB REST API
└── frontend/                ← React 18 SPA
```

---

## 🚀 Deploy on Render

### Option A — Blueprint (recommended)

1. Push this folder to a GitHub/GitLab repo.
2. **Render Dashboard → New → Blueprint** → connect repo.
3. Render detects `render.yaml` and creates both services.
4. Set env vars below → **Apply**.

---

### Option B — Manual (two services)

#### 1. MongoDB Atlas
- Create free cluster at cloud.mongodb.com
- Add DB user, whitelist `0.0.0.0/0`
- Copy URI: `mongodb+srv://user:pass@cluster.mongodb.net/retailos`

#### 2. Backend Web Service
- Root Dir: `backend`
- Build: `npm install`
- Start: `node server.js`
- Health check: `/health`

**Environment Variables:**

| Key | Value |
|---|---|
| NODE_ENV | production |
| PORT | 5000 |
| MONGO_URI | your Atlas URI |
| JWT_SECRET | run: `openssl rand -hex 32` |
| JWT_EXPIRES_IN | 15m |
| JWT_REFRESH_SECRET | run: `openssl rand -hex 32` |
| JWT_REFRESH_EXPIRES_IN | 7d |
| CLIENT_URL | your frontend Render URL |

#### 3. Frontend Web Service
- Root Dir: `frontend`
- Build: `npm install && npm run build`
- Start: `npx serve -s build -l 3000`

**Environment Variables:**

| Key | Value |
|---|---|
| REACT_APP_API_URL | https://your-backend.onrender.com/api |

#### 4. Seed Data (first time only)
In Render backend → Shell tab:
```
node src/config/seed.js
```

---

## Default Credentials (after seed)

| Role    | Email              | Password      |
|---------|--------------------|---------------|
| Admin   | admin@pos.com      | Admin@1234    |
| Manager | manager@pos.com    | Manager@1234  |
| Cashier | cashier@pos.com    | Cashier@1234  |

---

## Local Development

```bash
# Backend
cd backend && cp .env.example .env
npm install && npm run seed && npm run dev
# → http://localhost:5000

# Frontend
cd frontend && cp .env.example .env
# set REACT_APP_API_URL=http://localhost:5000/api
npm install && npm start
# → http://localhost:3000
```

---

## Tech Stack
- **Backend**: Node.js 18, Express 4, MongoDB/Mongoose 8, JWT, bcrypt, Joi, Winston
- **Frontend**: React 18, React Router 6, Axios, Recharts
- **Security**: Helmet, CORS, rate-limit, mongo-sanitize, HttpOnly cookies
- **Hosting**: Render + MongoDB Atlas
