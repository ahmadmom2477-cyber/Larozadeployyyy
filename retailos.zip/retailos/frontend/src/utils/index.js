export const fmt = {
  currency: (n) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(n ?? 0),
  number:   (n) => new Intl.NumberFormat('en-US').format(n ?? 0),
  date:     (d) => new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
  dateTime: (d) => new Date(d).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
  percent:  (n) => `${Number(n ?? 0).toFixed(1)}%`,
};

export const statusBadge = (status) => {
  const map = {
    completed:          'badge-green',
    refunded:           'badge-blue',
    partially_refunded: 'badge-amber',
    voided:             'badge-red',
    on_hold:            'badge-neutral',
    pending:            'badge-amber',
    approved:           'badge-green',
    rejected:           'badge-red',
    refund_issued:      'badge-blue',
    active:             'badge-green',
    inactive:           'badge-red',
  };
  return map[status] || 'badge-neutral';
};

export const errMsg = (err) =>
  err?.response?.data?.message || err?.message || 'Something went wrong.';
