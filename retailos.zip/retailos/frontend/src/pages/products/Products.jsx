import React, { useState, useEffect, useCallback } from 'react';
import AppLayout from '../../components/layout/AppLayout';
import { DataTable, Pagination, SearchInput, Modal, Spinner, Badge, FormField } from '../../components/shared';
import { productsApi } from '../../api';
import { fmt, errMsg } from '../../utils';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';
import { useDebounce } from '../../hooks';

const EMPTY_FORM = {
  name:'', sku:'', barcode:'', description:'',
  categoryId:'', costPrice:'', sellingPrice:'', taxRate:'0',
  unit:'piece', totalStock:'0', reorderPoint:'10', isActive:true,
};

const UNITS = ['piece','kg','gram','liter','ml','box','pack','dozen','meter','other'];

function ProductForm({ form, onChange, onSubmit, loading, isEdit }) {
  return (
    <div>
      <div className="grid-2">
        <FormField label="Product Name" required>
          <input className="form-input" value={form.name} onChange={e => onChange('name', e.target.value)} placeholder="e.g. USB-C Hub" />
        </FormField>
        <FormField label="SKU" required>
          <input className="form-input" value={form.sku} onChange={e => onChange('sku', e.target.value.toUpperCase())} placeholder="e.g. EL-001" />
        </FormField>
      </div>
      <div className="grid-2">
        <FormField label="Cost Price ($)" required>
          <input className="form-input" type="number" min="0" step="0.01" value={form.costPrice} onChange={e => onChange('costPrice', e.target.value)} placeholder="0.00" />
        </FormField>
        <FormField label="Selling Price ($)" required>
          <input className="form-input" type="number" min="0" step="0.01" value={form.sellingPrice} onChange={e => onChange('sellingPrice', e.target.value)} placeholder="0.00" />
        </FormField>
      </div>
      <div className="grid-2">
        <FormField label="Tax Rate (%)" hint="Applied to subtotal after discounts.">
          <input className="form-input" type="number" min="0" max="100" value={form.taxRate} onChange={e => onChange('taxRate', e.target.value)} />
        </FormField>
        <FormField label="Unit">
          <select className="form-select" value={form.unit} onChange={e => onChange('unit', e.target.value)}>
            {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
          </select>
        </FormField>
      </div>
      <div className="grid-2">
        <FormField label="Category ID" hint="MongoDB ObjectId of the category.">
          <input className="form-input" value={form.categoryId} onChange={e => onChange('categoryId', e.target.value)} placeholder="64abc..." />
        </FormField>
        <FormField label="Barcode">
          <input className="form-input" value={form.barcode} onChange={e => onChange('barcode', e.target.value)} placeholder="EAN / UPC" />
        </FormField>
      </div>
      {!isEdit && (
        <div className="grid-2">
          <FormField label="Opening Stock">
            <input className="form-input" type="number" min="0" value={form.totalStock} onChange={e => onChange('totalStock', e.target.value)} />
          </FormField>
          <FormField label="Reorder Point">
            <input className="form-input" type="number" min="0" value={form.reorderPoint} onChange={e => onChange('reorderPoint', e.target.value)} />
          </FormField>
        </div>
      )}
      <FormField label="Description">
        <textarea className="form-input" rows={2} value={form.description} onChange={e => onChange('description', e.target.value)} placeholder="Optional product description" style={{ resize:'vertical' }} />
      </FormField>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:20 }}>
        <input type="checkbox" id="isActive" checked={form.isActive} onChange={e => onChange('isActive', e.target.checked)} />
        <label htmlFor="isActive" style={{ fontSize:13, color:'var(--text-secondary)' }}>Active (visible in POS)</label>
      </div>
      <div className="flex justify-end gap-2">
        <button className="btn btn-primary" onClick={onSubmit} disabled={loading}>
          {loading ? <Spinner size={14} /> : isEdit ? 'Save Changes' : 'Create Product'}
        </button>
      </div>
    </div>
  );
}

export default function Products() {
  const [products, setProducts] = useState([]);
  const [total, setTotal]       = useState(0);
  const [page, setPage]         = useState(1);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState('');
  const [formLoading, setFormLoading] = useState(false);
  const [modalOpen, setModalOpen]     = useState(false);
  const [editTarget, setEditTarget]   = useState(null);
  const [form, setForm]               = useState(EMPTY_FORM);
  const LIMIT = 20;

  const { toast }   = useToast();
  const { hasRole } = useAuth();
  const dSearch = useDebounce(search, 400);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: LIMIT };
      if (dSearch) params.search = dSearch;
      const res = await productsApi.list(params);
      setProducts(res.data.data || []);
      setTotal(res.data.pagination?.total || 0);
    } catch { toast('Failed to load products.', 'error'); }
    finally { setLoading(false); }
  }, [page, dSearch, toast]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [dSearch]);

  const openCreate = () => { setForm(EMPTY_FORM); setEditTarget(null); setModalOpen(true); };
  const openEdit   = (p) => {
    setForm({
      name: p.name, sku: p.sku, barcode: p.barcode || '',
      description: p.description || '',
      categoryId: p.categoryId?._id || p.categoryId || '',
      costPrice: p.costPrice, sellingPrice: p.sellingPrice,
      taxRate: p.taxRate || 0, unit: p.unit || 'piece',
      totalStock: p.totalStock, reorderPoint: p.reorderPoint,
      isActive: p.isActive,
    });
    setEditTarget(p);
    setModalOpen(true);
  };

  const fieldChange = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async () => {
    const { name, sku, costPrice, sellingPrice, categoryId } = form;
    if (!name || !sku || !costPrice || !sellingPrice || !categoryId) {
      return toast('Please fill all required fields.', 'error');
    }
    setFormLoading(true);
    try {
      const payload = {
        ...form,
        costPrice:    parseFloat(form.costPrice),
        sellingPrice: parseFloat(form.sellingPrice),
        taxRate:      parseFloat(form.taxRate),
        totalStock:   parseInt(form.totalStock),
        reorderPoint: parseInt(form.reorderPoint),
      };
      if (editTarget) await productsApi.update(editTarget._id, payload);
      else            await productsApi.create(payload);
      toast(editTarget ? 'Product updated.' : 'Product created.', 'success');
      setModalOpen(false);
      load();
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setFormLoading(false); }
  };

  const columns = [
    { key:'name',  label:'Product', render: p => (
        <div>
          <div style={{ fontWeight:600 }}>{p.name}</div>
          <div className="td-mono" style={{ color:'var(--text-muted)', fontSize:11 }}>{p.sku}</div>
        </div>
      )},
    { key:'category', label:'Category', render: p => p.categoryId?.name || '—' },
    { key:'sellingPrice', label:'Price', render: p => <span className="td-mono">{fmt.currency(p.sellingPrice)}</span> },
    { key:'costPrice', label:'Cost', render: p => <span className="td-mono text-muted">{fmt.currency(p.costPrice)}</span> },
    { key:'totalStock', label:'Stock', render: p => (
        <span style={{ fontFamily:'var(--font-mono)', fontWeight:700, color: p.totalStock <= p.reorderPoint ? 'var(--red)' : 'var(--green)' }}>
          {p.totalStock}
        </span>
      )},
    { key:'taxRate', label:'Tax', render: p => <span className="td-mono">{p.taxRate}%</span> },
    { key:'isActive', label:'Status', render: p => <Badge status={p.isActive ? 'active' : 'inactive'} label={p.isActive ? 'Active' : 'Inactive'} /> },
    { key:'actions', label:'', render: p => (
        <div className="flex gap-2" style={{ justifyContent:'flex-end' }}>
          {hasRole('admin','manager') && (
            <button className="btn btn-ghost btn-sm" onClick={() => openEdit(p)}>Edit</button>
          )}
        </div>
      )},
  ];

  return (
    <AppLayout
      title="Products"
      actions={
        <div className="flex items-center gap-3">
          <SearchInput value={search} onChange={setSearch} placeholder="Search products…" />
          {hasRole('admin','manager') && (
            <button className="btn btn-primary" onClick={openCreate}>+ Add Product</button>
          )}
        </div>
      }
    >
      <DataTable columns={columns} data={products} loading={loading} emptyMessage="No products found." />
      <Pagination
        page={page} pages={Math.ceil(total / LIMIT)}
        total={total} limit={LIMIT} onPage={setPage}
      />

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editTarget ? 'Edit Product' : 'New Product'}
        size="modal-lg"
      >
        <ProductForm form={form} onChange={fieldChange} onSubmit={handleSubmit} loading={formLoading} isEdit={!!editTarget} />
      </Modal>
    </AppLayout>
  );
}
