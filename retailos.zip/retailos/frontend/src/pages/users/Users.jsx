import React, { useState, useEffect, useCallback } from 'react';
import AppLayout from '../../components/layout/AppLayout';
import { DataTable, Pagination, Modal, Badge, Spinner, FormField, ConfirmModal } from '../../components/shared';
import { usersApi } from '../../api';
import { fmt, errMsg } from '../../utils';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';

const EMPTY_FORM = { name:'', email:'', password:'', role:'cashier', isActive:true };

export default function Users() {
  const [users, setUsers]         = useState([]);
  const [total, setTotal]         = useState(0);
  const [page, setPage]           = useState(1);
  const [loading, setLoading]     = useState(true);
  const [formOpen, setFormOpen]   = useState(false);
  const [form, setForm]           = useState(EMPTY_FORM);
  const [formLoading, setFormLoading] = useState(false);
  const [editTarget, setEditTarget]   = useState(null);
  const [resetTarget, setResetTarget] = useState(null);
  const [newPwd, setNewPwd]           = useState('');
  const [resetLoading, setResetLoading] = useState(false);
  const [deactivateTarget, setDeactivateTarget] = useState(null);
  const [deactivateLoading, setDeactivateLoading] = useState(false);
  const LIMIT = 20;

  const { toast } = useToast();
  const { user: me } = useAuth();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await usersApi.list({ page, limit: LIMIT });
      setUsers(res.data.data || []);
      setTotal(res.data.pagination?.total || 0);
    } catch { toast('Failed to load users.', 'error'); }
    finally { setLoading(false); }
  }, [page, toast]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => { setForm(EMPTY_FORM); setEditTarget(null); setFormOpen(true); };
  const openEdit   = (u) => {
    setForm({ name: u.name, email: u.email, password:'', role: u.role, isActive: u.isActive });
    setEditTarget(u);
    setFormOpen(true);
  };

  const fieldChange = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async () => {
    const { name, email, password, role } = form;
    if (!name || !email || (!editTarget && !password)) return toast('Fill all required fields.', 'error');
    setFormLoading(true);
    try {
      if (editTarget) await usersApi.update(editTarget._id, { name, role, isActive: form.isActive });
      else            await usersApi.create({ name, email, password, role });
      toast(editTarget ? 'User updated.' : 'User created.', 'success');
      setFormOpen(false);
      load();
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setFormLoading(false); }
  };

  const handleReset = async () => {
    if (newPwd.length < 8) return toast('Password must be at least 8 characters.', 'error');
    setResetLoading(true);
    try {
      await usersApi.resetPassword(resetTarget._id, newPwd);
      toast(`Password reset for ${resetTarget.name}.`, 'success');
      setResetTarget(null); setNewPwd('');
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setResetLoading(false); }
  };

  const handleDeactivate = async () => {
    setDeactivateLoading(true);
    try {
      await usersApi.deactivate(deactivateTarget._id);
      toast(`${deactivateTarget.name} deactivated.`, 'success');
      setDeactivateTarget(null);
      load();
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setDeactivateLoading(false); }
  };

  const roleBadgeClass = { admin:'badge-red', manager:'badge-blue', cashier:'badge-green' };

  const columns = [
    { key:'name', label:'Name', render: u => (
        <div>
          <div style={{ fontWeight:600 }}>{u.name}</div>
          <div style={{ fontSize:12, color:'var(--text-muted)' }}>{u.email}</div>
        </div>
      )},
    { key:'role', label:'Role', render: u => <span className={`badge ${roleBadgeClass[u.role] || 'badge-neutral'}`}>{u.role}</span> },
    { key:'isActive', label:'Status', render: u => <Badge status={u.isActive ? 'active' : 'inactive'} label={u.isActive ? 'Active' : 'Inactive'} /> },
    { key:'lastLogin', label:'Last Login', render: u => <span style={{ color:'var(--text-muted)', fontSize:12 }}>{u.lastLogin ? fmt.dateTime(u.lastLogin) : 'Never'}</span> },
    { key:'created', label:'Created', render: u => <span style={{ color:'var(--text-muted)', fontSize:12 }}>{fmt.date(u.createdAt)}</span> },
    { key:'actions', label:'', render: u => (
        <div className="flex gap-2" style={{ justifyContent:'flex-end' }}>
          <button className="btn btn-ghost btn-sm" onClick={() => openEdit(u)}>Edit</button>
          <button className="btn btn-ghost btn-sm" onClick={() => { setResetTarget(u); setNewPwd(''); }}>Reset Pwd</button>
          {u._id !== me?._id && u.isActive && (
            <button className="btn btn-sm" style={{ background:'var(--red-dim)', color:'var(--red)', border:'1px solid rgba(239,68,68,0.2)' }} onClick={() => setDeactivateTarget(u)}>
              Deactivate
            </button>
          )}
        </div>
      )},
  ];

  return (
    <AppLayout title="User Management" actions={<button className="btn btn-primary" onClick={openCreate}>+ Add User</button>}>
      <DataTable columns={columns} data={users} loading={loading} emptyMessage="No users found." />
      <Pagination page={page} pages={Math.ceil(total / LIMIT)} total={total} limit={LIMIT} onPage={setPage} />

      {/* Create / Edit Modal */}
      <Modal open={formOpen} onClose={() => setFormOpen(false)} title={editTarget ? 'Edit User' : 'New User'} size="modal-md">
        <FormField label="Full Name" required>
          <input className="form-input" value={form.name} onChange={e => fieldChange('name', e.target.value)} placeholder="Jane Smith" />
        </FormField>
        <FormField label="Email" required>
          <input className="form-input" type="email" value={form.email} onChange={e => fieldChange('email', e.target.value)} placeholder="jane@store.com" disabled={!!editTarget} />
        </FormField>
        {!editTarget && (
          <FormField label="Password" required hint="Min 8 chars, must contain uppercase, lowercase, and number.">
            <input className="form-input" type="password" value={form.password} onChange={e => fieldChange('password', e.target.value)} placeholder="••••••••" />
          </FormField>
        )}
        <FormField label="Role">
          <select className="form-select" value={form.role} onChange={e => fieldChange('role', e.target.value)}>
            <option value="cashier">Cashier</option>
            <option value="manager">Manager</option>
            <option value="admin">Admin</option>
          </select>
        </FormField>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:20 }}>
          <input type="checkbox" id="isActive" checked={form.isActive} onChange={e => fieldChange('isActive', e.target.checked)} />
          <label htmlFor="isActive" style={{ fontSize:13, color:'var(--text-secondary)' }}>Account Active</label>
        </div>
        <div className="flex justify-end gap-2">
          <button className="btn btn-ghost" onClick={() => setFormOpen(false)}>Cancel</button>
          <button className="btn btn-primary" onClick={handleSubmit} disabled={formLoading}>
            {formLoading ? <Spinner size={14} /> : editTarget ? 'Save Changes' : 'Create User'}
          </button>
        </div>
      </Modal>

      {/* Reset Password Modal */}
      <Modal open={!!resetTarget} onClose={() => { setResetTarget(null); setNewPwd(''); }} title={`Reset Password — ${resetTarget?.name}`} size="modal-sm">
        <FormField label="New Password" required hint="Min 8 chars, uppercase, lowercase, number.">
          <input className="form-input" type="password" value={newPwd} onChange={e => setNewPwd(e.target.value)} placeholder="••••••••" autoFocus />
        </FormField>
        <div className="flex justify-end gap-2">
          <button className="btn btn-ghost" onClick={() => { setResetTarget(null); setNewPwd(''); }}>Cancel</button>
          <button className="btn btn-primary" onClick={handleReset} disabled={resetLoading}>
            {resetLoading ? <Spinner size={14} /> : 'Reset Password'}
          </button>
        </div>
      </Modal>

      {/* Deactivate Confirm */}
      <ConfirmModal
        open={!!deactivateTarget}
        onClose={() => setDeactivateTarget(null)}
        onConfirm={handleDeactivate}
        title="Deactivate User"
        message={`Are you sure you want to deactivate ${deactivateTarget?.name}? They will immediately lose access.`}
        confirmLabel="Deactivate"
        danger
        loading={deactivateLoading}
      />
    </AppLayout>
  );
}
