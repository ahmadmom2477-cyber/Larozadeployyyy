import React, { useState, useEffect, useCallback } from 'react';
import AppLayout from '../../components/layout/AppLayout';
import { DataTable, Pagination, Modal, Badge, Spinner, FormField } from '../../components/shared';
import { exchangesApi, salesApi, cashierApi } from '../../api';
import { fmt, errMsg } from '../../utils';
import { useToast } from '../../context/ToastContext';
import { useDebounce } from '../../hooks';

const REASONS = ['wrong_size','wrong_color','wrong_item','defective','customer_preference','other'];
const CONDITIONS = ['resalable','damaged','disposed'];

function CreateExchangeModal({ open, onClose, onSuccess }) {
  const [step, setStep]               = useState(1);
  const [receiptNum, setReceiptNum]   = useState('');
  const [sale, setSale]               = useState(null);
  const [lookupLoading, setLookupLoading] = useState(false);
  const [returnItems, setReturnItems] = useState([]);
  const [prodSearch, setProdSearch]   = useState('');
  const [prodResults, setProdResults] = useState([]);
  const [prodLoading, setProdLoading] = useState(false);
  const [replacements, setReplacements] = useState([]);
  const [reason, setReason]           = useState('wrong_size');
  const [submitLoading, setSubmitLoading] = useState(false);
  const { toast } = useToast();
  const debouncedSearch = useDebounce(prodSearch, 350);

  const reset = () => {
    setStep(1); setReceiptNum(''); setSale(null);
    setReturnItems([]); setProdSearch(''); setProdResults([]);
    setReplacements([]); setReason('wrong_size');
  };
  const handleClose = () => { reset(); onClose(); };

  const lookupSale = async () => {
    if (!receiptNum.trim()) return;
    setLookupLoading(true);
    try {
      const res = await salesApi.byReceipt(receiptNum.trim());
      const s = res.data.data.sale;
      if (s.status === 'voided') return toast('Cannot exchange a voided sale.', 'error');
      setSale(s);
      setReturnItems(s.items.map(i => ({ ...i, returnQty: 0, condition: 'resalable', selected: false })));
      setStep(2);
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setLookupLoading(false); }
  };

  useEffect(() => {
    if (!debouncedSearch.trim()) { setProdResults([]); return; }
    setProdLoading(true);
    cashierApi.searchProducts(debouncedSearch)
      .then(r => setProdResults(r.data.data.products || []))
      .catch(() => setProdResults([]))
      .finally(() => setProdLoading(false));
  }, [debouncedSearch]);

  const toggleReturnItem = (idx) => setReturnItems(prev => prev.map((i, n) => n === idx ? { ...i, selected: !i.selected, returnQty: i.selected ? 0 : 1 } : i));
  const setReturnQty     = (idx, qty) => setReturnItems(prev => prev.map((i, n) => n === idx ? { ...i, returnQty: Math.max(0, Math.min(qty, i.quantity)) } : i));
  const setReturnCond    = (idx, cond) => setReturnItems(prev => prev.map((i, n) => n === idx ? { ...i, condition: cond } : i));

  const addReplacement = (product) => {
    const existing = replacements.find(r => r.productId === product._id);
    if (existing) {
      setReplacements(prev => prev.map(r => r.productId === product._id ? { ...r, quantity: r.quantity + 1 } : r));
    } else {
      setReplacements(prev => [...prev, { productId: product._id, productName: product.name, sku: product.sku, unitPrice: product.sellingPrice, quantity: 1 }]);
    }
    setProdSearch('');
    setProdResults([]);
  };
  const removeReplacement = (productId) => setReplacements(prev => prev.filter(r => r.productId !== productId));
  const setReplQty = (productId, qty) => setReplacements(prev => prev.map(r => r.productId === productId ? { ...r, quantity: Math.max(1, qty) } : r));

  const returnTotal      = returnItems.filter(i => i.selected).reduce((s, i) => s + i.unitPrice * i.returnQty, 0);
  const replacementTotal = replacements.reduce((s, r) => s + r.unitPrice * r.quantity, 0);
  const priceDiff        = replacementTotal - returnTotal;

  const handleSubmit = async () => {
    const rItems = returnItems.filter(i => i.selected && i.returnQty > 0).map(i => ({
      productId: i.productId, variantId: i.variantId || undefined,
      quantity: i.returnQty, condition: i.condition,
    }));
    if (!rItems.length || !replacements.length) return toast('Select returned items and at least one replacement.', 'error');
    setSubmitLoading(true);
    try {
      await exchangesApi.create({
        saleId: sale._id,
        returnedItems: rItems,
        replacementItems: replacements.map(r => ({ productId: r.productId, quantity: r.quantity })),
        reason,
      });
      toast('Exchange processed.', 'success');
      handleClose();
      onSuccess();
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setSubmitLoading(false); }
  };

  if (!open) return null;

  return (
    <Modal open={open} onClose={handleClose} title="Process Exchange" size="modal-lg">
      {step === 1 && (
        <div>
          <FormField label="Receipt Number" required>
            <input className="form-input" value={receiptNum} onChange={e => setReceiptNum(e.target.value.toUpperCase())} placeholder="RCP-20240101-XXXX" autoFocus onKeyDown={e => e.key === 'Enter' && lookupSale()} />
          </FormField>
          <div className="flex justify-end gap-2">
            <button className="btn btn-ghost" onClick={handleClose}>Cancel</button>
            <button className="btn btn-primary" onClick={lookupSale} disabled={lookupLoading}>
              {lookupLoading ? <Spinner size={14} /> : 'Look Up Sale'}
            </button>
          </div>
        </div>
      )}

      {step === 2 && sale && (
        <div>
          <div style={{ background:'var(--bg-overlay)', borderRadius:'var(--radius-md)', padding:'10px 16px', marginBottom:16, fontSize:13 }}>
            <strong>Sale:</strong> {sale.receiptNumber} · {fmt.currency(sale.grandTotal)}
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20, marginBottom:20 }}>
            {/* Return items */}
            <div>
              <p style={{ fontWeight:700, fontSize:13, marginBottom:8 }}>Items Being Returned</p>
              <div style={{ display:'flex', flexDirection:'column', gap:6, maxHeight:220, overflowY:'auto' }}>
                {returnItems.map((item, idx) => (
                  <div key={idx} style={{ background:'var(--bg-overlay)', borderRadius:'var(--radius-md)', padding:10, border:`1px solid ${item.selected ? 'var(--accent)' : 'var(--border)'}`, fontSize:12 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom: item.selected ? 8 : 0 }}>
                      <input type="checkbox" checked={item.selected} onChange={() => toggleReturnItem(idx)} />
                      <span style={{ fontWeight:600, flex:1 }}>{item.productName}</span>
                      <span className="td-mono" style={{ color:'var(--text-muted)' }}>×{item.quantity}</span>
                    </div>
                    {item.selected && (
                      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:6 }}>
                        <input className="form-input" type="number" min={1} max={item.quantity} value={item.returnQty} onChange={e => setReturnQty(idx, parseInt(e.target.value)||0)} style={{ padding:'5px 8px', fontSize:12 }} />
                        <select className="form-select" value={item.condition} onChange={e => setReturnCond(idx, e.target.value)} style={{ padding:'5px 8px', fontSize:12 }}>
                          {CONDITIONS.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Replacement items */}
            <div>
              <p style={{ fontWeight:700, fontSize:13, marginBottom:8 }}>Replacement Items</p>
              <div style={{ position:'relative', marginBottom:8 }}>
                <input className="form-input" value={prodSearch} onChange={e => setProdSearch(e.target.value)} placeholder="Search replacement products…" style={{ fontSize:12, padding:'7px 10px' }} />
                {prodLoading && <div style={{ position:'absolute', right:8, top:8 }}><Spinner size={14} /></div>}
                {prodResults.length > 0 && (
                  <div style={{ position:'absolute', top:'100%', left:0, right:0, background:'var(--bg-elevated)', border:'1px solid var(--border)', borderRadius:'var(--radius-md)', zIndex:10, maxHeight:160, overflowY:'auto' }}>
                    {prodResults.map(p => (
                      <div key={p._id} onClick={() => addReplacement(p)}
                        style={{ padding:'8px 12px', fontSize:12, cursor:'pointer', borderBottom:'1px solid var(--border)' }}
                        onMouseOver={e => e.currentTarget.style.background = 'var(--bg-overlay)'}
                        onMouseOut={e => e.currentTarget.style.background = 'transparent'}
                      >
                        <strong>{p.name}</strong> · <span className="td-mono">{fmt.currency(p.sellingPrice)}</span>
                        <span style={{ color:'var(--text-muted)', marginLeft:8 }}>Stock: {p.totalStock}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:6, maxHeight:160, overflowY:'auto' }}>
                {replacements.length === 0 && <p style={{ fontSize:12, color:'var(--text-muted)', padding:'8px 0' }}>No replacements added yet.</p>}
                {replacements.map(r => (
                  <div key={r.productId} style={{ display:'flex', alignItems:'center', gap:8, background:'var(--bg-overlay)', borderRadius:'var(--radius-md)', padding:8, fontSize:12 }}>
                    <span style={{ flex:1, fontWeight:600 }}>{r.productName}</span>
                    <input className="form-input" type="number" min={1} value={r.quantity} onChange={e => setReplQty(r.productId, parseInt(e.target.value)||1)} style={{ width:48, padding:'4px 6px', fontSize:12 }} />
                    <span className="td-mono">{fmt.currency(r.unitPrice * r.quantity)}</span>
                    <button onClick={() => removeReplacement(r.productId)} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', fontSize:16 }}>×</button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Price difference */}
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8, marginBottom:16 }}>
            {[['Returned Value', returnTotal, 'var(--blue)'], ['Replacement Value', replacementTotal, 'var(--accent)'], ['Price Difference', priceDiff, priceDiff > 0 ? 'var(--red)' : 'var(--green)']].map(([l, v, c]) => (
              <div key={l} style={{ background:'var(--bg-overlay)', borderRadius:'var(--radius-md)', padding:'10px 14px' }}>
                <p style={{ fontSize:11, color:'var(--text-muted)', marginBottom:4 }}>{l}</p>
                <p style={{ fontFamily:'var(--font-mono)', fontWeight:700, color: c }}>{priceDiff === 0 && l === 'Price Difference' ? 'Even' : fmt.currency(v)}</p>
              </div>
            ))}
          </div>

          <FormField label="Reason">
            <select className="form-select" value={reason} onChange={e => setReason(e.target.value)}>
              {REASONS.map(r => <option key={r} value={r}>{r.replace(/_/g,' ')}</option>)}
            </select>
          </FormField>

          <div className="flex justify-end gap-2">
            <button className="btn btn-ghost" onClick={() => setStep(1)}>Back</button>
            <button className="btn btn-primary" onClick={handleSubmit} disabled={submitLoading}>
              {submitLoading ? <Spinner size={14} /> : 'Complete Exchange'}
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
}

export default function Exchanges() {
  const [exchanges, setExchanges] = useState([]);
  const [total, setTotal]         = useState(0);
  const [page, setPage]           = useState(1);
  const [loading, setLoading]     = useState(true);
  const [detail, setDetail]       = useState(null);
  const [createOpen, setCreateOpen] = useState(false);
  const LIMIT = 20;
  const { toast } = useToast();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await exchangesApi.list({ page, limit: LIMIT });
      setExchanges(res.data.data || []);
      setTotal(res.data.pagination?.total || 0);
    } catch { toast('Failed to load exchanges.', 'error'); }
    finally { setLoading(false); }
  }, [page, toast]);

  useEffect(() => { load(); }, [load]);

  const columns = [
    { key:'exchangeNumber', label:'Exchange #', render: e => <span className="td-mono">{e.exchangeNumber}</span> },
    { key:'sale', label:'Original Sale', render: e => <span className="td-mono" style={{ fontSize:12 }}>{e.saleId?.receiptNumber || '—'}</span> },
    { key:'processedBy', label:'By', render: e => e.processedBy?.name || '—' },
    { key:'reason', label:'Reason', render: e => <span style={{ fontSize:12, color:'var(--text-muted)' }}>{e.reason?.replace(/_/g,' ')}</span> },
    { key:'returnedTotal', label:'Returned', render: e => <span className="td-mono" style={{ color:'var(--blue)' }}>{fmt.currency(e.returnedItemsTotal)}</span> },
    { key:'replacementTotal', label:'Replacement', render: e => <span className="td-mono" style={{ color:'var(--accent)' }}>{fmt.currency(e.replacementItemsTotal)}</span> },
    { key:'diff', label:'Difference', render: e => <span className="td-mono" style={{ fontWeight:700, color: e.priceDifference > 0 ? 'var(--red)' : e.priceDifference < 0 ? 'var(--green)' : 'var(--text-muted)' }}>{e.priceDifference === 0 ? 'Even' : fmt.currency(e.priceDifference)}</span> },
    { key:'status', label:'Status', render: e => <Badge status={e.status} label={e.status} /> },
    { key:'date', label:'Date', render: e => <span style={{ color:'var(--text-muted)', fontSize:12 }}>{fmt.dateTime(e.createdAt)}</span> },
    { key:'actions', label:'', render: e => <button className="btn btn-ghost btn-sm" onClick={() => setDetail(e)}>View</button> },
  ];

  return (
    <AppLayout title="Exchanges" actions={<button className="btn btn-primary" onClick={() => setCreateOpen(true)}>+ Process Exchange</button>}>
      <DataTable columns={columns} data={exchanges} loading={loading} emptyMessage="No exchanges found." />
      <Pagination page={page} pages={Math.ceil(total / LIMIT)} total={total} limit={LIMIT} onPage={setPage} />

      <CreateExchangeModal open={createOpen} onClose={() => setCreateOpen(false)} onSuccess={load} />

      <Modal open={!!detail} onClose={() => setDetail(null)} title={`Exchange — ${detail?.exchangeNumber}`} size="modal-lg">
        {detail && (
          <div>
            <div className="grid-2" style={{ marginBottom:16 }}>
              <div><p className="text-muted" style={{ fontSize:11 }}>ORIGINAL SALE</p><p className="td-mono">{detail.saleId?.receiptNumber}</p></div>
              <div><p className="text-muted" style={{ fontSize:11 }}>STATUS</p><Badge status={detail.status} label={detail.status} /></div>
              <div><p className="text-muted" style={{ fontSize:11 }}>REASON</p><p>{detail.reason?.replace(/_/g,' ')}</p></div>
              <div><p className="text-muted" style={{ fontSize:11 }}>PRICE DIFFERENCE</p>
                <p className="td-mono" style={{ fontWeight:700, color: detail.priceDifference > 0 ? 'var(--red)' : 'var(--green)' }}>
                  {detail.priceDifference === 0 ? 'Even' : fmt.currency(detail.priceDifference)}
                </p>
              </div>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
              <div>
                <p style={{ fontWeight:700, fontSize:12, marginBottom:8, color:'var(--text-muted)' }}>RETURNED ITEMS</p>
                {detail.returnedItems?.map((item, i) => (
                  <div key={i} style={{ fontSize:13, marginBottom:6, background:'var(--bg-overlay)', padding:'8px 12px', borderRadius:'var(--radius-md)' }}>
                    <strong>{item.productName}</strong> × {item.quantity}<br/>
                    <span className="td-mono" style={{ fontSize:12, color:'var(--blue)' }}>{fmt.currency(item.totalPrice)}</span>
                    <span style={{ fontSize:11, color:'var(--text-muted)', marginLeft:8 }}>{item.condition}</span>
                  </div>
                ))}
              </div>
              <div>
                <p style={{ fontWeight:700, fontSize:12, marginBottom:8, color:'var(--text-muted)' }}>REPLACEMENT ITEMS</p>
                {detail.replacementItems?.map((item, i) => (
                  <div key={i} style={{ fontSize:13, marginBottom:6, background:'var(--bg-overlay)', padding:'8px 12px', borderRadius:'var(--radius-md)' }}>
                    <strong>{item.productName}</strong> × {item.quantity}<br/>
                    <span className="td-mono" style={{ fontSize:12, color:'var(--accent)' }}>{fmt.currency(item.totalPrice)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </Modal>
    </AppLayout>
  );
}
