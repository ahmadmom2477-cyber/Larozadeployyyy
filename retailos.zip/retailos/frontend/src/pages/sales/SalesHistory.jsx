import React, { useState, useEffect, useCallback } from 'react';
import AppLayout from '../../components/layout/AppLayout';
import { DataTable, Pagination, Modal, ConfirmModal, Badge, Spinner, FormField } from '../../components/shared';
import { salesApi } from '../../api';
import { fmt, statusBadge, errMsg } from '../../utils';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';

const STATUSES = ['', 'completed', 'partially_refunded', 'refunded', 'voided'];

export default function SalesHistory() {
  const [sales, setSales]         = useState([]);
  const [total, setTotal]         = useState(0);
  const [page, setPage]           = useState(1);
  const [loading, setLoading]     = useState(true);
  const [statusFilter, setStatus] = useState('');
  const [detail, setDetail]       = useState(null);
  const [voidTarget, setVoidTarget] = useState(null);
  const [voidReason, setVoidReason] = useState('');
  const [voidLoading, setVoidLoading] = useState(false);
  const LIMIT = 20;

  const { toast }   = useToast();
  const { hasRole } = useAuth();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: LIMIT };
      if (statusFilter) params.status = statusFilter;
      const res = await salesApi.list(params);
      setSales(res.data.data || []);
      setTotal(res.data.pagination?.total || 0);
    } catch { toast('Failed to load sales.', 'error'); }
    finally { setLoading(false); }
  }, [page, statusFilter, toast]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { setPage(1); }, [statusFilter]);

  const handleVoid = async () => {
    if (!voidReason.trim()) return toast('Please enter a void reason.', 'error');
    setVoidLoading(true);
    try {
      await salesApi.void(voidTarget._id, voidReason);
      toast('Sale voided.', 'success');
      setVoidTarget(null);
      setVoidReason('');
      load();
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setVoidLoading(false); }
  };

  const columns = [
    { key:'receiptNumber', label:'Receipt', render: s => <span className="td-mono">{s.receiptNumber}</span> },
    { key:'cashier', label:'Cashier', render: s => s.cashierId?.name || '—' },
    { key:'items', label:'Items', render: s => <span className="td-mono">{s.items?.length || 0}</span> },
    { key:'grandTotal', label:'Total', render: s => <span className="td-mono" style={{ fontWeight:700 }}>{fmt.currency(s.grandTotal)}</span> },
    { key:'payment', label:'Payment', render: s => (
        <span className="td-mono" style={{ fontSize:12, color:'var(--text-muted)' }}>
          {s.payments?.map(p => p.method).join(', ') || '—'}
        </span>
      )},
    { key:'status', label:'Status', render: s => <Badge status={s.status} label={s.status.replace(/_/g,' ')} /> },
    { key:'date', label:'Date', render: s => <span style={{ color:'var(--text-muted)', fontSize:12 }}>{fmt.dateTime(s.createdAt)}</span> },
    { key:'actions', label:'', render: s => (
        <div className="flex gap-2">
          <button className="btn btn-ghost btn-sm" onClick={() => setDetail(s)}>View</button>
          {hasRole('admin','manager') && s.status === 'completed' && (
            <button className="btn btn-sm" style={{ background:'var(--red-dim)', color:'var(--red)', border:'1px solid rgba(239,68,68,0.2)' }} onClick={() => setVoidTarget(s)}>
              Void
            </button>
          )}
        </div>
      )},
  ];

  return (
    <AppLayout title="Sales History" actions={
      <div className="flex items-center gap-2">
        <select className="form-select" value={statusFilter} onChange={e => setStatus(e.target.value)} style={{ minWidth:160 }}>
          {STATUSES.map(s => <option key={s} value={s}>{s ? s.replace(/_/g,' ') : 'All Statuses'}</option>)}
        </select>
      </div>
    }>
      <DataTable columns={columns} data={sales} loading={loading} emptyMessage="No sales found." />
      <Pagination page={page} pages={Math.ceil(total / LIMIT)} total={total} limit={LIMIT} onPage={setPage} />

      {/* Detail Modal */}
      <Modal open={!!detail} onClose={() => setDetail(null)} title={`Sale — ${detail?.receiptNumber}`} size="modal-lg">
        {detail && (
          <div>
            <div className="grid-2" style={{ marginBottom:16 }}>
              <div>
                <p className="text-muted" style={{ fontSize:11, marginBottom:4 }}>CASHIER</p>
                <p style={{ fontWeight:600 }}>{detail.cashierId?.name || '—'}</p>
              </div>
              <div>
                <p className="text-muted" style={{ fontSize:11, marginBottom:4 }}>DATE</p>
                <p>{fmt.dateTime(detail.createdAt)}</p>
              </div>
              <div>
                <p className="text-muted" style={{ fontSize:11, marginBottom:4 }}>STATUS</p>
                <Badge status={detail.status} label={detail.status.replace(/_/g,' ')} />
              </div>
              <div>
                <p className="text-muted" style={{ fontSize:11, marginBottom:4 }}>PAYMENT</p>
                <p style={{ fontFamily:'var(--font-mono)', fontSize:13 }}>
                  {detail.payments?.map(p => `${p.method} ${fmt.currency(p.amount)}`).join(' + ')}
                </p>
              </div>
            </div>

            <div className="table-container" style={{ marginBottom:16 }}>
              <table>
                <thead>
                  <tr>
                    {['Product','SKU','Qty','Unit Price','Discount','Tax','Total'].map(h => <th key={h}>{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {detail.items?.map(item => (
                    <tr key={item._id}>
                      <td style={{ fontWeight:600 }}>{item.productName}</td>
                      <td className="td-mono">{item.sku}</td>
                      <td className="td-mono">{item.quantity}</td>
                      <td className="td-mono">{fmt.currency(item.unitPrice)}</td>
                      <td className="td-mono">{item.discountAmount > 0 ? `-${fmt.currency(item.discountAmount)}` : '—'}</td>
                      <td className="td-mono">{fmt.currency(item.taxAmount)}</td>
                      <td className="td-mono" style={{ fontWeight:700 }}>{fmt.currency(item.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div style={{ textAlign:'right' }}>
              {[
                ['Subtotal',   detail.subtotal],
                ['Discount',   -detail.discountTotal],
                ['Tax',        detail.taxTotal],
                ['Grand Total',detail.grandTotal],
                ['Amount Paid',detail.amountPaid],
                ['Change Due', detail.changeDue],
              ].map(([label, val]) => (
                <div key={label} style={{ display:'flex', justifyContent:'flex-end', gap:40, fontSize:13, marginBottom:4 }}>
                  <span style={{ color:'var(--text-muted)' }}>{label}</span>
                  <span className="td-mono" style={{ minWidth:80, fontWeight: label === 'Grand Total' ? 800 : 400, color: label === 'Grand Total' ? 'var(--accent)' : undefined }}>
                    {fmt.currency(val)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </Modal>

      {/* Void Modal */}
      <Modal open={!!voidTarget} onClose={() => { setVoidTarget(null); setVoidReason(''); }} title="Void Sale" size="modal-sm">
        <p style={{ color:'var(--text-secondary)', fontSize:13, marginBottom:16 }}>
          You are voiding sale <strong>{voidTarget?.receiptNumber}</strong>. Stock will be restored.
          This action cannot be undone.
        </p>
        <FormField label="Void Reason" required>
          <input className="form-input" value={voidReason} onChange={e => setVoidReason(e.target.value)} placeholder="Reason for voiding this sale…" autoFocus />
        </FormField>
        <div className="flex justify-end gap-2">
          <button className="btn btn-ghost" onClick={() => { setVoidTarget(null); setVoidReason(''); }}>Cancel</button>
          <button className="btn btn-danger" onClick={handleVoid} disabled={voidLoading}>
            {voidLoading ? <Spinner size={14} /> : 'Void Sale'}
          </button>
        </div>
      </Modal>
    </AppLayout>
  );
}
