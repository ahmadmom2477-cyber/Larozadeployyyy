import React, { useState, useEffect, useCallback } from 'react';
import AppLayout from '../../components/layout/AppLayout';
import { DataTable, Pagination, Modal, Spinner, StatCard, FormField } from '../../components/shared';
import { inventoryApi } from '../../api';
import { fmt, errMsg } from '../../utils';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';

const ADJUST_TYPES = ['manual_adjustment','purchase_receipt','damage_write_off','audit_correction','transfer_in','transfer_out'];

export default function Inventory() {
  const [tab, setTab]             = useState('logs');
  const [logs, setLogs]           = useState([]);
  const [logsTotal, setLogsTotal] = useState(0);
  const [logsPage, setLogsPage]   = useState(1);
  const [lowStock, setLowStock]   = useState([]);
  const [valuation, setValuation] = useState(null);
  const [loading, setLoading]     = useState(true);
  const [adjOpen, setAdjOpen]     = useState(false);
  const [adjForm, setAdjForm]     = useState({ productId:'', quantityChange:'', type:'manual_adjustment', reason:'' });
  const [adjLoading, setAdjLoading] = useState(false);
  const LIMIT = 25;

  const { toast }   = useToast();
  const { hasRole } = useAuth();

  const loadLogs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await inventoryApi.getLogs({ page: logsPage, limit: LIMIT });
      setLogs(res.data.data || []);
      setLogsTotal(res.data.pagination?.total || 0);
    } catch { toast('Failed to load logs.', 'error'); }
    finally { setLoading(false); }
  }, [logsPage, toast]);

  const loadLowStock = useCallback(async () => {
    setLoading(true);
    try {
      const res = await inventoryApi.getLowStock();
      setLowStock(res.data.data?.products || []);
    } finally { setLoading(false); }
  }, []);

  const loadValuation = useCallback(async () => {
    try {
      const res = await inventoryApi.getValuation();
      setValuation(res.data.data?.valuation);
    } catch {}
  }, []);

  useEffect(() => { loadValuation(); }, [loadValuation]);
  useEffect(() => {
    if (tab === 'logs')      loadLogs();
    if (tab === 'low-stock') loadLowStock();
  }, [tab, loadLogs, loadLowStock]);

  const adjChange = (k, v) => setAdjForm(f => ({ ...f, [k]: v }));

  const handleAdjust = async () => {
    const { productId, quantityChange, type, reason } = adjForm;
    if (!productId || !quantityChange || !type) return toast('Fill all required fields.', 'error');
    setAdjLoading(true);
    try {
      await inventoryApi.adjust({ productId, quantityChange: parseInt(quantityChange), type, reason });
      toast('Inventory adjusted.', 'success');
      setAdjOpen(false);
      setAdjForm({ productId:'', quantityChange:'', type:'manual_adjustment', reason:'' });
      loadLogs();
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setAdjLoading(false); }
  };

  const logColumns = [
    { key:'productName', label:'Product', render: l => (
        <div>
          <div style={{ fontWeight:600, fontSize:13 }}>{l.productName}</div>
          <div className="td-mono" style={{ fontSize:11, color:'var(--text-muted)' }}>{l.sku}</div>
        </div>
      )},
    { key:'type', label:'Type', render: l => (
        <span style={{ fontSize:12, fontFamily:'var(--font-mono)', color:'var(--text-secondary)', textTransform:'uppercase', letterSpacing:0.5 }}>
          {l.type.replace(/_/g,' ')}
        </span>
      )},
    { key:'change', label:'Change', render: l => (
        <span style={{ fontFamily:'var(--font-mono)', fontWeight:700, fontSize:13, color: l.quantityChange > 0 ? 'var(--green)' : 'var(--red)' }}>
          {l.quantityChange > 0 ? '+' : ''}{l.quantityChange}
        </span>
      )},
    { key:'before', label:'Before', render: l => <span className="td-mono">{l.quantityBefore}</span> },
    { key:'after',  label:'After',  render: l => <span className="td-mono">{l.quantityAfter}</span> },
    { key:'performedBy', label:'By', render: l => l.performedBy?.name || '—' },
    { key:'reason', label:'Reason', render: l => <span style={{ color:'var(--text-muted)', fontSize:12 }}>{l.reason || '—'}</span> },
    { key:'date', label:'Date', render: l => <span style={{ color:'var(--text-muted)', fontSize:12 }}>{fmt.dateTime(l.createdAt)}</span> },
  ];

  const lowColumns = [
    { key:'name', label:'Product', render: p => (
        <div>
          <div style={{ fontWeight:600 }}>{p.name}</div>
          <div className="td-mono" style={{ fontSize:11, color:'var(--text-muted)' }}>{p.sku}</div>
        </div>
      )},
    { key:'category', label:'Category', render: p => p.categoryId?.name || '—' },
    { key:'totalStock', label:'Stock', render: p => (
        <span style={{ fontFamily:'var(--font-mono)', fontWeight:800, color:'var(--red)' }}>{p.totalStock}</span>
      )},
    { key:'reorderPoint', label:'Reorder At', render: p => <span className="td-mono">{p.reorderPoint}</span> },
    { key:'costPrice', label:'Cost', render: p => <span className="td-mono">{fmt.currency(p.costPrice)}</span> },
    { key:'value', label:'Value', render: p => <span className="td-mono">{fmt.currency(p.costPrice * p.totalStock)}</span> },
  ];

  return (
    <AppLayout
      title="Inventory"
      actions={
        hasRole('admin','manager') && (
          <button className="btn btn-primary" onClick={() => setAdjOpen(true)}>Adjust Stock</button>
        )
      }
    >
      {/* Valuation Cards */}
      {valuation && hasRole('admin','manager') && (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16, marginBottom:24 }}>
          <StatCard label="Total Units" value={fmt.number(valuation.totalUnits)} accentColor="var(--blue)" icon={null} />
          <StatCard label="Products" value={fmt.number(valuation.productCount)} accentColor="var(--purple)" icon={null} />
          <StatCard label="Cost Value" value={fmt.currency(valuation.totalCostValue)} accentColor="var(--accent)" icon={null} />
          <StatCard label="Retail Value" value={fmt.currency(valuation.totalRetailValue)} accentColor="var(--green)" icon={null} />
        </div>
      )}

      {/* Tabs */}
      <div style={{ display:'flex', gap:4, marginBottom:16 }}>
        {[
          { id:'logs',      label:'Inventory Logs' },
          { id:'low-stock', label:'Low Stock' },
        ].map(t => (
          <button
            key={t.id}
            className={`btn ${tab === t.id ? 'btn-primary' : 'btn-ghost'}`}
            style={{ fontSize:13 }}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'logs' && (
        <>
          <DataTable columns={logColumns} data={logs} loading={loading} emptyMessage="No inventory logs yet." />
          <Pagination page={logsPage} pages={Math.ceil(logsTotal / LIMIT)} total={logsTotal} limit={LIMIT} onPage={setLogsPage} />
        </>
      )}

      {tab === 'low-stock' && (
        <DataTable columns={lowColumns} data={lowStock} loading={loading} emptyMessage="All products are well-stocked." />
      )}

      {/* Adjust Modal */}
      <Modal open={adjOpen} onClose={() => setAdjOpen(false)} title="Adjust Inventory" size="modal-md">
        <FormField label="Product ID" required hint="MongoDB ObjectId of the product.">
          <input className="form-input" value={adjForm.productId} onChange={e => adjChange('productId', e.target.value)} placeholder="64abc..." />
        </FormField>
        <FormField label="Quantity Change" required hint="Use negative values to reduce stock (e.g. -5).">
          <input className="form-input" type="number" value={adjForm.quantityChange} onChange={e => adjChange('quantityChange', e.target.value)} placeholder="+10 or -5" />
        </FormField>
        <FormField label="Adjustment Type" required>
          <select className="form-select" value={adjForm.type} onChange={e => adjChange('type', e.target.value)}>
            {ADJUST_TYPES.map(t => <option key={t} value={t}>{t.replace(/_/g,' ')}</option>)}
          </select>
        </FormField>
        <FormField label="Reason">
          <input className="form-input" value={adjForm.reason} onChange={e => adjChange('reason', e.target.value)} placeholder="Reason for this adjustment…" />
        </FormField>
        <div className="flex justify-end gap-2">
          <button className="btn btn-ghost" onClick={() => setAdjOpen(false)}>Cancel</button>
          <button className="btn btn-primary" onClick={handleAdjust} disabled={adjLoading}>
            {adjLoading ? <Spinner size={14} /> : 'Apply Adjustment'}
          </button>
        </div>
      </Modal>
    </AppLayout>
  );
}
