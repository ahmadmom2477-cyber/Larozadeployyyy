import React, { useState, useEffect, useRef, useCallback } from 'react';
import AppLayout from '../../components/layout/AppLayout';
import { Spinner, Modal } from '../../components/shared';
import { useCart } from '../../context/CartContext';
import { useToast } from '../../context/ToastContext';
import { cashierApi, salesApi } from '../../api';
import { fmt, errMsg } from '../../utils';
import { useDebounce } from '../../hooks';

/* ─── Payment Modal ───────────────────────────────────────────────────────── */
function PaymentModal({ open, onClose, grandTotal, onComplete }) {
  const [method,    setMethod]    = useState('cash');
  const [cash,      setCash]      = useState('');
  const [cardRef,   setCardRef]   = useState('');
  const [mobileRef, setMobileRef] = useState('');
  const [loading,   setLoading]   = useState(false);
  const { toast } = useToast();

  const cashAmt  = parseFloat(cash) || 0;
  const changeDue = method === 'cash' ? Math.max(0, cashAmt - grandTotal) : 0;

  const handlePay = async () => {
    if (method === 'cash' && cashAmt < grandTotal) {
      return toast(`Cash received (${fmt.currency(cashAmt)}) is less than total (${fmt.currency(grandTotal)}).`, 'error');
    }
    let payments;
    if (method === 'cash')         payments = [{ method: 'cash',         amount: cashAmt }];
    if (method === 'card')         payments = [{ method: 'card',         amount: grandTotal, reference: cardRef }];
    if (method === 'mobile_money') payments = [{ method: 'mobile_money', amount: grandTotal, reference: mobileRef }];

    setLoading(true);
    try {
      await onComplete(payments);
    } catch (err) {
      toast(errMsg(err), 'error');
    } finally {
      setLoading(false);
    }
  };

  const resetAndClose = () => {
    setMethod('cash'); setCash(''); setCardRef(''); setMobileRef('');
    onClose();
  };

  if (!open) return null;

  return (
    <Modal open={open} onClose={resetAndClose} title="Process Payment" size="modal-sm">
      <div style={{ marginBottom:20 }}>
        <p style={{ fontSize:13, color:'var(--text-muted)', marginBottom:6 }}>TOTAL DUE</p>
        <p style={{ fontSize:32, fontWeight:800, fontFamily:'var(--font-mono)', color:'var(--accent)' }}>
          {fmt.currency(grandTotal)}
        </p>
      </div>

      {/* Method selector */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8, marginBottom:20 }}>
        {[
          { id:'cash',         label:'Cash' },
          { id:'card',         label:'Card' },
          { id:'mobile_money', label:'Mobile' },
        ].map(m => (
          <button
            key={m.id}
            onClick={() => setMethod(m.id)}
            style={{
              padding:'10px 0',
              borderRadius:'var(--radius-md)',
              border: `1px solid ${method === m.id ? 'var(--accent)' : 'var(--border)'}`,
              background: method === m.id ? 'var(--accent-dim)' : 'var(--bg-overlay)',
              color: method === m.id ? 'var(--accent)' : 'var(--text-secondary)',
              fontWeight: 600, fontSize: 13, cursor: 'pointer', transition: 'all var(--transition)',
            }}
          >
            {m.label}
          </button>
        ))}
      </div>

      {method === 'cash' && (
        <>
          <div className="form-group">
            <label className="form-label">Cash Received</label>
            <input
              className="form-input"
              type="number"
              step="0.01"
              min={grandTotal}
              value={cash}
              onChange={e => setCash(e.target.value)}
              placeholder={fmt.currency(grandTotal)}
              autoFocus
            />
          </div>
          {cashAmt >= grandTotal && (
            <div style={{ background:'var(--green-dim)', border:'1px solid rgba(34,197,94,0.2)', borderRadius:'var(--radius-md)', padding:'12px 16px', marginBottom:16 }}>
              <p style={{ fontSize:12, color:'var(--text-muted)' }}>CHANGE DUE</p>
              <p style={{ fontSize:22, fontWeight:800, fontFamily:'var(--font-mono)', color:'var(--green)' }}>
                {fmt.currency(changeDue)}
              </p>
            </div>
          )}
        </>
      )}

      {method === 'card' && (
        <div className="form-group">
          <label className="form-label">Card Reference (optional)</label>
          <input className="form-input" value={cardRef} onChange={e => setCardRef(e.target.value)} placeholder="Last 4 digits or reference #" autoFocus />
        </div>
      )}

      {method === 'mobile_money' && (
        <div className="form-group">
          <label className="form-label">Mobile Money Reference</label>
          <input className="form-input" value={mobileRef} onChange={e => setMobileRef(e.target.value)} placeholder="Transaction reference" autoFocus />
        </div>
      )}

      <div style={{ display:'flex', gap:8 }}>
        <button className="btn btn-ghost" onClick={resetAndClose} style={{ flex:1 }}>Cancel</button>
        <button
          className="btn btn-primary"
          onClick={handlePay}
          disabled={loading || (method === 'cash' && cashAmt < grandTotal)}
          style={{ flex:2 }}
        >
          {loading ? <Spinner size={14} /> : `Charge ${fmt.currency(grandTotal)}`}
        </button>
      </div>
    </Modal>
  );
}

/* ─── Cart Item Row ───────────────────────────────────────────────────────── */
function CartItem({ item, onQty, onRemove }) {
  const lineTotal = item.unitPrice * item.quantity;
  return (
    <div className="cart-item">
      <div style={{ flex:1, minWidth:0 }}>
        <div className="cart-item-name truncate">{item.productName}</div>
        <div className="cart-item-sku">{item.sku} · {fmt.currency(item.unitPrice)}</div>
      </div>
      <div style={{ display:'flex', alignItems:'center', gap:6, flexShrink:0 }}>
        <button className="cart-qty-btn" onClick={() => onQty(item.quantity - 1)}>−</button>
        <span className="cart-qty">{item.quantity}</span>
        <button className="cart-qty-btn" onClick={() => onQty(item.quantity + 1)} disabled={item.quantity >= item.stock}>+</button>
      </div>
      <div className="cart-item-price">{fmt.currency(lineTotal)}</div>
      <button
        style={{ background:'none', border:'none', cursor:'pointer', color:'var(--text-muted)', padding:2, display:'flex', flexShrink:0 }}
        onClick={onRemove}
      >
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M18 6L6 18M6 6l12 12"/>
        </svg>
      </button>
    </div>
  );
}

/* ─── Product Card ────────────────────────────────────────────────────────── */
function ProductCard({ product, onAdd }) {
  const outOfStock = product.totalStock <= 0;
  return (
    <div
      className={`pos-product-card ${outOfStock ? 'out-of-stock' : ''}`}
      onClick={() => !outOfStock && onAdd(product)}
    >
      <div className="pos-product-name">{product.name}</div>
      <div className="pos-product-price">{fmt.currency(product.sellingPrice)}</div>
      <div className="pos-product-stock">{product.totalStock} in stock</div>
    </div>
  );
}

/* ─── Main POS Page ───────────────────────────────────────────────────────── */
export default function POS() {
  const [search, setSearch]         = useState('');
  const [products, setProducts]     = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [payModalOpen, setPayModal] = useState(false);
  const [receipt, setReceipt]       = useState(null);
  const searchRef = useRef(null);

  const debouncedSearch = useDebounce(search, 300);
  const { cart, addItem, removeItem, setQty, clearCart, grandTotal, subtotal, taxTotal } = useCart();
  const { toast } = useToast();

  // Load initial products & search
  useEffect(() => {
    if (!debouncedSearch.trim()) {
      cashierApi.searchProducts('a')
        .then(r => setProducts(r.data.data.products || []))
        .catch(() => {});
      return;
    }
    setSearchLoading(true);
    cashierApi.searchProducts(debouncedSearch)
      .then(r => setProducts(r.data.data.products || []))
      .catch(() => setProducts([]))
      .finally(() => setSearchLoading(false));
  }, [debouncedSearch]);

  const handleComplete = useCallback(async (payments) => {
    const saleItems = cart.items.map(i => ({
      productId:     i.productId,
      variantId:     i.variantId,
      quantity:      i.quantity,
      discountType:  i.discountType,
      discountValue: i.discountValue,
    }));
    const res = await salesApi.create({ items: saleItems, payments });
    const sale = res.data.data.sale;
    setReceipt(sale);
    clearCart();
    setPayModal(false);
    toast(`Sale ${sale.receiptNumber} completed!`, 'success');
    // Refresh product list to update stock
    cashierApi.searchProducts(search || 'a').then(r => setProducts(r.data.data.products || [])).catch(() => {});
  }, [cart.items, clearCart, search, toast]);

  const handleNewSale = () => setReceipt(null);

  // ── Receipt screen ───────────────────────────────────────────────────────
  if (receipt) {
    return (
      <AppLayout title="Sale Complete">
        <div style={{ maxWidth:480, margin:'0 auto', textAlign:'center' }}>
          <div style={{ fontSize:48, marginBottom:8 }}>✅</div>
          <h2 style={{ fontSize:22, fontWeight:800, marginBottom:4 }}>Payment Received</h2>
          <p className="text-muted" style={{ marginBottom:28 }}>{fmt.dateTime(receipt.createdAt)}</p>

          <div style={{ background:'var(--bg-surface)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', padding:24, textAlign:'left', marginBottom:24 }}>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:16 }}>
              <span className="text-muted text-mono" style={{ fontSize:12 }}>RECEIPT</span>
              <span className="text-mono" style={{ fontWeight:700 }}>{receipt.receiptNumber}</span>
            </div>
            {receipt.items?.map(item => (
              <div key={item._id} style={{ display:'flex', justifyContent:'space-between', marginBottom:8, fontSize:13 }}>
                <span>{item.productName} × {item.quantity}</span>
                <span className="text-mono">{fmt.currency(item.total)}</span>
              </div>
            ))}
            <div className="divider" />
            <div style={{ display:'flex', justifyContent:'space-between', fontSize:13, color:'var(--text-secondary)', marginBottom:4 }}>
              <span>Subtotal</span><span className="text-mono">{fmt.currency(receipt.subtotal)}</span>
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', fontSize:13, color:'var(--text-secondary)', marginBottom:4 }}>
              <span>Tax</span><span className="text-mono">{fmt.currency(receipt.taxTotal)}</span>
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', fontSize:18, fontWeight:800, marginTop:8 }}>
              <span>Total</span><span className="text-mono text-accent">{fmt.currency(receipt.grandTotal)}</span>
            </div>
            {receipt.changeDue > 0 && (
              <div style={{ marginTop:12, background:'var(--green-dim)', borderRadius:'var(--radius-md)', padding:'8px 12px', fontSize:13 }}>
                Change due: <strong className="text-mono">{fmt.currency(receipt.changeDue)}</strong>
              </div>
            )}
          </div>
          <button className="btn btn-primary w-full" onClick={handleNewSale}>New Sale</button>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="POS Terminal">
      <div className="pos-layout">
        {/* ── Products Panel ── */}
        <div className="pos-products">
          {/* Search bar */}
          <div style={{ padding:'12px 14px', borderBottom:'1px solid var(--border)' }}>
            <div className="search-bar">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
              </svg>
              <input
                ref={searchRef}
                className="form-input"
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search by name, SKU, or scan barcode…"
                style={{ paddingLeft:38 }}
                autoFocus
              />
              {searchLoading && (
                <div style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)' }}>
                  <Spinner size={14} />
                </div>
              )}
            </div>
          </div>

          {/* Product grid */}
          <div className="pos-product-grid">
            {products.length === 0 && !searchLoading && (
              <p style={{ gridColumn:'1/-1', textAlign:'center', color:'var(--text-muted)', padding:40, fontSize:13 }}>
                {search ? 'No products found for that search.' : 'Start typing to search products.'}
              </p>
            )}
            {products.map(p => (
              <ProductCard key={p._id} product={p} onAdd={(prod) => addItem(prod)} />
            ))}
          </div>
        </div>

        {/* ── Cart Panel ── */}
        <div className="pos-cart">
          <div className="pos-cart-header">
            <span>Cart · {cart.items.reduce((s, i) => s + i.quantity, 0)} items</span>
            {cart.items.length > 0 && (
              <button className="btn btn-ghost btn-sm" onClick={clearCart} style={{ fontSize:11 }}>
                Clear
              </button>
            )}
          </div>

          <div className="pos-cart-items">
            {cart.items.length === 0 ? (
              <div style={{ textAlign:'center', padding:'48px 20px', color:'var(--text-muted)' }}>
                <svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ margin:'0 auto 10px', display:'block', opacity:0.3 }}>
                  <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4zM3 6h18M16 10a4 4 0 01-8 0"/>
                </svg>
                <p style={{ fontSize:13 }}>Cart is empty</p>
              </div>
            ) : (
              cart.items.map(item => (
                <CartItem
                  key={item.key}
                  item={item}
                  onQty={qty => setQty(item.key, qty, item.stock)}
                  onRemove={() => removeItem(item.key)}
                />
              ))
            )}
          </div>

          {/* Totals */}
          <div className="pos-totals">
            <div className="totals-row">
              <span>Subtotal</span>
              <span>{fmt.currency(subtotal)}</span>
            </div>
            <div className="totals-row">
              <span>Tax</span>
              <span>{fmt.currency(taxTotal)}</span>
            </div>
            <div className="totals-row grand">
              <span>Total</span>
              <span>{fmt.currency(grandTotal)}</span>
            </div>
            <button
              className="btn btn-primary w-full"
              style={{ marginTop:14, padding:'13px 0', fontSize:15, fontWeight:800 }}
              disabled={cart.items.length === 0}
              onClick={() => setPayModal(true)}
            >
              Charge {fmt.currency(grandTotal)}
            </button>
          </div>
        </div>
      </div>

      <PaymentModal
        open={payModalOpen}
        onClose={() => setPayModal(false)}
        grandTotal={grandTotal}
        onComplete={handleComplete}
      />
    </AppLayout>
  );
}
