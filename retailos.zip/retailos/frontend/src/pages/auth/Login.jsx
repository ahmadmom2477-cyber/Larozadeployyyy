import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function Login() {
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const { login }   = useAuth();
  const { toast }   = useToast();
  const navigate    = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) return toast('Please enter email and password.', 'error');
    setLoading(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err) {
      toast(err?.response?.data?.message || 'Invalid credentials.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const fill = (e, p) => { setEmail(e); setPassword(p); };

  return (
    <div className="login-page">
      <div className="login-bg-pattern" />
      <div className="login-card">
        <div className="login-box">
          <div className="login-logo">
            <div className="login-logo-mark">POS</div>
            <div className="login-title">RetailOS</div>
            <div className="login-sub">Point of Sale &amp; Inventory Management</div>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input
                className="form-input"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@store.com"
                autoComplete="email"
                autoFocus
              />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                className="form-input"
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
              />
            </div>
            <button
              type="submit"
              className="btn btn-primary w-full"
              disabled={loading}
              style={{ marginTop: 8 }}
            >
              {loading ? 'Signing in…' : 'Sign In'}
            </button>
          </form>

          <div className="divider" style={{ margin: '24px 0 16px' }} />
          <p style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 10 }}>
            DEMO CREDENTIALS
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[
              ['admin@pos.com',   'Admin@1234',   'Admin'],
              ['manager@pos.com', 'Manager@1234', 'Manager'],
              ['cashier@pos.com', 'Cashier@1234', 'Cashier'],
            ].map(([e, p, role]) => (
              <button
                key={role}
                className="btn btn-ghost"
                style={{ fontSize: 12, justifyContent: 'flex-start', gap: 10 }}
                onClick={() => fill(e, p)}
                type="button"
              >
                <span className="badge badge-neutral" style={{ fontSize: 10 }}>{role}</span>
                <span className="text-mono" style={{ color: 'var(--text-muted)' }}>{e}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
