import React, { useState, useEffect } from 'react';
import {
  AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import AppLayout from '../../components/layout/AppLayout';
import { StatCard, LoadingScreen, Badge } from '../../components/shared';
import { dashboardApi, reportsApi } from '../../api';
import { fmt } from '../../utils';
import { useAuth } from '../../context/AuthContext';

const iconRevenue  = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 100 7h5a3.5 3.5 0 110 7H6"/></svg>;
const iconCart     = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4zM3 6h18"/><path d="M16 10a4 4 0 01-8 0"/></svg>;
const iconBox      = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M21 16V8a2 2 0 00-1-1.73L13 2.27a2 2 0 00-2 0L4 6.27A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12"/></svg>;
const iconAlert    = <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg>;

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background:'var(--bg-elevated)', border:'1px solid var(--border)', borderRadius:8, padding:'10px 14px', fontSize:12 }}>
      <p style={{ color:'var(--text-muted)', marginBottom:4 }}>{label}</p>
      {payload.map(p => (
        <p key={p.dataKey} style={{ color: p.color, fontFamily:'var(--font-mono)' }}>
          {p.name}: {fmt.currency(p.value)}
        </p>
      ))}
    </div>
  );
};

export default function Dashboard() {
  const { user } = useAuth();
  const [summary, setSummary] = useState(null);
  const [daily,   setDaily]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [sRes, dRes] = await Promise.all([
          dashboardApi.summary(),
          reportsApi.dailySales({ from: new Date(Date.now() - 29 * 86400000).toISOString().slice(0, 10) }),
        ]);
        setSummary(sRes.data.data);
        setDaily(dRes.data.data?.days || []);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <AppLayout title="Dashboard"><LoadingScreen /></AppLayout>;

  const chartData = daily.map(d => ({
    date:         new Date(d._id).toLocaleDateString('en-US', { month:'short', day:'numeric' }),
    Revenue:      d.revenue,
    Transactions: d.transactions,
  }));

  return (
    <AppLayout title={`Welcome back, ${user?.name?.split(' ')[0] || 'there'} 👋`}>
      {/* ── KPI Cards ── */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16, marginBottom:24 }}>
        <StatCard
          label="Today's Revenue"
          value={fmt.currency(summary?.today?.revenue)}
          icon={iconRevenue}
          accentColor="var(--accent)"
        />
        <StatCard
          label="Today's Transactions"
          value={fmt.number(summary?.today?.transactions)}
          icon={iconCart}
          accentColor="var(--blue)"
        />
        <StatCard
          label="Total Products"
          value={fmt.number(summary?.inventory?.totalProducts)}
          icon={iconBox}
          accentColor="var(--green)"
        />
        <StatCard
          label="Low Stock Alerts"
          value={fmt.number(summary?.inventory?.lowStockCount)}
          icon={iconAlert}
          accentColor="var(--red)"
        />
      </div>

      {/* ── Charts Row ── */}
      <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:16, marginBottom:24 }}>
        {/* Revenue Area Chart */}
        <div style={{ background:'var(--bg-surface)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'20px 20px 12px' }}>
          <div style={{ marginBottom:16 }}>
            <p style={{ fontWeight:700, fontSize:14 }}>Revenue (30 days)</p>
            <p style={{ fontSize:12, color:'var(--text-muted)', marginTop:2 }}>
              Month total: {fmt.currency(summary?.month?.revenue)}
            </p>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={chartData} margin={{ top:5, right:5, left:5, bottom:0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="var(--accent)" stopOpacity={0.15}/>
                  <stop offset="95%" stopColor="var(--accent)" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false}/>
              <XAxis dataKey="date" tick={{ fontSize:10, fill:'var(--text-muted)' }} axisLine={false} tickLine={false} interval="preserveStartEnd"/>
              <YAxis tick={{ fontSize:10, fill:'var(--text-muted)' }} axisLine={false} tickLine={false} tickFormatter={v => `$${v >= 1000 ? (v/1000).toFixed(0)+'k' : v}`}/>
              <Tooltip content={<CustomTooltip />}/>
              <Area type="monotone" dataKey="Revenue" stroke="var(--accent)" strokeWidth={2} fill="url(#revGrad)" dot={false}/>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Transactions Bar Chart */}
        <div style={{ background:'var(--bg-surface)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'20px 20px 12px' }}>
          <div style={{ marginBottom:16 }}>
            <p style={{ fontWeight:700, fontSize:14 }}>Transactions (30 days)</p>
            <p style={{ fontSize:12, color:'var(--text-muted)', marginTop:2 }}>
              Month total: {fmt.number(summary?.month?.transactions)}
            </p>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={chartData} margin={{ top:5, right:5, left:-20, bottom:0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false}/>
              <XAxis dataKey="date" tick={{ fontSize:10, fill:'var(--text-muted)' }} axisLine={false} tickLine={false} interval="preserveStartEnd"/>
              <YAxis tick={{ fontSize:10, fill:'var(--text-muted)' }} axisLine={false} tickLine={false}/>
              <Tooltip content={<CustomTooltip />}/>
              <Bar dataKey="Transactions" fill="var(--blue)" radius={[3,3,0,0]} maxBarSize={20}/>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ── Bottom Row ── */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        {/* Recent Sales */}
        <div style={{ background:'var(--bg-surface)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', overflow:'hidden' }}>
          <div style={{ padding:'16px 20px', borderBottom:'1px solid var(--border)', fontWeight:700, fontSize:14 }}>
            Recent Sales
          </div>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
            <thead>
              <tr>
                {['Receipt','Cashier','Amount','Time'].map(h => (
                  <th key={h} style={{ padding:'10px 16px', textAlign:'left', fontSize:10, color:'var(--text-muted)', fontFamily:'var(--font-mono)', letterSpacing:1, textTransform:'uppercase', fontWeight:600 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(summary?.recentSales || []).map(sale => (
                <tr key={sale._id} style={{ borderTop:'1px solid rgba(255,255,255,0.03)' }}>
                  <td style={{ padding:'12px 16px', fontFamily:'var(--font-mono)', fontSize:12 }}>{sale.receiptNumber}</td>
                  <td style={{ padding:'12px 16px', color:'var(--text-secondary)' }}>{sale.cashierId?.name || '—'}</td>
                  <td style={{ padding:'12px 16px', fontFamily:'var(--font-mono)', color:'var(--accent)', fontWeight:600 }}>{fmt.currency(sale.grandTotal)}</td>
                  <td style={{ padding:'12px 16px', color:'var(--text-muted)', fontSize:12 }}>{fmt.dateTime(sale.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Recent Inventory Activity */}
        <div style={{ background:'var(--bg-surface)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', overflow:'hidden' }}>
          <div style={{ padding:'16px 20px', borderBottom:'1px solid var(--border)', fontWeight:700, fontSize:14 }}>
            Inventory Activity
          </div>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
            <thead>
              <tr>
                {['Item','Type','Change','Who'].map(h => (
                  <th key={h} style={{ padding:'10px 16px', textAlign:'left', fontSize:10, color:'var(--text-muted)', fontFamily:'var(--font-mono)', letterSpacing:1, textTransform:'uppercase', fontWeight:600 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(summary?.recentInventoryActivity || []).map(log => (
                <tr key={log._id} style={{ borderTop:'1px solid rgba(255,255,255,0.03)' }}>
                  <td style={{ padding:'10px 16px', maxWidth:140 }}>
                    <div style={{ fontWeight:600, fontSize:12, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{log.productName}</div>
                    <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text-muted)' }}>{log.sku}</div>
                  </td>
                  <td style={{ padding:'10px 16px' }}>
                    <Badge status={log.type === 'sale' ? 'completed' : 'pending'} label={log.type.replace(/_/g,' ')} />
                  </td>
                  <td style={{ padding:'10px 16px', fontFamily:'var(--font-mono)', fontWeight:700, color: log.quantityChange > 0 ? 'var(--green)' : 'var(--red)' }}>
                    {log.quantityChange > 0 ? '+' : ''}{log.quantityChange}
                  </td>
                  <td style={{ padding:'10px 16px', color:'var(--text-muted)', fontSize:12 }}>{log.performedBy?.name || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppLayout>
  );
}
