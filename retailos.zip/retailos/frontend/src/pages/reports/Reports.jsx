import React, { useState, useEffect, useCallback } from 'react';
import {
  BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import AppLayout from '../../components/layout/AppLayout';
import { StatCard, LoadingScreen, DataTable } from '../../components/shared';
import { reportsApi } from '../../api';
import { fmt } from '../../utils';

const COLORS = ['#ffb932','#3b82f6','#22c55e','#a855f7','#ef4444','#06b6d4'];
const PERIODS = [
  { label: 'Last 7 days',  days: 7  },
  { label: 'Last 30 days', days: 30 },
  { label: 'Last 90 days', days: 90 },
];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background:'var(--bg-elevated)', border:'1px solid var(--border)', borderRadius:8, padding:'10px 14px', fontSize:12 }}>
      <p style={{ color:'var(--text-muted)', marginBottom:4 }}>{label}</p>
      {payload.map(p => (
        <p key={p.name} style={{ color: p.color || 'var(--text-primary)', fontFamily:'var(--font-mono)' }}>
          {p.name}: {typeof p.value === 'number' && p.value > 100 ? fmt.currency(p.value) : p.value}
        </p>
      ))}
    </div>
  );
};

export default function Reports() {
  const [period, setPeriod]       = useState(30);
  const [loading, setLoading]     = useState(true);
  const [summary, setSummary]     = useState(null);
  const [daily, setDaily]         = useState([]);
  const [topProducts, setTopProducts] = useState([]);
  const [payMethods, setPayMethods]   = useState([]);
  const [cashiers, setCashiers]       = useState([]);

  const fromDate = useCallback(() => {
    const d = new Date(Date.now() - (period - 1) * 86400000);
    return d.toISOString().slice(0, 10);
  }, [period]);

  const load = useCallback(async () => {
    setLoading(true);
    const params = { from: fromDate() };
    try {
      const [sRes, dRes, pRes, pmRes, cRes] = await Promise.all([
        reportsApi.salesSummary(params),
        reportsApi.dailySales(params),
        reportsApi.topProducts({ ...params, limit: 10 }),
        reportsApi.paymentMethods(params),
        reportsApi.cashierPerf(params),
      ]);
      setSummary(sRes.data.data);
      setDaily(dRes.data.data?.days || []);
      setTopProducts(pRes.data.data?.products || []);
      setPayMethods(pmRes.data.data?.breakdown || []);
      setCashiers(cRes.data.data?.cashiers || []);
    } finally { setLoading(false); }
  }, [fromDate]);

  useEffect(() => { load(); }, [load]);

  const dailyChart = daily.map(d => ({
    date:     new Date(d._id).toLocaleDateString('en-US', { month:'short', day:'numeric' }),
    Revenue:  parseFloat(d.revenue.toFixed(2)),
    Transactions: d.transactions,
  }));

  const pieData = payMethods.map(pm => ({
    name:  pm._id.charAt(0).toUpperCase() + pm._id.slice(1).replace(/_/g,' '),
    value: parseFloat(pm.total.toFixed(2)),
    count: pm.count,
  }));

  const topCols = [
    { key:'rank', label:'#', render:(_, i) => <span className="td-mono">{i + 1}</span> },
    { key:'productName', label:'Product', render: p => <div><div style={{ fontWeight:600 }}>{p.productName}</div><div className="td-mono" style={{ fontSize:11, color:'var(--text-muted)' }}>{p.sku}</div></div> },
    { key:'totalQtySold', label:'Units', render: p => <span className="td-mono">{p.totalQtySold}</span> },
    { key:'totalRevenue', label:'Revenue', render: p => <span className="td-mono" style={{ fontWeight:700 }}>{fmt.currency(p.totalRevenue)}</span> },
    { key:'totalProfit', label:'Profit', render: p => <span className="td-mono" style={{ color:'var(--green)' }}>{fmt.currency(p.totalProfit)}</span> },
  ];

  const cashierCols = [
    { key:'name', label:'Cashier', render: c => c.cashier?.name || '—' },
    { key:'transactions', label:'Transactions', render: c => <span className="td-mono">{c.transactions}</span> },
    { key:'totalRevenue', label:'Revenue', render: c => <span className="td-mono" style={{ fontWeight:700 }}>{fmt.currency(c.totalRevenue)}</span> },
    { key:'avgOrder', label:'Avg Order', render: c => <span className="td-mono">{fmt.currency(c.avgOrder)}</span> },
  ];

  if (loading && !summary) return <AppLayout title="Reports"><LoadingScreen /></AppLayout>;

  return (
    <AppLayout title="Reports" actions={
      <div className="flex items-center gap-2">
        {PERIODS.map(p => (
          <button
            key={p.days}
            className={`btn ${period === p.days ? 'btn-primary' : 'btn-ghost'}`}
            style={{ fontSize:12 }}
            onClick={() => setPeriod(p.days)}
          >
            {p.label}
          </button>
        ))}
      </div>
    }>
      {/* KPI Row */}
      {summary && (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16, marginBottom:24 }}>
          <StatCard label="Net Revenue"    value={fmt.currency(summary.netRevenue)}      accentColor="var(--accent)" />
          <StatCard label="Transactions"   value={fmt.number(summary.totalTransactions)} accentColor="var(--blue)" />
          <StatCard label="Total Refunds"  value={fmt.currency(summary.totalRefunds)}    accentColor="var(--red)" />
          <StatCard label="Avg Order Value" value={fmt.currency(summary.avgOrderValue)}  accentColor="var(--green)" />
        </div>
      )}

      {/* Secondary KPIs */}
      {summary && (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:16, marginBottom:24 }}>
          {[
            ['Items Sold',      fmt.number(summary.totalItemsSold)],
            ['Total Discount',  fmt.currency(summary.totalDiscount)],
            ['Total Tax',       fmt.currency(summary.totalTax)],
          ].map(([l, v]) => (
            <div key={l} style={{ background:'var(--bg-surface)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'18px 20px' }}>
              <p style={{ fontSize:12, color:'var(--text-muted)', marginBottom:6 }}>{l}</p>
              <p style={{ fontSize:22, fontWeight:800, fontFamily:'var(--font-mono)' }}>{v}</p>
            </div>
          ))}
        </div>
      )}

      {/* Charts Row */}
      <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr', gap:16, marginBottom:24 }}>
        <div style={{ background:'var(--bg-surface)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'20px 20px 12px' }}>
          <p style={{ fontWeight:700, fontSize:14, marginBottom:16 }}>Daily Revenue</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={dailyChart} margin={{ top:5, right:5, left:5, bottom:0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false}/>
              <XAxis dataKey="date" tick={{ fontSize:10, fill:'var(--text-muted)' }} axisLine={false} tickLine={false} interval="preserveStartEnd"/>
              <YAxis tick={{ fontSize:10, fill:'var(--text-muted)' }} axisLine={false} tickLine={false} tickFormatter={v => `$${v >= 1000 ? (v/1000).toFixed(0)+'k' : v}`}/>
              <Tooltip content={<CustomTooltip />}/>
              <Bar dataKey="Revenue" fill="var(--accent)" radius={[3,3,0,0]} maxBarSize={24}/>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div style={{ background:'var(--bg-surface)', border:'1px solid var(--border)', borderRadius:'var(--radius-lg)', padding:'20px 20px 12px' }}>
          <p style={{ fontWeight:700, fontSize:14, marginBottom:16 }}>Payment Methods</p>
          {pieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="45%" outerRadius={70} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={11}>
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]}/>)}
                </Pie>
                <Tooltip formatter={(v) => fmt.currency(v)} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div style={{ height:220, display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:13 }}>No data</div>
          )}
        </div>
      </div>

      {/* Tables Row */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
        <div>
          <p style={{ fontWeight:700, fontSize:14, marginBottom:12 }}>Top Products by Revenue</p>
          <DataTable
            columns={topCols}
            data={topProducts.map((p, i) => ({ ...p, _id: p._id || i }))}
            loading={loading}
            emptyMessage="No sales data."
          />
        </div>
        <div>
          <p style={{ fontWeight:700, fontSize:14, marginBottom:12 }}>Cashier Performance</p>
          <DataTable
            columns={cashierCols}
            data={cashiers.map(c => ({ ...c, _id: c._id }))}
            loading={loading}
            emptyMessage="No cashier data."
          />
        </div>
      </div>
    </AppLayout>
  );
}
