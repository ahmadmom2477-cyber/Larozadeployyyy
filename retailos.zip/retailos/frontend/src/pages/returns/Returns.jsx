import React, { useState, useEffect, useCallback } from 'react';
import AppLayout from '../../components/layout/AppLayout';
import { DataTable, Pagination, Modal, Badge, Spinner, FormField } from '../../components/shared';
import { returnsApi, salesApi } from '../../api';
import { fmt, errMsg } from '../../utils';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';

const REASONS    = ['defective','wrong_item','customer_changed_mind','damaged_in_transit','duplicate_purchase','other'];
const CONDITIONS = ['resalable','damaged','disposed'];
const REFUND_METHODS = ['original_payment','cash','store_credit','bank_transfer'];

function CreateReturnModal({ open, onClose, onSuccess }) {
  const [step, setStep]           = useState(1);
  const [receiptNum, setReceiptNum] = useState('');
  const [sale, setSale]           = useState(null);
  const [searchLoading, setSearchLoading] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);
  const [reason, setReason]       = useState('defective');
  const [reasonDetail, setReasonDetail] = useState('');
  const [refundMethod, setRefundMethod] = useState('original_payment');
  const [loading, setLoading]     = useState(false);
  const { toast } = useToast();

  const reset = () => {
    setStep(1); setReceiptNum(''); setSale(null);
    setSelectedItems([]); setReason('defective');
    setReasonDetail(''); setRefundMethod('original_payment');
  };

  const handleClose = () => { reset(); onClose(); };

  const lookupSale = async () => {
    if (!receiptNum.trim()) return toast('Enter a receipt number.', 'error');
    setSearchLoading(true);
    try {
      const res = await salesApi.byReceipt(receiptNum.trim());
      const s = res.data.data.sale;
      if (['voided','refunded'].includes(s.status)) {
        return toast(`Cannot return items from a ${s.status} sale.`, 'error');
      }
      setSale(s);
      setSelectedItems(s.items.map(i => ({ ...i, returnQty: 0, condition: 'resalable', selected: false })));
      setStep(2);
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setSearchLoading(false); }
  };

  const toggleItem = (idx) => {
    setSelectedItems(prev => prev.map((i, n) => n === idx ? { ...i, selected: !i.selected, returnQty: i.selected ? 0 : 1 } : i));
  };

  const setItemQty = (idx, qty) => {
    setSelectedItems(prev => prev.map((i, n) => n === idx ? { ...i, returnQty: Math.max(0, Math.min(qty, i.quantity)) } : i));
  };

  const setItemCond = (idx, condition) => {
    setSelectedItems(prev => prev.map((i, n) => n === idx ? { ...i, condition } : i));
  };

  const handleSubmit = async () => {
    const items = selectedItems.filter(i => i.selected && i.returnQty > 0).map(i => ({
      productId: i.productId, variantId: i.variantId || undefined,
      returnQuantity: i.returnQty, condition: i.condition,
    }));
    if (!items.length) return toast('Select at least one item to return.', 'error');
    setLoading(true);
    try {
      await returnsApi.create({ saleId: sale._id, items, reason, reasonDetail, refundMethod });
      toast('Return processed successfully.', 'success');
      handleClose();
      onSuccess();
    } catch (err) { toast(errMsg(err), 'error'); }
    finally { setLoading(false); }
  };

  const refundTotal = selectedItems
    .filter(i => i.selected && i.returnQty > 0)
    .reduce((s, i) => s + i.unitPrice * i.returnQty, 0);

  if (!open) return null;

  return (
    <Modal open={open} onClose={handleClose} title="Process Return" size="modal-lg">
      {step === 1 && (
        <div>
          <FormField label="Receipt Number" required>
            <input className="form-input" value={receiptNum} onChange={e => setReceiptNum(e.target.value.toUpperCase())}
              placeholder="RCP-20240101-XXXX" autoFocus
              onKeyDown={e => e.key === 'Enter' && lookupSale()}
            />
          </FormField>
          <div className="flex justify-end gap-2">
            <button className="btn btn-ghost" onClick={handleClose}>Cancel</button>
            <button className="btn btn-primary" onClick={lookupSale} disabled={searchLoading}>
              {searchLoading ? <Spinner size={14} /> : 'Look Up Sale'}
            </button>
          </div>
        </div>
      )}

      {step === 2 && sale && (
        <div>
          <div style={{ background:'var(--bg-overlay)', borderRadius:'var(--radius-md)', padding:'12px 16px', marginBottom:20, fontSize:13 }}>
            <strong>Sale:</strong> {sale.receiptNumber} · {fmt.dateTime(sale.createdAt)} ·{' '}
            <span style={{ fontFamily:'var(--font-mono)' }}>{fmt.currency(sale.grandTotal)}</span>
          </div>

          <p style={{ fontWeight:700, fontSize:13, marginBottom:10 }}>Select Items to Return</p>
          <div style={{ marginBottom:20, maxHeight:240, overflowY:'auto', display:'flex', flexDirection:'column', gap:8 }}>
            {selectedItems.map((item, idx) => (
              <div key={idx} style={{ background:'var(--bg-overlay)', borderRadius:'var(--radius-md)', padding:12, border:`1px solid ${item.selected ? 'var(--accent)' : 'var(--border)'}` }}>
                <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom: item.selected ? 10 : 0 }}>
                  <input type="checkbox" checked={item.selected} onChange={() => toggleItem(idx)} />
                  <span style={{ fontWeight:600, flex:1 }}>{item.productName}</span>
                  <span className="td-mono" style={{ fontSize:12, color:'var(--text-muted)' }}>Max: {item.quantity}</span>
                  <span className="td-mono">{fmt.currency(item.unitPrice)}</span>
                </div>
                {item.selected && (
                  <div className="grid-2" style={{ gap:8 }}>
                    <div>
                      <label className="form-label" style={{ fontSize:11 }}>Return Qty</label>
                      <input className="form-input" type="number" min="1" max={item.quantity} value={item.returnQty}
                        onChange={e => setItemQty(idx, parseInt(e.target.value) || 0)} style={{ padding:'6px 10px', fontSize:12 }} />
                    </div>
                    <div>
                      <label className="form-label" style={{ fontSize:11 }}>Condition</label>
                      <select className="form-select" value={item.condition} onChange={e => setItemCond(idx, e.target.value)} style={{ padding:'6px 10px', fontSize:12 }}>
                        {CONDITIONS.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="grid-2" style={{ marginBottom:16 }}>
            <FormField label="Reason" required>
              <select className="form-select" value={reason} onChange={e => setReason(e.target.value)}>
                {REASONS.map(r => <option key={r} value={r}>{r.replace(/_/g,' ')}</option>)}
              </select>
            </FormField>
            <FormField label="Refund Method">
              <select className="form-select" value={refundMethod} onChange={e => setRefundMethod(e.target.value)}>
                {REFUND_METHODS.map(m => <option key={m} value={m}>{m.replace(/_/g,' ')}</option>)}
              </select>
            </FormField>
          </div>

          <FormField label="Additional Notes">
            <input className="form-input" value={reasonDetail} onChange={e => setReasonDetail(e.target.value)} placeholder="Optional details…" />
          </FormField>

          {refundTotal > 0 && (
            <div style={{ background:'var(--blue-dim)', borderRadius:'var(--radius-md)', padding:'12px 16px', marginBottom:16, fontSize:13 }}>
              Estimated refund: <strong className="td-mono">{fmt.currency(refundTotal)}</strong>
            </div>
          )}

          <div className="flex justify-end gap-2">
            <button className="btn btn-ghost" onClick={() => setStep(1)}>Back</button>
            <button className="btn btn-primary" onClick={handleSubmit} disabled={loading}>
              {loading ? <Spinner size={14} /> : 'Process Return'}
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
}

export default function Returns() {
  const [returns, setReturns] = useState([]);
  const [total, setTotal]     = useState(0);
  const [page, setPage]       = useState(1);
  const [loading, setLoading] = useState(true);
  const [detail, setDetail]   = useState(null);
  const [createOpen, setCreateOpen] = useState(false);
  const LIMIT = 20;

  const { toast }   = useToast();
  const { hasRole } = useAuth();

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await returnsApi.list({ page, limit: LIMIT });
      setReturns(res.data.data || []);
      setTotal(res.data.pagination?.total || 0);
    } catch { toast('Failed to load returns.', 'error'); }
    finally { setLoading(false); }
  }, [page, toast]);

  useEffect(() => { load(); }, [load]);

  const handleStatusUpdate = async (id, status) => {
    try {
      await returnsApi.updateStatus(id, status);
      toast(`Return marked as ${status}.`, 'success');
      setDetail(null);
      load();
    } catch (err) { toast(errMsg(err), 'error'); }
  };

  const columns = [
    { key:'returnNumber', label:'Return #', render: r => <span className="td-mono">{r.returnNumber}</span> },
    { key:'sale', label:'Original Sale', render: r => <span className="td-mono" style={{ fontSize:12 }}>{r.saleId?.receiptNumber || '—'}</span> },
    { key:'processedBy', label:'By', render: r => r.processedBy?.name || '—' },
    { key:'reason', label:'Reason', render: r => <span style={{ fontSize:12, color:'var(--text-muted)' }}>{r.reason?.replace(/_/g,' ')}</span> },
    { key:'refundAmount', label:'Refund', render: r => <span className="td-mono" style={{ color:'var(--blue)', fontWeight:700 }}>{fmt.currency(r.totalRefundAmount)}</span> },
    { key:'refundMethod', label:'Method', render: r => <span style={{ fontSize:12 }}>{r.refundMethod?.replace(/_/g,' ') || '—'}</span> },
    { key:'status', label:'Status', render: r => <Badge status={r.status} label={r.status.replace(/_/g,' ')} /> },
    { key:'date', label:'Date', render: r => <span style={{ color:'var(--text-muted)', fontSize:12 }}>{fmt.dateTime(r.createdAt)}</span> },
    { key:'actions', label:'', render: r => (
        <button className="btn btn-ghost btn-sm" onClick={() => setDetail(r)}>View</button>
      )},
  ];

  return (
    <AppLayout title="Returns" actions={
      <button className="btn btn-primary" onClick={() => setCreateOpen(true)}>+ Process Return</button>
    }>
      <DataTable columns={columns} data={returns} loading={loading} emptyMessage="No returns found." />
      <Pagination page={page} pages={Math.ceil(total / LIMIT)} total={total} limit={LIMIT} onPage={setPage} />

      <CreateReturnModal open={createOpen} onClose={() => setCreateOpen(false)} onSuccess={load} />

      {/* Detail Modal */}
      <Modal open={!!detail} onClose={() => setDetail(null)} title={`Return — ${detail?.returnNumber}`} size="modal-lg">
        {detail && (
          <div>
            <div className="grid-2" style={{ marginBottom:16 }}>
              <div><p className="text-muted" style={{ fontSize:11 }}>ORIGINAL SALE</p><p className="td-mono">{detail.saleId?.receiptNumber}</p></div>
              <div><p className="text-muted" style={{ fontSize:11 }}>STATUS</p><Badge status={detail.status} label={detail.status.replace(/_/g,' ')} /></div>
              <div><p className="text-muted" style={{ fontSize:11 }}>REASON</p><p>{detail.reason?.replace(/_/g,' ')}</p></div>
              <div><p className="text-muted" style={{ fontSize:11 }}>REFUND</p><p className="td-mono" style={{ color:'var(--blue)', fontWeight:700 }}>{fmt.currency(detail.totalRefundAmount)}</p></div>
            </div>

            <div className="table-container" style={{ marginBottom:16 }}>
              <table>
                <thead><tr>{['Product','Returned','Condition','Restocked','Refund'].map(h => <th key={h}>{h}</th>)}</tr></thead>
                <tbody>
                  {detail.items?.map((item, i) => (
                    <tr key={i}>
                      <td><div style={{ fontWeight:600 }}>{item.productName}</div><div className="td-mono" style={{ fontSize:11, color:'var(--text-muted)' }}>{item.sku}</div></td>
                      <td className="td-mono">{item.returnQuantity} of {item.originalQuantity}</td>
                      <td><Badge status={item.condition === 'resalable' ? 'completed' : 'rejected'} label={item.condition} /></td>
                      <td>{item.restocked ? '✅' : '—'}</td>
                      <td className="td-mono" style={{ fontWeight:700 }}>{fmt.currency(item.refundAmount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {hasRole('admin','manager') && detail.status === 'approved' && (
              <div className="flex justify-end gap-2">
                <button className="btn btn-ghost" style={{ color:'var(--red)' }} onClick={() => handleStatusUpdate(detail._id, 'rejected')}>Reject</button>
                <button className="btn btn-primary" onClick={() => handleStatusUpdate(detail._id, 'refund_issued')}>Mark Refund Issued</button>
              </div>
            )}
          </div>
        )}
      </Modal>
    </AppLayout>
  );
}
