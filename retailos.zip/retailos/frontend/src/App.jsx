import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { CartProvider } from './context/CartContext';

import Login        from './pages/auth/Login';
import Dashboard    from './pages/dashboard/Dashboard';
import Products     from './pages/products/Products';
import Inventory    from './pages/inventory/Inventory';
import POS          from './pages/pos/POS';
import SalesHistory from './pages/sales/SalesHistory';
import Returns      from './pages/returns/Returns';
import Exchanges    from './pages/exchanges/Exchanges';
import Reports      from './pages/reports/Reports';
import Users        from './pages/users/Users';

function ProtectedRoute({ children, roles }) {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100vh' }}>
      <div className="spinner" style={{ width:32, height:32 }} />
    </div>
  );
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/dashboard" replace />;
  return children;
}

function AppRoutes() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <Login />} />

      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/pos"       element={<ProtectedRoute><POS /></ProtectedRoute>} />
      <Route path="/products"  element={<ProtectedRoute><Products /></ProtectedRoute>} />
      <Route path="/inventory" element={<ProtectedRoute><Inventory /></ProtectedRoute>} />
      <Route path="/sales"     element={<ProtectedRoute><SalesHistory /></ProtectedRoute>} />
      <Route path="/returns"   element={<ProtectedRoute><Returns /></ProtectedRoute>} />
      <Route path="/exchanges" element={<ProtectedRoute><Exchanges /></ProtectedRoute>} />
      <Route path="/reports"   element={<ProtectedRoute roles={['admin','manager']}><Reports /></ProtectedRoute>} />
      <Route path="/users"     element={<ProtectedRoute roles={['admin']}><Users /></ProtectedRoute>} />

      <Route path="/"  element={<Navigate to="/dashboard" />} />
      <Route path="*"  element={<Navigate to="/dashboard" />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <CartProvider>
            <AppRoutes />
          </CartProvider>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
