import api from './axiosInstance';

export const authApi = {
  login:          (email, password) => api.post('/auth/login', { email, password }),
  me:             ()                => api.get('/auth/me'),
  logout:         ()                => api.post('/auth/logout'),
  changePassword: (data)            => api.patch('/auth/change-password', data),
};

export const productsApi = {
  list:      (params)     => api.get('/products', { params }),
  get:       (id)         => api.get(`/products/${id}`),
  bySku:     (sku)        => api.get(`/products/sku/${sku}`),
  byBarcode: (barcode)    => api.get(`/products/barcode/${barcode}`),
  create:    (data)       => api.post('/products', data),
  update:    (id, data)   => api.put(`/products/${id}`, data),
  delete:    (id)         => api.delete(`/products/${id}`),
  lowStock:  (params)     => api.get('/products/low-stock', { params }),
};

export const inventoryApi = {
  getLogs:        (params)     => api.get('/inventory/logs', { params }),
  getProductLogs: (id, params) => api.get(`/inventory/logs/product/${id}`, { params }),
  getLowStock:    (params)     => api.get('/inventory/low-stock', { params }),
  getValuation:   ()           => api.get('/inventory/valuation'),
  adjust:         (data)       => api.post('/inventory/adjust', data),
};

export const salesApi = {
  list:      (params)     => api.get('/sales', { params }),
  get:       (id)         => api.get(`/sales/${id}`),
  byReceipt: (num)        => api.get(`/sales/receipt/${num}`),
  create:    (data)       => api.post('/sales', data),
  void:      (id, reason) => api.patch(`/sales/${id}/void`, { reason }),
};

export const returnsApi = {
  list:         (params)        => api.get('/returns', { params }),
  get:          (id)            => api.get(`/returns/${id}`),
  create:       (data)          => api.post('/returns', data),
  updateStatus: (id, status)    => api.patch(`/returns/${id}/status`, { status }),
};

export const exchangesApi = {
  list:   (params) => api.get('/exchanges', { params }),
  get:    (id)     => api.get(`/exchanges/${id}`),
  create: (data)   => api.post('/exchanges', data),
};

export const reportsApi = {
  salesSummary:  (params) => api.get('/reports/sales-summary', { params }),
  dailySales:    (params) => api.get('/reports/daily-sales', { params }),
  topProducts:   (params) => api.get('/reports/top-products', { params }),
  paymentMethods:(params) => api.get('/reports/payment-methods', { params }),
  cashierPerf:   (params) => api.get('/reports/cashier-performance', { params }),
  stockMovements:(params) => api.get('/reports/stock-movements', { params }),
  valuation:     ()       => api.get('/reports/inventory-valuation'),
};

export const dashboardApi = {
  summary: () => api.get('/dashboard/summary'),
};

export const cashierApi = {
  searchProducts: (q) => api.get('/cashier/products/search', { params: { q } }),
  mySales:        ()  => api.get('/cashier/my-sales'),
  shiftSummary:   ()  => api.get('/cashier/shift-summary'),
};

export const usersApi = {
  list:          (params)     => api.get('/users', { params }),
  get:           (id)         => api.get(`/users/${id}`),
  create:        (data)       => api.post('/users', data),
  update:        (id, data)   => api.put(`/users/${id}`, data),
  resetPassword: (id, newPassword) => api.patch(`/users/${id}/reset-password`, { newPassword }),
  deactivate:    (id)         => api.patch(`/users/${id}/deactivate`),
};
