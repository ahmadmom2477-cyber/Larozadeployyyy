import React, { createContext, useContext, useReducer, useCallback } from 'react';

const CartContext = createContext(null);

const cartReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_ITEM': {
      const key      = `${action.product._id}__${action.variantId || 'base'}`;
      const existing = state.items.find(i => i.key === key);
      if (existing) {
        return {
          ...state,
          items: state.items.map(i =>
            i.key === key
              ? { ...i, quantity: Math.min(i.quantity + 1, i.stock) }
              : i
          ),
        };
      }
      const p       = action.product;
      const variant = action.variantId ? p.variants?.find(v => v._id === action.variantId) : null;
      return {
        ...state,
        items: [...state.items, {
          key,
          productId:     p._id,
          variantId:     action.variantId || null,
          productName:   p.name,
          sku:           variant ? variant.sku : p.sku,
          unitPrice:     variant ? variant.sellingPrice : p.sellingPrice,
          costPrice:     variant ? variant.costPrice    : p.costPrice,
          taxRate:       p.taxRate || 0,
          stock:         variant ? (variant.stock || 0) : p.totalStock,
          quantity:      1,
          discountType:  'none',
          discountValue: 0,
        }],
      };
    }
    case 'REMOVE_ITEM':
      return { ...state, items: state.items.filter(i => i.key !== action.key) };
    case 'SET_QTY': {
      const qty = Math.max(1, Math.min(action.qty, action.stock));
      return { ...state, items: state.items.map(i => i.key === action.key ? { ...i, quantity: qty } : i) };
    }
    case 'SET_DISCOUNT':
      return {
        ...state,
        items: state.items.map(i =>
          i.key === action.key
            ? { ...i, discountType: action.discountType, discountValue: action.discountValue }
            : i
        ),
      };
    case 'SET_CUSTOMER':
      return { ...state, customerId: action.customerId };
    case 'SET_NOTE':
      return { ...state, note: action.note };
    case 'CLEAR':
      return { items: [], customerId: null, note: '' };
    default:
      return state;
  }
};

const initialState = { items: [], customerId: null, note: '' };

export function CartProvider({ children }) {
  const [cart, dispatch] = useReducer(cartReducer, initialState);

  const addItem     = useCallback((product, variantId) => dispatch({ type: 'ADD_ITEM', product, variantId }), []);
  const removeItem  = useCallback((key) => dispatch({ type: 'REMOVE_ITEM', key }), []);
  const setQty      = useCallback((key, qty, stock) => dispatch({ type: 'SET_QTY', key, qty, stock }), []);
  const setDiscount = useCallback((key, discountType, discountValue) => dispatch({ type: 'SET_DISCOUNT', key, discountType, discountValue }), []);
  const clearCart   = useCallback(() => dispatch({ type: 'CLEAR' }), []);

  const lineCalc = (item) => {
    const gross = item.unitPrice * item.quantity;
    let disc = 0;
    if (item.discountType === 'percentage') disc = gross * item.discountValue / 100;
    if (item.discountType === 'fixed')      disc = Math.min(item.discountValue, gross);
    const subtotal = gross - disc;
    return { subtotal, tax: subtotal * item.taxRate / 100 };
  };

  const subtotal   = cart.items.reduce((s, i) => s + lineCalc(i).subtotal, 0);
  const taxTotal   = cart.items.reduce((s, i) => s + lineCalc(i).tax, 0);
  const grandTotal = subtotal + taxTotal;

  return (
    <CartContext.Provider value={{
      cart, addItem, removeItem, setQty, setDiscount, clearCart,
      subtotal, taxTotal, grandTotal,
    }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
