import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const icons = {
  dashboard: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>,
  pos:       <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>,
  products:  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M21 16V8a2 2 0 00-1-1.73L13 2.27a2 2 0 00-2 0L4 6.27A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>,
  inventory: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M3 3h18M3 9h18M3 15h18M3 21h18M9 3v18M15 3v18"/></svg>,
  sales:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4"/></svg>,
  returns:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M3 12a9 9 0 109-9"/><path d="M3 3v9h9"/></svg>,
  exchanges: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M7 16V4m0 0L3 8m4-4l4 4M17 8v12m0 0l4-4m-4 4l-4-4"/></svg>,
  reports:   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M18 20V10M12 20V4M6 20v-6"/></svg>,
  users:     <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>,
  logout:    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>,
};

const navItems = [
  { path: '/dashboard', label: 'Dashboard',     icon: 'dashboard', section: 'OVERVIEW' },
  { path: '/pos',       label: 'POS Terminal',  icon: 'pos',       section: 'OPERATIONS' },
  { path: '/sales',     label: 'Sales History', icon: 'sales',     section: 'OPERATIONS' },
  { path: '/returns',   label: 'Returns',       icon: 'returns',   section: 'OPERATIONS' },
  { path: '/exchanges', label: 'Exchanges',     icon: 'exchanges', section: 'OPERATIONS' },
  { path: '/products',  label: 'Products',      icon: 'products',  section: 'CATALOGUE' },
  { path: '/inventory', label: 'Inventory',     icon: 'inventory', section: 'CATALOGUE' },
  { path: '/reports',   label: 'Reports',       icon: 'reports',   section: 'ANALYTICS', roles: ['admin','manager'] },
  { path: '/users',     label: 'Users',         icon: 'users',     section: 'ADMIN',     roles: ['admin'] },
];

export default function Sidebar() {
  const { user, logout, hasRole } = useAuth();
  const navigate  = useNavigate();
  const location  = useLocation();
  let lastSection = '';

  const initials = user?.name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || '??';

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-mark">POS</div>
        <div>
          <div className="logo-text">RetailOS</div>
          <div className="logo-sub">Point of Sale</div>
        </div>
      </div>

      <nav className="sidebar-nav">
        {navItems.map(item => {
          if (item.roles && !hasRole(...item.roles)) return null;

          const showSection = item.section !== lastSection;
          if (showSection) lastSection = item.section;
          const isActive = location.pathname.startsWith(item.path);

          return (
            <React.Fragment key={item.path}>
              {showSection && <div className="nav-section-label">{item.section}</div>}
              <div
                className={`nav-item ${isActive ? 'active' : ''}`}
                onClick={() => navigate(item.path)}
              >
                {icons[item.icon]}
                {item.label}
              </div>
            </React.Fragment>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="user-card" onClick={logout}>
          <div className="user-avatar">{initials}</div>
          <div className="user-info">
            <div className="user-name">{user?.name || 'User'}</div>
            <div className="user-role">{user?.role || 'staff'}</div>
          </div>
          <div style={{ color: 'var(--text-muted)', display: 'flex' }}>{icons.logout}</div>
        </div>
      </div>
    </aside>
  );
}
