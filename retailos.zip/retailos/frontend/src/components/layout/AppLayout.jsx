import React from 'react';
import Sidebar from './Sidebar';

export default function AppLayout({ children, title, actions }) {
  return (
    <div className="app-shell">
      <Sidebar />
      <div className="main-content">
        <header className="topbar">
          <h1 className="page-title">{title}</h1>
          <div className="topbar-actions">{actions}</div>
        </header>
        <main className="page-body animate-in">
          {children}
        </main>
      </div>
    </div>
  );
}
