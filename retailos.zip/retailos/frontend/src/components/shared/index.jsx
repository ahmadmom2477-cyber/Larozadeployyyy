import React from 'react';
import { statusBadge } from '../../utils';

export function Spinner({ size = 20 }) {
  return <div className="spinner" style={{ width: size, height: size }} />;
}

export function LoadingScreen() {
  return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'60vh' }}>
      <Spinner size={32} />
    </div>
  );
}

export function EmptyState({ message = 'No data found.', icon }) {
  return (
    <div className="empty-state">
      {icon || (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7M4 13h16M8 13v7M16 13v7"/>
        </svg>
      )}
      <p>{message}</p>
    </div>
  );
}

export function Badge({ status, label }) {
  const cls = statusBadge(status);
  return <span className={`badge ${cls}`}>{label || status}</span>;
}

export function StatCard({ label, value, delta, deltaLabel, icon, accentColor = 'var(--accent)', iconBg }) {
  const isUp = delta >= 0;
  return (
    <div className="stat-card" style={{ '--card-accent': accentColor, '--card-icon-bg': iconBg || accentColor + '20' }}>
      <div className="stat-icon">{icon}</div>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      {delta !== undefined && (
        <div className={`stat-delta ${isUp ? 'up' : 'down'}`}>
          <span>{isUp ? '▲' : '▼'}</span>
          <span>{deltaLabel || `${Math.abs(delta)}%`}</span>
        </div>
      )}
    </div>
  );
}

export function Modal({ open, onClose, title, children, size = 'modal-md' }) {
  if (!open) return null;
  return (
    <div className="modal-backdrop" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`modal ${size}`}>
        <div className="modal-header">
          <h2 className="modal-title">{title}</h2>
          <button className="btn btn-ghost btn-icon btn-sm" onClick={onClose}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6L6 18M6 6l12 12"/>
            </svg>
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function ConfirmModal({ open, onClose, onConfirm, title, message, confirmLabel = 'Confirm', danger = false, loading = false }) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="modal-sm">
      <p style={{ color: 'var(--text-secondary)', fontSize: 14, marginBottom: 24 }}>{message}</p>
      <div className="flex justify-end gap-2">
        <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button
          className={`btn ${danger ? 'btn-danger' : 'btn-primary'}`}
          onClick={onConfirm}
          disabled={loading}
        >
          {loading ? <Spinner size={14} /> : confirmLabel}
        </button>
      </div>
    </Modal>
  );
}

export function DataTable({ columns, data, loading, emptyMessage }) {
  return (
    <div className="table-container">
      <table>
        <thead>
          <tr>
            {columns.map(col => (
              <th key={col.key} style={col.style}>{col.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr>
              <td colSpan={columns.length} style={{ textAlign:'center', padding: 48 }}>
                <Spinner />
              </td>
            </tr>
          ) : !data?.length ? (
            <tr>
              <td colSpan={columns.length}>
                <EmptyState message={emptyMessage} />
              </td>
            </tr>
          ) : (
            data.map((row, i) => (
              <tr key={row._id || i}>
                {columns.map(col => (
                  <td key={col.key} style={col.tdStyle}>
                    {col.render ? col.render(row) : row[col.key]}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export function Pagination({ page, pages, total, limit, onPage }) {
  if (!pages || pages <= 1) return null;
  const from = ((page - 1) * limit) + 1;
  const to   = Math.min(page * limit, total);

  // Show at most 7 page buttons, centered on current page
  const getPageNums = () => {
    const range  = [];
    const delta  = 3;
    const left   = Math.max(1, page - delta);
    const right  = Math.min(pages, page + delta);
    for (let i = left; i <= right; i++) range.push(i);
    return range;
  };

  return (
    <div className="pagination">
      <span>Showing {from}–{to} of {total}</span>
      <div className="pagination-btns">
        <button className="page-btn" onClick={() => onPage(1)} disabled={page <= 1}>«</button>
        <button className="page-btn" onClick={() => onPage(page - 1)} disabled={page <= 1}>‹</button>
        {getPageNums().map(p => (
          <button key={p} className={`page-btn ${p === page ? 'active' : ''}`} onClick={() => onPage(p)}>
            {p}
          </button>
        ))}
        <button className="page-btn" onClick={() => onPage(page + 1)} disabled={page >= pages}>›</button>
        <button className="page-btn" onClick={() => onPage(pages)} disabled={page >= pages}>»</button>
      </div>
    </div>
  );
}

export function SearchInput({ value, onChange, placeholder = 'Search...' }) {
  return (
    <div className="search-bar" style={{ maxWidth: 300 }}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
      </svg>
      <input
        className="form-input"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
      />
    </div>
  );
}

export function FormField({ label, required, children, hint }) {
  return (
    <div className="form-group">
      <label className="form-label">{label}{required && <span style={{ color:'var(--red)' }}> *</span>}</label>
      {children}
      {hint && <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>{hint}</p>}
    </div>
  );
}
