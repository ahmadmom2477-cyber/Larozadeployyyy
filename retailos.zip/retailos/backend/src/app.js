const express        = require('express');
const cors           = require('cors');
const helmet         = require('helmet');
const cookieParser   = require('cookie-parser');
const mongoSanitize  = require('express-mongo-sanitize');
const morgan         = require('morgan');
const rateLimit      = require('express-rate-limit');

const errorHandler   = require('./middleware/errorHandler');
const notFound       = require('./middleware/notFound');

const authRoutes      = require('./modules/auth/auth.routes');
const productRoutes   = require('./modules/products/product.routes');
const inventoryRoutes = require('./modules/inventory/inventory.routes');
const salesRoutes     = require('./modules/sales/sale.routes');
const returnRoutes    = require('./modules/returns/return.routes');
const exchangeRoutes  = require('./modules/exchanges/exchange.routes');
const reportRoutes    = require('./modules/reports/report.routes');
const dashboardRoutes = require('./modules/dashboard/dashboard.routes');
const cashierRoutes   = require('./modules/cashier/cashier.routes');
const userRoutes      = require('./modules/users/user.routes');

const app = express();

// ── Security ──────────────────────────────────────────────────────────────────
app.use(helmet());
app.use(mongoSanitize());
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true,
}));

// ── Rate Limiting ─────────────────────────────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 500,
  message: { success: false, message: 'Too many requests, please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { success: false, message: 'Too many login attempts, please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/api', globalLimiter);
app.use('/api/auth/login', authLimiter);

// ── Parsing ───────────────────────────────────────────────────────────────────
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// ── Logging ───────────────────────────────────────────────────────────────────
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// ── Health Check ──────────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ── API Routes ────────────────────────────────────────────────────────────────
app.use('/api/auth',      authRoutes);
app.use('/api/products',  productRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/sales',     salesRoutes);
app.use('/api/returns',   returnRoutes);
app.use('/api/exchanges', exchangeRoutes);
app.use('/api/reports',   reportRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/cashier',   cashierRoutes);
app.use('/api/users',     userRoutes);

// ── Error Handling ────────────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

module.exports = app;
