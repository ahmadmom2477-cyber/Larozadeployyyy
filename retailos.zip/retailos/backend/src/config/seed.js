require('dotenv').config();
const mongoose = require('mongoose');
const User     = require('../models/user.model');
const Product  = require('../models/product.model');
const logger   = require('../utils/logger');

const CATEGORY_IDS = {
  electronics: new mongoose.Types.ObjectId(),
  clothing:    new mongoose.Types.ObjectId(),
  food:        new mongoose.Types.ObjectId(),
  beauty:      new mongoose.Types.ObjectId(),
  sports:      new mongoose.Types.ObjectId(),
};

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  logger.info('Connected to DB for seeding...');

  await User.deleteMany({});
  await Product.deleteMany({});

  // ── Users ─────────────────────────────────────────────────────────────────
  const users = await User.create([
    { name: 'Admin User',    email: 'admin@pos.com',   passwordHash: 'Admin@1234',   role: 'admin'   },
    { name: 'Store Manager', email: 'manager@pos.com', passwordHash: 'Manager@1234', role: 'manager' },
    { name: 'Jane Cashier',  email: 'cashier@pos.com', passwordHash: 'Cashier@1234', role: 'cashier' },
  ]);

  logger.info(`Seeded ${users.length} users.`);

  // ── Products ──────────────────────────────────────────────────────────────
  const products = await Product.create([
    // Electronics
    {
      name: 'USB-C Hub 7-in-1', slug: 'usb-c-hub-7-in-1',
      sku: 'EL-001', barcode: '8901234560001',
      categoryId: CATEGORY_IDS.electronics,
      costPrice: 18.50, sellingPrice: 39.99, taxRate: 8,
      totalStock: 45, reorderPoint: 10,
      description: '7-in-1 USB-C hub with HDMI, USB-A, SD card reader.',
      tags: ['usb', 'hub', 'accessories'],
    },
    {
      name: 'Wireless Earbuds Pro', slug: 'wireless-earbuds-pro',
      sku: 'EL-002', barcode: '8901234560002',
      categoryId: CATEGORY_IDS.electronics,
      costPrice: 22.00, sellingPrice: 59.99, taxRate: 8,
      totalStock: 30, reorderPoint: 8,
      description: 'True wireless earbuds with ANC and 24hr battery.',
    },
    {
      name: 'Mechanical Keyboard TKL', slug: 'mechanical-keyboard-tkl',
      sku: 'EL-003', barcode: '8901234560003',
      categoryId: CATEGORY_IDS.electronics,
      costPrice: 45.00, sellingPrice: 89.99, taxRate: 8,
      totalStock: 20, reorderPoint: 5,
      description: 'Tenkeyless mechanical keyboard, brown switches.',
    },
    {
      name: 'Screen Protector 6.1"', slug: 'screen-protector-61',
      sku: 'EL-004', barcode: '8901234560004',
      categoryId: CATEGORY_IDS.electronics,
      costPrice: 2.00, sellingPrice: 12.99, taxRate: 8,
      totalStock: 120, reorderPoint: 20,
    },
    {
      name: 'Laptop Stand Aluminium', slug: 'laptop-stand-aluminium',
      sku: 'EL-005', barcode: '8901234560005',
      categoryId: CATEGORY_IDS.electronics,
      costPrice: 14.00, sellingPrice: 34.99, taxRate: 8,
      totalStock: 25, reorderPoint: 5,
    },

    // Clothing
    {
      name: 'Classic White Tee', slug: 'classic-white-tee',
      sku: 'CL-001', barcode: '8901234561001',
      categoryId: CATEGORY_IDS.clothing,
      costPrice: 4.50, sellingPrice: 19.99, taxRate: 0,
      totalStock: 80, reorderPoint: 20,
      description: '100% combed cotton, unisex fit.',
    },
    {
      name: 'Slim Fit Chinos', slug: 'slim-fit-chinos',
      sku: 'CL-002', barcode: '8901234561002',
      categoryId: CATEGORY_IDS.clothing,
      costPrice: 12.00, sellingPrice: 44.99, taxRate: 0,
      totalStock: 35, reorderPoint: 10,
    },
    {
      name: 'Branded Hoodie', slug: 'branded-hoodie',
      sku: 'CL-003', barcode: '8901234561003',
      categoryId: CATEGORY_IDS.clothing,
      costPrice: 18.00, sellingPrice: 64.99, taxRate: 0,
      totalStock: 22, reorderPoint: 8,
    },
    {
      name: 'Running Socks 3-Pack', slug: 'running-socks-3-pack',
      sku: 'CL-004', barcode: '8901234561004',
      categoryId: CATEGORY_IDS.clothing,
      costPrice: 2.50, sellingPrice: 9.99, taxRate: 0,
      totalStock: 150, reorderPoint: 30,
    },

    // Food & Drink
    {
      name: 'Arabica Coffee Beans 250g', slug: 'arabica-coffee-beans-250g',
      sku: 'FD-001', barcode: '8901234562001',
      categoryId: CATEGORY_IDS.food,
      costPrice: 6.00, sellingPrice: 14.99, taxRate: 5,
      totalStock: 60, reorderPoint: 15, unit: 'pack',
    },
    {
      name: 'Organic Green Tea 20s', slug: 'organic-green-tea-20s',
      sku: 'FD-002', barcode: '8901234562002',
      categoryId: CATEGORY_IDS.food,
      costPrice: 3.00, sellingPrice: 8.99, taxRate: 5,
      totalStock: 75, reorderPoint: 20, unit: 'pack',
    },
    {
      name: 'Protein Bar Box 12x', slug: 'protein-bar-box-12x',
      sku: 'FD-003', barcode: '8901234562003',
      categoryId: CATEGORY_IDS.food,
      costPrice: 10.00, sellingPrice: 24.99, taxRate: 5,
      totalStock: 40, reorderPoint: 10, unit: 'box',
    },
    {
      name: 'Sparkling Water 6-Pack', slug: 'sparkling-water-6-pack',
      sku: 'FD-004', barcode: '8901234562004',
      categoryId: CATEGORY_IDS.food,
      costPrice: 2.00, sellingPrice: 5.99, taxRate: 5,
      totalStock: 90, reorderPoint: 20, unit: 'pack',
    },

    // Beauty
    {
      name: 'SPF50 Sunscreen 100ml', slug: 'spf50-sunscreen-100ml',
      sku: 'BE-001', barcode: '8901234563001',
      categoryId: CATEGORY_IDS.beauty,
      costPrice: 5.00, sellingPrice: 16.99, taxRate: 0,
      totalStock: 55, reorderPoint: 10, unit: 'ml',
    },
    {
      name: 'Vitamin C Serum 30ml', slug: 'vitamin-c-serum-30ml',
      sku: 'BE-002', barcode: '8901234563002',
      categoryId: CATEGORY_IDS.beauty,
      costPrice: 8.00, sellingPrice: 29.99, taxRate: 0,
      totalStock: 30, reorderPoint: 8,
    },

    // Sports
    {
      name: 'Resistance Band Set', slug: 'resistance-band-set',
      sku: 'SP-001', barcode: '8901234564001',
      categoryId: CATEGORY_IDS.sports,
      costPrice: 7.00, sellingPrice: 22.99, taxRate: 0,
      totalStock: 40, reorderPoint: 10,
    },
    {
      name: 'Yoga Mat 6mm', slug: 'yoga-mat-6mm',
      sku: 'SP-002', barcode: '8901234564002',
      categoryId: CATEGORY_IDS.sports,
      costPrice: 12.00, sellingPrice: 34.99, taxRate: 0,
      totalStock: 18, reorderPoint: 5,
    },
    {
      name: 'Jump Rope Speed', slug: 'jump-rope-speed',
      sku: 'SP-003', barcode: '8901234564003',
      categoryId: CATEGORY_IDS.sports,
      costPrice: 4.00, sellingPrice: 14.99, taxRate: 0,
      totalStock: 50, reorderPoint: 10,
    },
  ]);

  logger.info(`Seeded ${products.length} products.`);
  logger.info('');
  logger.info('Seed credentials:');
  logger.info('  admin@pos.com    / Admin@1234');
  logger.info('  manager@pos.com  / Manager@1234');
  logger.info('  cashier@pos.com  / Cashier@1234');
  logger.info('');
  logger.info('Sample barcodes for POS scanning:');
  products.slice(0, 5).forEach(p => logger.info(`  ${p.sku}: ${p.barcode}`));

  await mongoose.connection.close();
  logger.info('Seeding complete. DB connection closed.');
};

seed().catch((err) => {
  logger.error('Seed failed:', err);
  process.exit(1);
});
