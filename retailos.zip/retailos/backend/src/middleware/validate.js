const { AppError } = require('../utils/appError');

const validate = (schema, target = 'body') => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req[target], {
      abortEarly:    false,
      stripUnknown:  true,
      convert:       true,
    });

    if (error) {
      const message = error.details.map(d => d.message.replace(/"/g, "'")).join('. ');
      return next(new AppError(message, 400));
    }

    req[target] = value;
    next();
  };
};

module.exports = validate;
