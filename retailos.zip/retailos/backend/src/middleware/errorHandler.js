const logger = require('../utils/logger');

const handleCastError        = (err) => ({ statusCode: 400, message: `Invalid value for field '${err.path}': ${err.value}` });
const handleDuplicateKeyError= (err) => {
  const field = Object.keys(err.keyValue)[0];
  return { statusCode: 409, message: `Duplicate value: '${err.keyValue[field]}' already exists for field '${field}'.` };
};
const handleValidationError  = (err) => ({ statusCode: 400, message: Object.values(err.errors).map(e => e.message).join('. ') });
const handleJWTError         = ()    => ({ statusCode: 401, message: 'Invalid token. Please log in again.' });
const handleJWTExpiredError  = ()    => ({ statusCode: 401, message: 'Your session has expired. Please log in again.' });

// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  let statusCode = err.statusCode || 500;
  let message    = err.message    || 'Internal Server Error';

  if (err.name === 'CastError')         ({ statusCode, message } = handleCastError(err));
  if (err.code === 11000)               ({ statusCode, message } = handleDuplicateKeyError(err));
  if (err.name === 'ValidationError')   ({ statusCode, message } = handleValidationError(err));
  if (err.name === 'JsonWebTokenError') ({ statusCode, message } = handleJWTError());
  if (err.name === 'TokenExpiredError') ({ statusCode, message } = handleJWTExpiredError());

  if (statusCode === 500) {
    logger.error(`Unhandled error: ${err.message}`, { stack: err.stack, url: req.originalUrl });
  }

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};

module.exports = errorHandler;
