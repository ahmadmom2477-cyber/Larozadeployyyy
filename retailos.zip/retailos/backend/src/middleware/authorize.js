const { AppError } = require('../utils/appError');

const ROLE_LEVELS = {
  admin:    3,
  manager:  2,
  cashier:  1,
  employee: 1,
};

const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) return next(new AppError('Authentication required.', 401));
    if (!roles.includes(req.user.role)) {
      return next(
        new AppError(
          `Access denied. Required role(s): ${roles.join(', ')}. Your role: ${req.user.role}.`,
          403
        )
      );
    }
    next();
  };
};

const authorizeMinLevel = (minRole) => {
  return (req, res, next) => {
    if (!req.user) return next(new AppError('Authentication required.', 401));
    const userLevel = ROLE_LEVELS[req.user.role] || 0;
    const minLevel  = ROLE_LEVELS[minRole] || 0;
    if (userLevel < minLevel) {
      return next(new AppError(`Access denied. Minimum role required: ${minRole}.`, 403));
    }
    next();
  };
};

const authorizeSelf = (req, res, next) => {
  const isAdmin = ['admin', 'manager'].includes(req.user.role);
  const isSelf  = req.user._id.toString() === req.params.id;
  if (isAdmin || isSelf) return next();
  return next(new AppError('You can only access your own resource.', 403));
};

module.exports = { authorize, authorizeMinLevel, authorizeSelf };
