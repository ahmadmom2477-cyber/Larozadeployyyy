const getPagination = (query) => {
  const page  = Math.max(1, parseInt(query.page)  || 1);
  const limit = Math.min(100, Math.max(1, parseInt(query.limit) || 20));
  const skip  = (page - 1) * limit;
  return { page, limit, skip };
};

const getDateRange = (query, field = 'createdAt') => {
  const filter = {};
  if (query.from || query.to) {
    filter[field] = {};
    if (query.from) filter[field].$gte = new Date(query.from);
    if (query.to) {
      const to = new Date(query.to);
      to.setHours(23, 59, 59, 999);
      filter[field].$lte = to;
    }
  }
  return filter;
};

const getSort = (query, defaultSort = { createdAt: -1 }) => {
  if (!query.sort) return defaultSort;
  const sort   = {};
  const fields = query.sort.split(',');
  fields.forEach((f) => {
    if (f.startsWith('-')) sort[f.slice(1)] = -1;
    else sort[f] = 1;
  });
  return sort;
};

module.exports = { getPagination, getDateRange, getSort };
