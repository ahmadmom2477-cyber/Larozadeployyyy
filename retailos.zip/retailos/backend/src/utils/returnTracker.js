const Return   = require('../models/return.model');
const Exchange = require('../models/exchange.model');

async function getAlreadyReturnedQtyMap(saleId) {
  const map = new Map();

  const key    = (productId, variantId) => `${productId}__${variantId || 'base'}`;
  const addQty = (productId, variantId, qty) => {
    const k = key(productId, variantId);
    map.set(k, (map.get(k) || 0) + qty);
  };

  const returns = await Return.find({
    saleId,
    status: { $nin: ['rejected'] },
  }).lean();

  for (const ret of returns) {
    for (const item of ret.items) {
      addQty(item.productId.toString(), item.variantId?.toString(), item.returnQuantity);
    }
  }

  const exchanges = await Exchange.find({
    saleId,
    status: { $nin: ['rejected', 'cancelled'] },
  }).lean();

  for (const ex of exchanges) {
    for (const item of ex.returnedItems) {
      addQty(item.productId.toString(), item.variantId?.toString(), item.quantity);
    }
  }

  return { map, key };
}

async function validateReturnQuantities(sale, requestedItems) {
  const { map, key } = await getAlreadyReturnedQtyMap(sale._id.toString());

  const saleItemMap = new Map();
  for (const si of sale.items) {
    const k        = key(si.productId.toString(), si.variantId?.toString());
    const existing = saleItemMap.get(k);
    if (existing) {
      existing.quantity += si.quantity;
    } else {
      saleItemMap.set(k, { ...si.toObject(), quantity: si.quantity });
    }
  }

  const enriched = [];

  for (const req of requestedItems) {
    const k        = key(req.productId.toString(), req.variantId?.toString());
    const saleItem = saleItemMap.get(k);

    if (!saleItem) {
      throw new Error(
        `Item (product: ${req.productId}, variant: ${req.variantId ?? 'base'}) was not in the original sale.`
      );
    }

    const alreadyReturned = map.get(k) || 0;
    const maxReturnable   = saleItem.quantity - alreadyReturned;

    if (req.returnQuantity > maxReturnable) {
      throw new Error(
        `Cannot return ${req.returnQuantity} unit(s) of '${saleItem.productName}'` +
        (req.variantId ? ` (variant ${req.variantId})` : '') +
        `. Max returnable: ${maxReturnable} (originally purchased: ${saleItem.quantity}, already returned: ${alreadyReturned}).`
      );
    }

    enriched.push({ ...req, saleItem, alreadyReturned, maxReturnable });
  }

  return enriched;
}

async function computePostReturnSaleStatus(sale) {
  const { map, key } = await getAlreadyReturnedQtyMap(sale._id.toString());

  let allReturned = true;
  let anyReturned = false;

  for (const si of sale.items) {
    const k        = key(si.productId.toString(), si.variantId?.toString());
    const returned = map.get(k) || 0;
    if (returned > 0) anyReturned = true;
    if (returned < si.quantity) allReturned = false;
  }

  if (allReturned) return 'refunded';
  if (anyReturned) return 'partially_refunded';
  return 'completed';
}

module.exports = { validateReturnQuantities, computePostReturnSaleStatus, getAlreadyReturnedQtyMap };
