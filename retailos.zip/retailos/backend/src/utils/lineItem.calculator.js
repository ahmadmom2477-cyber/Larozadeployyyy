/**
 * lineItem.calculator.js
 * Pure, side-effect-free financial calculation helpers.
 */

function computeDiscount(unitPrice, quantity, discountType, discountValue) {
  const lineTotal = unitPrice * quantity;
  if (discountType === 'percentage') {
    const pct = Math.min(Math.max(discountValue, 0), 100);
    return parseFloat(((lineTotal * pct) / 100).toFixed(4));
  }
  if (discountType === 'fixed') {
    return parseFloat(Math.min(Math.max(discountValue, 0), lineTotal).toFixed(4));
  }
  return 0;
}

/**
 * Compute all financial fields for one cart line item.
 *
 * Formula:
 *   lineGross    = unitPrice × quantity
 *   discountAmt  = f(discountType, discountValue)
 *   subtotal     = lineGross − discountAmt     ← pre-tax, post-discount
 *   taxAmount    = subtotal × (taxRate / 100)
 *   total        = subtotal + taxAmount
 */
function computeLineItem({ unitPrice, costPrice, quantity, taxRate, discountType, discountValue }) {
  const lineGross      = unitPrice * quantity;
  const discountAmount = computeDiscount(unitPrice, quantity, discountType, discountValue);
  const subtotal       = parseFloat((lineGross - discountAmount).toFixed(4));
  const taxAmount      = parseFloat(((subtotal * (taxRate || 0)) / 100).toFixed(4));
  const total          = parseFloat((subtotal + taxAmount).toFixed(4));
  const profit         = parseFloat(((unitPrice - costPrice) * quantity).toFixed(4));

  return {
    unitPrice,
    costPrice,
    quantity,
    taxRate:       taxRate || 0,
    discountType:  discountType  || 'none',
    discountValue: discountValue || 0,
    discountAmount,
    subtotal,
    taxAmount,
    total,
    profit,
  };
}

function computeOrderTotals(lines) {
  const subtotal      = parseFloat(lines.reduce((s, l) => s + l.subtotal, 0).toFixed(2));
  const discountTotal = parseFloat(lines.reduce((s, l) => s + l.discountAmount, 0).toFixed(2));
  const taxTotal      = parseFloat(lines.reduce((s, l) => s + l.taxAmount, 0).toFixed(2));
  const grandTotal    = parseFloat(lines.reduce((s, l) => s + l.total, 0).toFixed(2));
  return { subtotal, discountTotal, taxTotal, grandTotal };
}

module.exports = { computeLineItem, computeOrderTotals, computeDiscount };
