const crypto = require('crypto');

const generateDocNumber = (prefix) => {
  const date    = new Date();
  const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
  const rand    = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `${prefix}-${dateStr}-${rand}`;
};

const generateReceiptNumber  = () => generateDocNumber('RCP');
const generateReturnNumber   = () => generateDocNumber('RTN');
const generateExchangeNumber = () => generateDocNumber('EXC');
const generatePONumber       = () => generateDocNumber('PO');

module.exports = {
  generateDocNumber,
  generateReceiptNumber,
  generateReturnNumber,
  generateExchangeNumber,
  generatePONumber,
};
