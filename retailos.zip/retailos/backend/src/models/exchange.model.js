const mongoose = require('mongoose');

const exchangeItemSchema = new mongoose.Schema({
  productId:   { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  variantId:   { type: mongoose.Schema.Types.ObjectId, default: null },
  productName: { type: String, required: true },
  sku:         { type: String, required: true },
  quantity:    { type: Number, required: true, min: 1 },
  unitPrice:   { type: Number, required: true, min: 0 },
  totalPrice:  { type: Number, required: true, min: 0 },
  condition:   { type: String, enum: ['resalable', 'damaged', 'disposed'], default: 'resalable' },
}, { _id: true });

const exchangeSchema = new mongoose.Schema(
  {
    exchangeNumber:          { type: String, required: true, unique: true, uppercase: true },
    saleId:                  { type: mongoose.Schema.Types.ObjectId, ref: 'Sale', required: true },
    customerId:              { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', default: null },
    processedBy:             { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    approvedBy:              { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    returnedItems: {
      type: [exchangeItemSchema],
      validate: { validator: (v) => v.length > 0, message: 'Must include returned items' },
    },
    replacementItems: {
      type: [exchangeItemSchema],
      validate: { validator: (v) => v.length > 0, message: 'Must include replacement items' },
    },
    reason: {
      type: String,
      enum: ['wrong_size', 'wrong_color', 'wrong_item', 'defective', 'customer_preference', 'other'],
      required: true,
    },
    reasonDetail:            { type: String, maxlength: 500, default: '' },
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected', 'completed', 'cancelled'],
      default: 'pending',
    },
    returnedItemsTotal:      { type: Number, required: true, min: 0 },
    replacementItemsTotal:   { type: Number, required: true, min: 0 },
    priceDifference:         { type: Number, required: true },
    additionalPaymentMethod: { type: String, enum: ['cash', 'card', 'mobile_money', 'store_credit', null], default: null },
    additionalPaymentRef:    { type: String, default: null },
    refundMethod:            { type: String, enum: ['cash', 'card', 'store_credit', null], default: null },
    completedAt:             { type: Date, default: null },
    notes:                   { type: String, maxlength: 500, default: '' },
  },
  { timestamps: true, toJSON: { virtuals: true } }
);

exchangeSchema.virtual('settlementType').get(function () {
  if (this.priceDifference > 0) return 'customer_owes';
  if (this.priceDifference < 0) return 'refund_due';
  return 'even';
});

exchangeSchema.index({ exchangeNumber: 1 }, { unique: true });
exchangeSchema.index({ saleId: 1 });
exchangeSchema.index({ customerId: 1 });
exchangeSchema.index({ status: 1 });
exchangeSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Exchange', exchangeSchema);
