const mongoose = require('mongoose');

const saleItemSchema = new mongoose.Schema({
  productId:         { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  variantId:         { type: mongoose.Schema.Types.ObjectId, default: null },
  productName:       { type: String, required: true },
  sku:               { type: String, required: true },
  variantAttributes: { type: Map, of: String, default: {} },
  quantity:          { type: Number, required: true, min: 1 },
  unitPrice:         { type: Number, required: true, min: 0 },
  costPrice:         { type: Number, required: true, min: 0 },
  discountType:      { type: String, enum: ['none', 'percentage', 'fixed'], default: 'none' },
  discountValue:     { type: Number, default: 0, min: 0 },
  discountAmount:    { type: Number, default: 0, min: 0 },
  taxRate:           { type: Number, default: 0, min: 0, max: 100 },
  taxAmount:         { type: Number, default: 0, min: 0 },
  subtotal:          { type: Number, required: true, min: 0 },
  total:             { type: Number, required: true, min: 0 },
}, { _id: true });

const paymentSchema = new mongoose.Schema({
  method:    { type: String, enum: ['cash', 'card', 'mobile_money', 'split', 'credit'], required: true },
  amount:    { type: Number, required: true, min: 0 },
  reference: { type: String, default: null },
}, { _id: true });

const saleSchema = new mongoose.Schema(
  {
    receiptNumber: { type: String, required: true, unique: true, uppercase: true },
    cashierId:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    customerId:    { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', default: null },
    items: {
      type: [saleItemSchema],
      validate: { validator: (v) => v.length > 0, message: 'Sale must have at least one item' },
    },
    subtotal:      { type: Number, required: true, min: 0 },
    discountTotal: { type: Number, default: 0, min: 0 },
    taxTotal:      { type: Number, default: 0, min: 0 },
    grandTotal:    { type: Number, required: true, min: 0 },
    payments: {
      type: [paymentSchema],
      validate: { validator: (v) => v.length > 0, message: 'At least one payment required' },
    },
    amountPaid:  { type: Number, required: true, min: 0 },
    changeDue:   { type: Number, default: 0, min: 0 },
    status: {
      type: String,
      enum: ['completed', 'refunded', 'partially_refunded', 'voided', 'on_hold'],
      default: 'completed',
    },
    notes:       { type: String, maxlength: 500, default: '' },
    returnIds:   [{ type: mongoose.Schema.Types.ObjectId, ref: 'Return' }],
    exchangeIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Exchange' }],
  },
  { timestamps: true, toJSON: { virtuals: true } }
);

saleSchema.virtual('itemCount').get(function () {
  return this.items.reduce((s, i) => s + i.quantity, 0);
});
saleSchema.virtual('grossProfit').get(function () {
  return this.items.reduce((s, i) => s + (i.unitPrice - i.costPrice) * i.quantity, 0);
});

saleSchema.index({ receiptNumber: 1 }, { unique: true });
saleSchema.index({ cashierId: 1 });
saleSchema.index({ customerId: 1 });
saleSchema.index({ status: 1 });
saleSchema.index({ createdAt: -1 });
saleSchema.index({ createdAt: 1, status: 1 });

module.exports = mongoose.model('Sale', saleSchema);
