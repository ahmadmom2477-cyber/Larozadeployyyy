const mongoose = require('mongoose');

const LOG_TYPES = [
  'sale', 'return', 'exchange_out', 'exchange_in', 'purchase_receipt',
  'manual_adjustment', 'damage_write_off', 'opening_stock',
  'transfer_in', 'transfer_out', 'audit_correction',
];

const inventoryLogSchema = new mongoose.Schema(
  {
    productId:       { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    variantId:       { type: mongoose.Schema.Types.ObjectId, default: null },
    productName:     { type: String, required: true },
    sku:             { type: String, required: true },
    type:            { type: String, enum: { values: LOG_TYPES, message: 'Invalid log type' }, required: true },
    quantityBefore:  { type: Number, required: true },
    quantityChange: {
      type: Number, required: true,
      validate: { validator: (v) => v !== 0, message: 'Quantity change cannot be zero' },
    },
    quantityAfter:   { type: Number, required: true, min: 0 },
    reason:          { type: String, maxlength: 500, default: '' },
    performedBy:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    sourceDocument: {
      model:      { type: String, enum: ['Sale', 'Return', 'Exchange', 'PurchaseOrder', null], default: null },
      documentId: { type: mongoose.Schema.Types.ObjectId, default: null },
    },
    unitCost:        { type: Number, default: null, min: 0 },
    totalCostImpact: { type: Number, default: null },
    warehouseId:     { type: mongoose.Schema.Types.ObjectId, default: null },
    notes:           { type: String, maxlength: 500, default: '' },
  },
  { timestamps: true, toJSON: { virtuals: true } }
);

inventoryLogSchema.virtual('direction').get(function () {
  return this.quantityChange > 0 ? 'in' : 'out';
});

inventoryLogSchema.pre('validate', function (next) {
  if (this.quantityBefore != null && this.quantityChange != null) {
    this.quantityAfter = this.quantityBefore + this.quantityChange;
  }
  if (this.unitCost != null && this.quantityChange != null) {
    this.totalCostImpact = this.unitCost * Math.abs(this.quantityChange);
  }
  next();
});

inventoryLogSchema.index({ productId: 1, createdAt: -1 });
inventoryLogSchema.index({ variantId: 1, createdAt: -1 });
inventoryLogSchema.index({ type: 1 });
inventoryLogSchema.index({ performedBy: 1 });
inventoryLogSchema.index({ createdAt: -1 });
inventoryLogSchema.index({ 'sourceDocument.model': 1, 'sourceDocument.documentId': 1 });

module.exports = mongoose.model('InventoryLog', inventoryLogSchema);
