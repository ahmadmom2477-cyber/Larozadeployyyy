const mongoose = require('mongoose');

const variantSchema = new mongoose.Schema({
  sku:          { type: String, required: true, trim: true, uppercase: true },
  attributes:   { type: Map, of: String, default: {} },
  costPrice:    { type: Number, required: true, min: 0 },
  sellingPrice: { type: Number, required: true, min: 0 },
  barcode:      { type: String, default: null },
  imageUrl:     { type: String, default: null },
  isActive:     { type: Boolean, default: true },
  stock:        { type: Number, default: 0, min: 0 },
  reorderPoint: { type: Number, default: 5, min: 0 },
}, { _id: true, timestamps: true });

const productSchema = new mongoose.Schema(
  {
    name:         { type: String, required: true, trim: true, minlength: 2, maxlength: 200 },
    slug:         { type: String, unique: true, lowercase: true, trim: true },
    description:  { type: String, trim: true, maxlength: 2000, default: '' },
    sku:          { type: String, required: true, unique: true, trim: true, uppercase: true },
    barcode:      { type: String, trim: true, default: null },
    categoryId:   { type: mongoose.Schema.Types.ObjectId, ref: 'Category', required: true },
    supplierId:   { type: mongoose.Schema.Types.ObjectId, ref: 'Supplier', default: null },
    unit: {
      type: String,
      enum: ['piece', 'kg', 'gram', 'liter', 'ml', 'box', 'pack', 'dozen', 'meter', 'other'],
      default: 'piece',
    },
    costPrice:    { type: Number, required: true, min: 0 },
    sellingPrice: { type: Number, required: true, min: 0 },
    taxRate:      { type: Number, default: 0, min: 0, max: 100 },
    images:       { type: [String], default: [] },
    hasVariants:  { type: Boolean, default: false },
    variants:     { type: [variantSchema], default: [] },
    tags:         { type: [String], default: [] },
    isActive:     { type: Boolean, default: true },
    totalStock:   { type: Number, default: 0, min: 0 },
    reorderPoint: { type: Number, default: 10, min: 0 },
  },
  { timestamps: true, toJSON: { virtuals: true } }
);

productSchema.virtual('profitMargin').get(function () {
  if (!this.costPrice) return null;
  return (((this.sellingPrice - this.costPrice) / this.costPrice) * 100).toFixed(2);
});

productSchema.virtual('isLowStock').get(function () {
  return this.totalStock <= this.reorderPoint;
});

productSchema.index({ sku: 1 }, { unique: true });
productSchema.index({ slug: 1 }, { unique: true });
productSchema.index({ barcode: 1 }, { sparse: true });
productSchema.index({ categoryId: 1 });
productSchema.index({ supplierId: 1 });
productSchema.index({ isActive: 1 });
productSchema.index({ name: 'text', description: 'text', tags: 'text' });
productSchema.index({ totalStock: 1 });

productSchema.pre('save', function (next) {
  if (this.isModified('name') && !this.slug) {
    this.slug = this.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  }
  next();
});

module.exports = mongoose.model('Product', productSchema);
