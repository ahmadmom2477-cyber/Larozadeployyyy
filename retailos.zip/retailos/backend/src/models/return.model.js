const mongoose = require('mongoose');

const returnItemSchema = new mongoose.Schema({
  productId:        { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  variantId:        { type: mongoose.Schema.Types.ObjectId, default: null },
  productName:      { type: String, required: true },
  sku:              { type: String, required: true },
  originalQuantity: { type: Number, required: true, min: 1 },
  returnQuantity:   { type: Number, required: true, min: 1 },
  unitPrice:        { type: Number, required: true, min: 0 },
  refundAmount:     { type: Number, required: true, min: 0 },
  condition:        { type: String, enum: ['resalable', 'damaged', 'disposed'], default: 'resalable' },
  restocked:        { type: Boolean, default: false },
}, { _id: true });

const returnSchema = new mongoose.Schema(
  {
    returnNumber:     { type: String, required: true, unique: true, uppercase: true },
    saleId:           { type: mongoose.Schema.Types.ObjectId, ref: 'Sale', required: true },
    customerId:       { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', default: null },
    processedBy:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    approvedBy:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    items: {
      type: [returnItemSchema],
      validate: { validator: (v) => v.length > 0, message: 'Return must include at least one item' },
    },
    reason: {
      type: String,
      enum: ['defective', 'wrong_item', 'customer_changed_mind', 'damaged_in_transit', 'duplicate_purchase', 'other'],
      required: true,
    },
    reasonDetail:      { type: String, maxlength: 500, default: '' },
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected', 'completed', 'refund_issued'],
      default: 'pending',
    },
    totalRefundAmount: { type: Number, required: true, min: 0 },
    refundMethod: {
      type: String,
      enum: ['original_payment', 'cash', 'store_credit', 'bank_transfer'],
      required: true,
    },
    refundReference: { type: String, default: null },
    refundIssuedAt:  { type: Date, default: null },
    notes:           { type: String, maxlength: 500, default: '' },
  },
  { timestamps: true }
);

returnSchema.index({ returnNumber: 1 }, { unique: true });
returnSchema.index({ saleId: 1 });
returnSchema.index({ customerId: 1 });
returnSchema.index({ status: 1 });
returnSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Return', returnSchema);
