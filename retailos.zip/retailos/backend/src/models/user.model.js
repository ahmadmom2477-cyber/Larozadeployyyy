const mongoose = require('mongoose');
const bcrypt   = require('bcrypt');

const userSchema = new mongoose.Schema(
  {
    name:  { type: String, required: [true, 'Name is required'], trim: true, minlength: 2, maxlength: 100 },
    email: {
      type: String, required: [true, 'Email is required'],
      unique: true, lowercase: true, trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email'],
    },
    passwordHash:      { type: String, required: true, select: false },
    role: {
      type: String,
      enum: { values: ['admin', 'manager', 'cashier'], message: 'Invalid role' },
      default: 'cashier',
    },
    isActive:          { type: Boolean, default: true },
    lastLogin:         { type: Date, default: null },
    refreshTokenHash:  { type: String, select: false, default: null },
    passwordChangedAt: { type: Date, select: false, default: null },
  },
  {
    timestamps: true,
    toJSON: {
      virtuals: true,
      transform(_, ret) {
        delete ret.passwordHash;
        delete ret.refreshTokenHash;
        delete ret.__v;
      },
    },
  }
);

userSchema.index({ email: 1 }, { unique: true });
userSchema.index({ role: 1 });
userSchema.index({ isActive: 1 });

userSchema.methods.comparePassword = function (plain) {
  return bcrypt.compare(plain, this.passwordHash);
};

userSchema.methods.changedPasswordAfter = function (jwtIat) {
  if (this.passwordChangedAt) {
    return jwtIat < Math.floor(this.passwordChangedAt.getTime() / 1000);
  }
  return false;
};

userSchema.pre('save', async function (next) {
  if (!this.isModified('passwordHash')) return next();
  this.passwordHash = await bcrypt.hash(this.passwordHash, 12);
  if (!this.isNew) this.passwordChangedAt = new Date();
  next();
});

module.exports = mongoose.model('User', userSchema);
