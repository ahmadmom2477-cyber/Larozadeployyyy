const dashboardService = require('./dashboard.service');
const { asyncHandler, sendSuccess } = require('../../utils/appError');

const dashboardController = {
  getSummary: asyncHandler(async (req, res) => {
    const data = await dashboardService.getSummary();
    sendSuccess(res, data);
  }),
};

module.exports = dashboardController;
