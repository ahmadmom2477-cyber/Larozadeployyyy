const Sale         = require('../../models/sale.model');
const Product      = require('../../models/product.model');
const Return       = require('../../models/return.model');
const InventoryLog = require('../../models/inventoryLog.model');

const dashboardService = {
  async getSummary() {
    const now        = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    const endOfDay   = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const [
      todaySales,
      monthSales,
      totalProducts,
      lowStockCount,
      pendingReturns,
      recentSales,
      recentLogs,
    ] = await Promise.all([
      Sale.aggregate([
        { $match: { createdAt: { $gte: startOfDay, $lte: endOfDay }, status: { $in: ['completed','partially_refunded'] } } },
        { $group: { _id: null, revenue: { $sum: '$grandTotal' }, count: { $sum: 1 } } },
      ]),
      Sale.aggregate([
        { $match: { createdAt: { $gte: startOfMonth }, status: { $in: ['completed','partially_refunded'] } } },
        { $group: { _id: null, revenue: { $sum: '$grandTotal' }, count: { $sum: 1 } } },
      ]),
      Product.countDocuments({ isActive: true }),
      Product.countDocuments({ totalStock: { $lte: 10 }, isActive: true }),
      Return.countDocuments({ status: 'pending' }),
      Sale.find({ status: { $in: ['completed','partially_refunded'] } })
        .sort({ createdAt: -1 }).limit(5)
        .populate('cashierId', 'name')
        .select('receiptNumber grandTotal createdAt cashierId')
        .lean(),
      InventoryLog.find()
        .sort({ createdAt: -1 }).limit(10)
        .populate('performedBy', 'name')
        .select('type quantityChange productName sku createdAt performedBy')
        .lean(),
    ]);

    return {
      today: {
        revenue:      todaySales[0]?.revenue || 0,
        transactions: todaySales[0]?.count   || 0,
      },
      month: {
        revenue:      monthSales[0]?.revenue || 0,
        transactions: monthSales[0]?.count   || 0,
      },
      inventory: {
        totalProducts,
        lowStockCount,
      },
      pendingReturns,
      recentSales,
      recentInventoryActivity: recentLogs,
    };
  },
};

module.exports = dashboardService;
