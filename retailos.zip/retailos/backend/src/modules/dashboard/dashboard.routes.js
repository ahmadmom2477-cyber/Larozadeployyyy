const router              = require('express').Router();
const dashboardController = require('./dashboard.controller');
const { authenticate }    = require('../../middleware/authenticate');
const { authorize }       = require('../../middleware/authorize');

router.use(authenticate);
router.get('/summary', authorize('admin','manager'), dashboardController.getSummary);

module.exports = router;
