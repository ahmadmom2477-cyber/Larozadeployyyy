const router         = require('express').Router();
const saleController = require('./sale.controller');
const { authenticate } = require('../../middleware/authenticate');
const { authorize }    = require('../../middleware/authorize');
const validate         = require('../../middleware/validate');
const { createSaleSchema, voidSaleSchema } = require('./sale.validation');

router.use(authenticate);

router.post('/',                                  validate(createSaleSchema), saleController.create);
router.get('/',                                                               saleController.list);
router.get('/receipt/:receiptNumber',                                         saleController.findByReceipt);
router.get('/:id',                                                            saleController.findById);
router.patch('/:id/void', authorize('admin','manager'), validate(voidSaleSchema), saleController.voidSale);

module.exports = router;
