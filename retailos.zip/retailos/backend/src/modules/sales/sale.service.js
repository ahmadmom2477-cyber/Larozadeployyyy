const Sale       = require('../../models/sale.model');
const Product    = require('../../models/product.model');
const engine     = require('../inventory/inventory.engine');
const { computeLineItem, computeOrderTotals } = require('../../utils/lineItem.calculator');
const { AppError }  = require('../../utils/appError');
const { getPagination, getDateRange, getSort } = require('../../utils/queryHelpers');
const { generateReceiptNumber } = require('../../utils/docNumber');

async function resolveCartItems(items) {
  const productIds = [...new Set(items.map(i => i.productId))];
  const products   = await Product.find({ _id: { $in: productIds }, isActive: true });
  const productMap = new Map(products.map(p => [p._id.toString(), p]));

  return items.map((item) => {
    const product = productMap.get(item.productId.toString());
    if (!product) throw new AppError(`Product ${item.productId} not found or is inactive.`, 400);

    let variantDoc   = null;
    let unitPrice    = product.sellingPrice;
    let costPrice    = product.costPrice;
    let taxRate      = product.taxRate || 0;
    let sku          = product.sku;
    let variantAttrs = {};
    let currentStock = product.totalStock;

    if (item.variantId) {
      variantDoc = product.variants.id(item.variantId);
      if (!variantDoc)          throw new AppError(`Variant ${item.variantId} not found on '${product.name}'.`, 400);
      if (!variantDoc.isActive) throw new AppError(`Variant ${item.variantId} on '${product.name}' is inactive.`, 400);
      unitPrice    = variantDoc.sellingPrice;
      costPrice    = variantDoc.costPrice;
      sku          = variantDoc.sku;
      currentStock = variantDoc.stock ?? 0;
      variantAttrs = variantDoc.attributes ? Object.fromEntries(variantDoc.attributes) : {};
    }

    return {
      product, variantDoc, currentStock,
      productId:         product._id,
      variantId:         item.variantId || null,
      productName:       product.name,
      sku,
      variantAttributes: variantAttrs,
      quantity:          item.quantity,
      unitPrice,
      costPrice,
      taxRate,
      discountType:      item.discountType  || 'none',
      discountValue:     item.discountValue || 0,
    };
  });
}

const saleService = {
  async create({ customerId, items, payments, notes, cashierId }) {
    // 1 & 2: Resolve + stock check
    const resolvedItems = await resolveCartItems(items);

    for (const ri of resolvedItems) {
      if (ri.currentStock < ri.quantity) {
        throw new AppError(
          `Insufficient stock for '${ri.productName}'${ri.variantId ? ` (${ri.sku})` : ''}. ` +
          `Available: ${ri.currentStock}, requested: ${ri.quantity}.`,
          400
        );
      }
    }

    // 3: Compute line-item financials
    const computedLines = resolvedItems.map((ri) => {
      const fin = computeLineItem({
        unitPrice:     ri.unitPrice,
        costPrice:     ri.costPrice,
        quantity:      ri.quantity,
        taxRate:       ri.taxRate,
        discountType:  ri.discountType,
        discountValue: ri.discountValue,
      });
      return {
        productId: ri.productId, variantId: ri.variantId,
        productName: ri.productName, sku: ri.sku,
        variantAttributes: ri.variantAttributes,
        ...fin,
      };
    });

    // 4: Order totals
    const { subtotal, discountTotal, taxTotal, grandTotal } = computeOrderTotals(computedLines);

    // 5: Payment validation
    const amountPaid = parseFloat(payments.reduce((s, p) => s + p.amount, 0).toFixed(2));
    if (amountPaid < grandTotal) {
      throw new AppError(`Payment insufficient. Grand total: ${grandTotal}, amount paid: ${amountPaid}.`, 400);
    }
    const changeDue = parseFloat((amountPaid - grandTotal).toFixed(2));

    // 6: Persist sale
    const saleItems = computedLines.map(({ profit, ...rest }) => rest);

    const sale = await Sale.create({
      receiptNumber: generateReceiptNumber(),
      cashierId,
      customerId:    customerId || null,
      items:         saleItems,
      subtotal,
      discountTotal,
      taxTotal,
      grandTotal,
      payments,
      amountPaid,
      changeDue,
      notes:   notes || '',
      status: 'completed',
    });

    // 7: Deduct inventory
    const deductContexts = resolvedItems.map((ri) => ({
      productId:      ri.productId,
      variantId:      ri.variantId,
      quantity:       ri.quantity,
      type:           'sale',
      reason:         `Sale ${sale.receiptNumber}`,
      performedBy:    cashierId,
      sourceDocument: { model: 'Sale', documentId: sale._id },
      unitCost:       ri.costPrice,
    }));

    await engine.bulkDeduct(deductContexts);

    // 8: Return populated sale
    return Sale.findById(sale._id)
      .populate('cashierId', 'name')
      .populate('customerId', 'name email phone');
  },

  async voidSale(saleId, performedBy, reason) {
    const sale = await Sale.findById(saleId);
    if (!sale)                       throw new AppError('Sale not found.', 404);
    if (sale.status === 'voided')    throw new AppError('Sale is already voided.', 400);
    if (sale.status === 'refunded')  throw new AppError('Cannot void a fully refunded sale.', 400);
    if (!reason || !reason.trim())   throw new AppError('A void reason is required.', 400);

    sale.status = 'voided';
    sale.notes  = [sale.notes, `VOIDED by ${performedBy}: ${reason}`].filter(Boolean).join(' | ');
    await sale.save({ validateBeforeSave: false });

    const restoreContexts = sale.items.map((item) => ({
      productId:      item.productId,
      variantId:      item.variantId || null,
      quantity:       item.quantity,
      type:           'manual_adjustment',
      reason:         `Void reversal — sale ${sale.receiptNumber}: ${reason}`,
      performedBy,
      sourceDocument: { model: 'Sale', documentId: sale._id },
      unitCost:       item.costPrice,
    }));

    await engine.bulkRestore(restoreContexts);
    return sale;
  },

  async list(query) {
    const { page, limit, skip } = getPagination(query);
    const sort   = getSort(query, { createdAt: -1 });
    const filter = { ...getDateRange(query) };

    if (query.status)     filter.status     = query.status;
    if (query.cashierId)  filter.cashierId  = query.cashierId;
    if (query.customerId) filter.customerId = query.customerId;

    const [sales, total] = await Promise.all([
      Sale.find(filter)
        .populate('cashierId', 'name')
        .populate('customerId', 'name email')
        .sort(sort).skip(skip).limit(limit).lean(),
      Sale.countDocuments(filter),
    ]);
    return { sales, total, page, limit };
  },

  async findById(id) {
    const sale = await Sale.findById(id)
      .populate('cashierId', 'name')
      .populate('customerId', 'name email phone')
      .populate('returnIds')
      .populate('exchangeIds');
    if (!sale) throw new AppError('Sale not found.', 404);
    return sale;
  },

  async findByReceiptNumber(receiptNumber) {
    const sale = await Sale.findOne({ receiptNumber: receiptNumber.toUpperCase() })
      .populate('cashierId', 'name')
      .populate('customerId', 'name email phone');
    if (!sale) throw new AppError('Receipt not found.', 404);
    return sale;
  },
};

module.exports = saleService;
