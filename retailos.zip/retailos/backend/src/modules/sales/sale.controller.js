const saleService = require('./sale.service');
const { asyncHandler, sendSuccess, sendPaginated } = require('../../utils/appError');

const saleController = {
  create: asyncHandler(async (req, res) => {
    const sale = await saleService.create({ ...req.body, cashierId: req.user._id });
    sendSuccess(res, { sale }, 201);
  }),

  list: asyncHandler(async (req, res) => {
    const { sales, total, page, limit } = await saleService.list(req.query);
    sendPaginated(res, sales, total, page, limit);
  }),

  findById: asyncHandler(async (req, res) => {
    const sale = await saleService.findById(req.params.id);
    sendSuccess(res, { sale });
  }),

  findByReceipt: asyncHandler(async (req, res) => {
    const sale = await saleService.findByReceiptNumber(req.params.receiptNumber);
    sendSuccess(res, { sale });
  }),

  voidSale: asyncHandler(async (req, res) => {
    const sale = await saleService.voidSale(req.params.id, req.user._id, req.body.reason);
    sendSuccess(res, { sale }, 200, { message: 'Sale voided successfully.' });
  }),
};

module.exports = saleController;
