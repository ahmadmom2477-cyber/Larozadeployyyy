const Joi = require('joi');

const saleItemSchema = Joi.object({
  productId:     Joi.string().hex().length(24).required(),
  variantId:     Joi.string().hex().length(24).allow(null).default(null),
  quantity:      Joi.number().integer().min(1).required(),
  discountType:  Joi.string().valid('none','percentage','fixed').default('none'),
  discountValue: Joi.number().min(0).default(0),
});

const paymentSchema = Joi.object({
  method:    Joi.string().valid('cash','card','mobile_money','split','credit').required(),
  amount:    Joi.number().min(0.01).required(),
  reference: Joi.string().allow(null,'').default(null),
});

const createSaleSchema = Joi.object({
  customerId: Joi.string().hex().length(24).allow(null).default(null),
  items:      Joi.array().items(saleItemSchema).min(1).required(),
  payments:   Joi.array().items(paymentSchema).min(1).required(),
  notes:      Joi.string().max(500).allow('').default(''),
});

const voidSaleSchema = Joi.object({
  reason: Joi.string().min(5).required(),
});

module.exports = { createSaleSchema, voidSaleSchema };
