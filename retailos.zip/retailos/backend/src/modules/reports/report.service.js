const Sale         = require('../../models/sale.model');
const Return       = require('../../models/return.model');
const Product      = require('../../models/product.model');
const InventoryLog = require('../../models/inventoryLog.model');
const { getDateRange } = require('../../utils/queryHelpers');

const reportService = {
  async salesSummary(query) {
    const dateFilter = getDateRange(query);
    const match      = { status: { $in: ['completed','partially_refunded'] }, ...dateFilter };

    const [summary] = await Sale.aggregate([
      { $match: match },
      {
        $group: {
          _id:               null,
          totalRevenue:      { $sum: '$grandTotal' },
          totalTransactions: { $sum: 1 },
          totalDiscount:     { $sum: '$discountTotal' },
          totalTax:          { $sum: '$taxTotal' },
          avgOrderValue:     { $avg: '$grandTotal' },
          totalItemsSold:    { $sum: { $sum: '$items.quantity' } },
        },
      },
    ]);

    const refundTotal = await Return.aggregate([
      { $match: { status: { $in: ['completed','refund_issued'] }, ...dateFilter } },
      { $group: { _id: null, total: { $sum: '$totalRefundAmount' } } },
    ]);

    return {
      ...(summary || { totalRevenue: 0, totalTransactions: 0, totalDiscount: 0, totalTax: 0, avgOrderValue: 0, totalItemsSold: 0 }),
      totalRefunds: refundTotal[0]?.total || 0,
      netRevenue:   (summary?.totalRevenue || 0) - (refundTotal[0]?.total || 0),
    };
  },

  async dailySales(query) {
    const dateFilter = getDateRange(query);
    return Sale.aggregate([
      { $match: { status: { $in: ['completed','partially_refunded'] }, ...dateFilter } },
      {
        $group: {
          _id:          { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
          revenue:      { $sum: '$grandTotal' },
          transactions: { $sum: 1 },
          avgOrder:     { $avg: '$grandTotal' },
        },
      },
      { $sort: { _id: 1 } },
    ]);
  },

  async topProducts(query) {
    const limit      = parseInt(query.limit) || 10;
    const dateFilter = getDateRange(query);

    return Sale.aggregate([
      { $match: { status: { $in: ['completed','partially_refunded'] }, ...dateFilter } },
      { $unwind: '$items' },
      {
        $group: {
          _id:          '$items.productId',
          productName:  { $first: '$items.productName' },
          sku:          { $first: '$items.sku' },
          totalQtySold: { $sum: '$items.quantity' },
          totalRevenue: { $sum: '$items.total' },
          totalProfit:  {
            $sum: { $multiply: [{ $subtract: ['$items.unitPrice', '$items.costPrice'] }, '$items.quantity'] }
          },
        },
      },
      { $sort: { totalRevenue: -1 } },
      { $limit: limit },
    ]);
  },

  async salesByPaymentMethod(query) {
    const dateFilter = getDateRange(query);
    return Sale.aggregate([
      { $match: { status: 'completed', ...dateFilter } },
      { $unwind: '$payments' },
      {
        $group: {
          _id:   '$payments.method',
          total: { $sum: '$payments.amount' },
          count: { $sum: 1 },
        },
      },
      { $sort: { total: -1 } },
    ]);
  },

  async cashierPerformance(query) {
    const dateFilter = getDateRange(query);
    return Sale.aggregate([
      { $match: { status: { $in: ['completed','partially_refunded'] }, ...dateFilter } },
      {
        $group: {
          _id:          '$cashierId',
          transactions: { $sum: 1 },
          totalRevenue: { $sum: '$grandTotal' },
          avgOrder:     { $avg: '$grandTotal' },
        },
      },
      {
        $lookup: {
          from: 'users', localField: '_id', foreignField: '_id', as: 'cashier',
        },
      },
      { $unwind: '$cashier' },
      { $project: { 'cashier.passwordHash': 0, 'cashier.refreshTokenHash': 0 } },
      { $sort: { totalRevenue: -1 } },
    ]);
  },

  async inventoryValuation() {
    return Product.aggregate([
      { $match: { isActive: true } },
      {
        $group: {
          _id:              null,
          totalCostValue:   { $sum: { $multiply: ['$costPrice', '$totalStock'] } },
          totalRetailValue: { $sum: { $multiply: ['$sellingPrice', '$totalStock'] } },
          totalUnits:       { $sum: '$totalStock' },
          productCount:     { $sum: 1 },
        },
      },
    ]);
  },

  async stockMovements(query) {
    const dateFilter = getDateRange(query);
    return InventoryLog.aggregate([
      { $match: { ...dateFilter } },
      {
        $group: {
          _id:      '$type',
          count:    { $sum: 1 },
          totalIn:  { $sum: { $cond: [{ $gt: ['$quantityChange', 0] }, '$quantityChange', 0] } },
          totalOut: { $sum: { $cond: [{ $lt: ['$quantityChange', 0] }, '$quantityChange', 0] } },
        },
      },
      { $sort: { count: -1 } },
    ]);
  },
};

module.exports = reportService;
