const reportService = require('./report.service');
const { asyncHandler, sendSuccess } = require('../../utils/appError');

const reportController = {
  salesSummary:        asyncHandler(async (req, res) => sendSuccess(res, await reportService.salesSummary(req.query))),
  dailySales:          asyncHandler(async (req, res) => sendSuccess(res, { days:      await reportService.dailySales(req.query) })),
  topProducts:         asyncHandler(async (req, res) => sendSuccess(res, { products:  await reportService.topProducts(req.query) })),
  salesByPaymentMethod:asyncHandler(async (req, res) => sendSuccess(res, { breakdown: await reportService.salesByPaymentMethod(req.query) })),
  cashierPerformance:  asyncHandler(async (req, res) => sendSuccess(res, { cashiers:  await reportService.cashierPerformance(req.query) })),
  inventoryValuation:  asyncHandler(async (req, res) => sendSuccess(res, { valuation: (await reportService.inventoryValuation())[0] })),
  stockMovements:      asyncHandler(async (req, res) => sendSuccess(res, { movements: await reportService.stockMovements(req.query) })),
};

module.exports = reportController;
