const router           = require('express').Router();
const reportController = require('./report.controller');
const { authenticate } = require('../../middleware/authenticate');
const { authorize }    = require('../../middleware/authorize');

router.use(authenticate);
router.use(authorize('admin','manager'));

router.get('/sales-summary',       reportController.salesSummary);
router.get('/daily-sales',         reportController.dailySales);
router.get('/top-products',        reportController.topProducts);
router.get('/payment-methods',     reportController.salesByPaymentMethod);
router.get('/cashier-performance', reportController.cashierPerformance);
router.get('/inventory-valuation', reportController.inventoryValuation);
router.get('/stock-movements',     reportController.stockMovements);

module.exports = router;
