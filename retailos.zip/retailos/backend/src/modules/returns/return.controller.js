const returnService = require('./return.service');
const { asyncHandler, sendSuccess, sendPaginated } = require('../../utils/appError');

const returnController = {
  create: asyncHandler(async (req, res) => {
    const returnDoc = await returnService.create({ ...req.body, processedBy: req.user._id });
    sendSuccess(res, { return: returnDoc }, 201);
  }),

  list: asyncHandler(async (req, res) => {
    const { returns, total, page, limit } = await returnService.list(req.query);
    sendPaginated(res, returns, total, page, limit);
  }),

  findById: asyncHandler(async (req, res) => {
    const returnDoc = await returnService.findById(req.params.id);
    sendSuccess(res, { return: returnDoc });
  }),

  updateStatus: asyncHandler(async (req, res) => {
    const doc = await returnService.updateStatus(req.params.id, req.body.status, req.user._id);
    sendSuccess(res, { return: doc });
  }),
};

module.exports = returnController;
