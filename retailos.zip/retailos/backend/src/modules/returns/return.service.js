const Return   = require('../../models/return.model');
const Sale     = require('../../models/sale.model');
const engine   = require('../inventory/inventory.engine');
const { validateReturnQuantities, computePostReturnSaleStatus } = require('../../utils/returnTracker');
const { AppError }  = require('../../utils/appError');
const { getPagination, getDateRange } = require('../../utils/queryHelpers');
const { generateReturnNumber } = require('../../utils/docNumber');

const returnService = {
  async create({ saleId, items, reason, reasonDetail, refundMethod, notes, processedBy }) {
    const sale = await Sale.findById(saleId);
    if (!sale)                       throw new AppError('Original sale not found.', 404);
    if (sale.status === 'voided')    throw new AppError('Cannot return items from a voided sale.', 400);
    if (sale.status === 'refunded')  throw new AppError('This sale has already been fully returned.', 400);

    let enrichedItems;
    try {
      enrichedItems = await validateReturnQuantities(sale, items);
    } catch (err) {
      throw new AppError(err.message, 400);
    }

    let totalRefundAmount = 0;
    const computedItems = enrichedItems.map(({ saleItem, ...req }) => {
      const unitRefund   = parseFloat((saleItem.unitPrice * (1 + saleItem.taxRate / 100)).toFixed(4));
      const refundAmount = parseFloat((unitRefund * req.returnQuantity).toFixed(2));
      totalRefundAmount += refundAmount;

      return {
        productId:        saleItem.productId,
        variantId:        saleItem.variantId || null,
        productName:      saleItem.productName,
        sku:              saleItem.sku,
        originalQuantity: saleItem.quantity,
        returnQuantity:   req.returnQuantity,
        unitPrice:        saleItem.unitPrice,
        refundAmount,
        condition:        req.condition || 'resalable',
        restocked:        false,
      };
    });

    totalRefundAmount = parseFloat(totalRefundAmount.toFixed(2));

    const returnDoc = await Return.create({
      returnNumber:      generateReturnNumber(),
      saleId,
      processedBy,
      customerId:        sale.customerId || null,
      items:             computedItems,
      reason,
      reasonDetail:      reasonDetail || '',
      totalRefundAmount,
      refundMethod,
      notes:             notes || '',
      status:            'approved',
    });

    // Restore resalable items
    const resalableItems = computedItems.filter(i => i.condition === 'resalable');
    if (resalableItems.length > 0) {
      const restoreContexts = resalableItems.map(item => ({
        productId:      item.productId,
        variantId:      item.variantId,
        quantity:       item.returnQuantity,
        type:           'return',
        reason:         `Return ${returnDoc.returnNumber} from sale ${sale.receiptNumber}`,
        performedBy:    processedBy,
        sourceDocument: { model: 'Return', documentId: returnDoc._id },
        unitCost:       item.unitPrice,
      }));

      await engine.bulkRestore(restoreContexts);

      returnDoc.items.forEach(item => {
        if (item.condition === 'resalable') item.restocked = true;
      });
      await returnDoc.save({ validateBeforeSave: false });
    }

    // Update sale status
    sale.returnIds.push(returnDoc._id);
    sale.status = await computePostReturnSaleStatus(sale);
    await sale.save({ validateBeforeSave: false });

    return returnDoc;
  },

  async list(query) {
    const { page, limit, skip } = getPagination(query);
    const filter = { ...getDateRange(query) };
    if (query.status)      filter.status      = query.status;
    if (query.saleId)      filter.saleId      = query.saleId;
    if (query.processedBy) filter.processedBy = query.processedBy;

    const [returns, total] = await Promise.all([
      Return.find(filter)
        .populate('processedBy', 'name')
        .populate('saleId', 'receiptNumber grandTotal')
        .populate('customerId', 'name email')
        .sort({ createdAt: -1 })
        .skip(skip).limit(limit).lean(),
      Return.countDocuments(filter),
    ]);
    return { returns, total, page, limit };
  },

  async findById(id) {
    const doc = await Return.findById(id)
      .populate('saleId', 'receiptNumber grandTotal items')
      .populate('processedBy', 'name')
      .populate('customerId', 'name email');
    if (!doc) throw new AppError('Return not found.', 404);
    return doc;
  },

  async updateStatus(id, status, approvedBy) {
    const allowedTransitions = {
      pending:  ['approved', 'rejected'],
      approved: ['refund_issued', 'completed'],
    };

    const doc = await Return.findById(id);
    if (!doc) throw new AppError('Return not found.', 404);

    const allowed = allowedTransitions[doc.status] || [];
    if (!allowed.includes(status)) {
      throw new AppError(`Cannot transition return from '${doc.status}' to '${status}'.`, 400);
    }

    doc.status     = status;
    doc.approvedBy = approvedBy;
    if (status === 'refund_issued') doc.refundIssuedAt = new Date();
    await doc.save({ validateBeforeSave: false });

    return doc;
  },
};

module.exports = returnService;
