const router           = require('express').Router();
const returnController = require('./return.controller');
const { authenticate } = require('../../middleware/authenticate');
const { authorize }    = require('../../middleware/authorize');

router.use(authenticate);

router.post('/',            returnController.create);
router.get('/',             returnController.list);
router.get('/:id',          returnController.findById);
router.patch('/:id/status', authorize('admin','manager'), returnController.updateStatus);

module.exports = router;
