const Exchange = require('../../models/exchange.model');
const Sale     = require('../../models/sale.model');
const Product  = require('../../models/product.model');
const engine   = require('../inventory/inventory.engine');
const { validateReturnQuantities, computePostReturnSaleStatus } = require('../../utils/returnTracker');
const { AppError }  = require('../../utils/appError');
const { getPagination, getDateRange } = require('../../utils/queryHelpers');
const { generateExchangeNumber } = require('../../utils/docNumber');

async function resolveReplacementItems(replacementRequests) {
  const productIds = [...new Set(replacementRequests.map(r => r.productId.toString()))];
  const products   = await Product.find({ _id: { $in: productIds }, isActive: true });
  const productMap = new Map(products.map(p => [p._id.toString(), p]));
  const resolved   = [];

  for (const req of replacementRequests) {
    const product = productMap.get(req.productId.toString());
    if (!product) throw new AppError(`Replacement product ${req.productId} not found or is inactive.`, 400);

    let variantDoc   = null;
    let unitPrice    = product.sellingPrice;
    let costPrice    = product.costPrice;
    let sku          = product.sku;
    let currentStock = product.totalStock;

    if (req.variantId) {
      variantDoc = product.variants.id(req.variantId);
      if (!variantDoc)           throw new AppError(`Replacement variant ${req.variantId} not found on '${product.name}'.`, 400);
      if (!variantDoc.isActive)  throw new AppError(`Replacement variant ${req.variantId} on '${product.name}' is inactive.`, 400);
      unitPrice    = variantDoc.sellingPrice;
      costPrice    = variantDoc.costPrice;
      sku          = variantDoc.sku;
      currentStock = variantDoc.stock ?? 0;
    }

    if (currentStock < req.quantity) {
      throw new AppError(
        `Insufficient replacement stock for '${product.name}'${req.variantId ? ` (${sku})` : ''}. ` +
        `Available: ${currentStock}, requested: ${req.quantity}.`,
        400
      );
    }

    resolved.push({
      product, variantDoc,
      productId:   product._id,
      variantId:   req.variantId || null,
      productName: product.name,
      sku,
      quantity:    req.quantity,
      unitPrice,
      costPrice,
      totalPrice:  parseFloat((unitPrice * req.quantity).toFixed(2)),
    });
  }

  return resolved;
}

const exchangeService = {
  async create({
    saleId, returnedItems, replacementItems,
    reason, reasonDetail, additionalPaymentMethod,
    additionalPaymentRef, refundMethod, notes, processedBy,
  }) {
    const sale = await Sale.findById(saleId);
    if (!sale)                   throw new AppError('Original sale not found.', 404);
    if (sale.status === 'voided') throw new AppError('Cannot exchange items from a voided sale.', 400);

    // Validate returned quantities
    const returnRequests = returnedItems.map(i => ({
      productId:      i.productId,
      variantId:      i.variantId || null,
      returnQuantity: i.quantity,
      condition:      i.condition || 'resalable',
    }));

    let enrichedReturned;
    try {
      enrichedReturned = await validateReturnQuantities(sale, returnRequests);
    } catch (err) {
      throw new AppError(err.message, 400);
    }

    const resolvedReplacements = await resolveReplacementItems(replacementItems);

    const computedReturnedItems = enrichedReturned.map(({ saleItem, ...req }) => ({
      productId:   saleItem.productId,
      variantId:   saleItem.variantId || null,
      productName: saleItem.productName,
      sku:         saleItem.sku,
      quantity:    req.returnQuantity,
      unitPrice:   saleItem.unitPrice,
      totalPrice:  parseFloat((saleItem.unitPrice * req.returnQuantity).toFixed(2)),
      condition:   req.condition || 'resalable',
    }));

    const computedReplacementItems = resolvedReplacements.map(r => ({
      productId:   r.productId,
      variantId:   r.variantId,
      productName: r.productName,
      sku:         r.sku,
      quantity:    r.quantity,
      unitPrice:   r.unitPrice,
      totalPrice:  r.totalPrice,
      condition:   'resalable',
    }));

    const returnedItemsTotal    = parseFloat(computedReturnedItems.reduce((s, i) => s + i.totalPrice, 0).toFixed(2));
    const replacementItemsTotal = parseFloat(computedReplacementItems.reduce((s, i) => s + i.totalPrice, 0).toFixed(2));
    const priceDifference       = parseFloat((replacementItemsTotal - returnedItemsTotal).toFixed(2));

    const exchangeDoc = await Exchange.create({
      exchangeNumber:          generateExchangeNumber(),
      saleId,
      customerId:              sale.customerId || null,
      processedBy,
      returnedItems:           computedReturnedItems,
      replacementItems:        computedReplacementItems,
      reason,
      reasonDetail:            reasonDetail || '',
      status:                  'completed',
      returnedItemsTotal,
      replacementItemsTotal,
      priceDifference,
      additionalPaymentMethod: additionalPaymentMethod || null,
      additionalPaymentRef:    additionalPaymentRef    || null,
      refundMethod:            refundMethod            || null,
      notes:                   notes                   || '',
      completedAt:             new Date(),
    });

    // Restore resalable returned items (exchange_in)
    const resalableReturned = computedReturnedItems.filter(i => i.condition === 'resalable');
    for (const item of resalableReturned) {
      await engine.restoreStock({
        productId:      item.productId,
        variantId:      item.variantId,
        quantity:       item.quantity,
        type:           'exchange_in',
        reason:         `Exchange ${exchangeDoc.exchangeNumber} — returned item back to shelf`,
        performedBy:    processedBy,
        sourceDocument: { model: 'Exchange', documentId: exchangeDoc._id },
        unitCost:       item.unitPrice,
      });
    }

    // Deduct replacement items (exchange_out)
    for (const item of resolvedReplacements) {
      await engine.deductStock({
        productId:      item.productId,
        variantId:      item.variantId,
        quantity:       item.quantity,
        type:           'exchange_out',
        reason:         `Exchange ${exchangeDoc.exchangeNumber} — replacement item to customer`,
        performedBy:    processedBy,
        sourceDocument: { model: 'Exchange', documentId: exchangeDoc._id },
        unitCost:       item.costPrice,
      });
    }

    // Update sale status
    sale.exchangeIds.push(exchangeDoc._id);
    sale.status = await computePostReturnSaleStatus(sale);
    await sale.save({ validateBeforeSave: false });

    return exchangeDoc;
  },

  async list(query) {
    const { page, limit, skip } = getPagination(query);
    const filter = { ...getDateRange(query) };
    if (query.status)      filter.status      = query.status;
    if (query.saleId)      filter.saleId      = query.saleId;
    if (query.processedBy) filter.processedBy = query.processedBy;

    const [exchanges, total] = await Promise.all([
      Exchange.find(filter)
        .populate('processedBy', 'name')
        .populate('saleId', 'receiptNumber grandTotal')
        .populate('customerId', 'name email')
        .sort({ createdAt: -1 })
        .skip(skip).limit(limit).lean(),
      Exchange.countDocuments(filter),
    ]);
    return { exchanges, total, page, limit };
  },

  async findById(id) {
    const doc = await Exchange.findById(id)
      .populate('saleId', 'receiptNumber grandTotal items')
      .populate('processedBy', 'name')
      .populate('customerId', 'name email');
    if (!doc) throw new AppError('Exchange not found.', 404);
    return doc;
  },
};

module.exports = exchangeService;
