const exchangeService = require('./exchange.service');
const { asyncHandler, sendSuccess, sendPaginated } = require('../../utils/appError');

const exchangeController = {
  create: asyncHandler(async (req, res) => {
    const exchange = await exchangeService.create({ ...req.body, processedBy: req.user._id });
    sendSuccess(res, { exchange }, 201);
  }),

  list: asyncHandler(async (req, res) => {
    const { exchanges, total, page, limit } = await exchangeService.list(req.query);
    sendPaginated(res, exchanges, total, page, limit);
  }),

  findById: asyncHandler(async (req, res) => {
    const exchange = await exchangeService.findById(req.params.id);
    sendSuccess(res, { exchange });
  }),
};

module.exports = exchangeController;
