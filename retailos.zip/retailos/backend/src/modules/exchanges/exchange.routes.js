const router             = require('express').Router();
const exchangeController = require('./exchange.controller');
const { authenticate }   = require('../../middleware/authenticate');

router.use(authenticate);
router.post('/',   exchangeController.create);
router.get('/',    exchangeController.list);
router.get('/:id', exchangeController.findById);

module.exports = router;
