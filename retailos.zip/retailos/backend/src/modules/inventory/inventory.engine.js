/**
 * inventory.engine.js
 * THE only place in the codebase that writes product stock and creates InventoryLogs.
 */
const Product      = require('../../models/product.model');
const InventoryLog = require('../../models/inventoryLog.model');
const { AppError } = require('../../utils/appError');

async function resolveTarget(productId, variantId) {
  const product = await Product.findById(productId);
  if (!product)         throw new AppError(`Product ${productId} not found.`, 404);
  if (!product.isActive) throw new AppError(`Product '${product.name}' is inactive.`, 400);

  if (variantId) {
    const variant = product.variants.id(variantId);
    if (!variant)         throw new AppError(`Variant ${variantId} not found on product '${product.name}'.`, 404);
    if (!variant.isActive) throw new AppError(`Variant ${variantId} on '${product.name}' is inactive.`, 400);
    return {
      product,
      variant,
      currentStock: variant.stock ?? 0,
      sku:          variant.sku,
      displayName:  `${product.name} [${Array.from(variant.attributes?.entries?.() ?? []).map(([k,v]) => `${k}:${v}`).join(', ')}]`,
    };
  }

  return {
    product,
    variant:      null,
    currentStock: product.totalStock,
    sku:          product.sku,
    displayName:  product.name,
  };
}

async function applyDelta({ product, variant, delta, type, reason, performedBy, sourceDocument, unitCost, allowNegative = false }) {
  const before = variant ? (variant.stock ?? 0) : product.totalStock;
  const after  = before + delta;

  if (!allowNegative && after < 0) {
    const target = variant ? `variant ${variant.sku}` : `product '${product.name}'`;
    throw new AppError(
      `Insufficient stock for ${target}. Available: ${before}, attempted change: ${delta}.`,
      400
    );
  }

  if (variant) {
    variant.stock  = after;
    product.totalStock = product.variants
      .filter(v => v.isActive)
      .reduce((sum, v) => sum + (v.stock ?? 0), 0);
  } else {
    product.totalStock = after;
  }

  await product.save({ validateBeforeSave: false });

  const log = await InventoryLog.create({
    productId:       product._id,
    variantId:       variant?._id ?? null,
    productName:     product.name,
    sku:             variant ? variant.sku : product.sku,
    type,
    quantityBefore:  before,
    quantityChange:  delta,
    quantityAfter:   after,
    reason:          reason || '',
    performedBy,
    sourceDocument:  sourceDocument ?? {},
    unitCost:        unitCost ?? (variant ? variant.costPrice : product.costPrice),
  });

  return log;
}

async function deductStock(ctx) {
  const { product, variant } = await resolveTarget(ctx.productId, ctx.variantId);
  return applyDelta({
    product, variant,
    delta:          -Math.abs(ctx.quantity),
    type:           ctx.type,
    reason:         ctx.reason,
    performedBy:    ctx.performedBy,
    sourceDocument: ctx.sourceDocument,
    unitCost:       ctx.unitCost,
  });
}

async function restoreStock(ctx) {
  const { product, variant } = await resolveTarget(ctx.productId, ctx.variantId);
  return applyDelta({
    product, variant,
    delta:          +Math.abs(ctx.quantity),
    type:           ctx.type,
    reason:         ctx.reason,
    performedBy:    ctx.performedBy,
    sourceDocument: ctx.sourceDocument,
    unitCost:       ctx.unitCost,
  });
}

async function manualAdjust(ctx) {
  const { product, variant } = await resolveTarget(ctx.productId, ctx.variantId);
  return applyDelta({
    product, variant,
    delta:          ctx.quantityChange,
    type:           ctx.type || 'manual_adjustment',
    reason:         ctx.reason,
    performedBy:    ctx.performedBy,
    sourceDocument: ctx.sourceDocument,
    unitCost:       ctx.unitCost,
    allowNegative:  ctx.allowNegative ?? false,
  });
}

async function bulkDeduct(ctxArray) {
  const resolved = await Promise.all(
    ctxArray.map(async (ctx) => {
      const target   = await resolveTarget(ctx.productId, ctx.variantId);
      const newStock = target.currentStock - Math.abs(ctx.quantity);
      if (newStock < 0) {
        throw new AppError(
          `Insufficient stock for '${target.displayName}'. Available: ${target.currentStock}, requested: ${ctx.quantity}.`,
          400
        );
      }
      return { ...target, ctx };
    })
  );

  const logs = [];
  for (const { product, variant, ctx } of resolved) {
    const log = await applyDelta({
      product, variant,
      delta:          -Math.abs(ctx.quantity),
      type:           ctx.type,
      reason:         ctx.reason,
      performedBy:    ctx.performedBy,
      sourceDocument: ctx.sourceDocument,
      unitCost:       ctx.unitCost,
    });
    logs.push(log);
  }
  return logs;
}

async function bulkRestore(ctxArray) {
  const logs = [];
  for (const ctx of ctxArray) {
    const log = await restoreStock(ctx);
    logs.push(log);
  }
  return logs;
}

module.exports = { deductStock, restoreStock, manualAdjust, bulkDeduct, bulkRestore };
