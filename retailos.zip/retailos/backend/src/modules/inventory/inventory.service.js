const Product      = require('../../models/product.model');
const InventoryLog = require('../../models/inventoryLog.model');
const engine       = require('./inventory.engine');
const { AppError } = require('../../utils/appError');
const { getPagination, getDateRange, getSort } = require('../../utils/queryHelpers');

const inventoryService = {
  async adjust({ productId, variantId, quantityChange, type, reason, performedBy, unitCost }) {
    if (quantityChange === 0) throw new AppError('Quantity change cannot be zero.', 400);

    const log = await engine.manualAdjust({
      productId,
      variantId:     variantId || null,
      quantityChange,
      type:          type || 'manual_adjustment',
      reason,
      performedBy,
      unitCost,
      allowNegative: type === 'audit_correction',
    });

    const product = await Product.findById(productId).lean();
    return { product, log };
  },

  async getLogs(query) {
    const { page, limit, skip } = getPagination(query);
    const sort   = getSort(query, { createdAt: -1 });
    const filter = { ...getDateRange(query) };

    if (query.productId)    filter.productId    = query.productId;
    if (query.variantId)    filter.variantId    = query.variantId;
    if (query.type)         filter.type         = query.type;
    if (query.performedBy)  filter.performedBy  = query.performedBy;
    if (query.direction) {
      filter.quantityChange = query.direction === 'in' ? { $gt: 0 } : { $lt: 0 };
    }

    const [logs, total] = await Promise.all([
      InventoryLog.find(filter)
        .populate('performedBy', 'name role')
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .lean(),
      InventoryLog.countDocuments(filter),
    ]);

    return { logs, total, page, limit };
  },

  async getProductLogs(productId, query) {
    const { page, limit, skip } = getPagination(query);
    const filter = { productId };
    if (query.variantId) filter.variantId = query.variantId;

    const [logs, total] = await Promise.all([
      InventoryLog.find(filter)
        .populate('performedBy', 'name role')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      InventoryLog.countDocuments(filter),
    ]);
    return { logs, total, page, limit };
  },

  async getLowStockProducts(threshold = 10) {
    return Product.find({ totalStock: { $lte: threshold }, isActive: true })
      .select('name sku totalStock reorderPoint costPrice sellingPrice categoryId variants')
      .populate('categoryId', 'name')
      .sort({ totalStock: 1 })
      .lean();
  },

  async getValuation() {
    const result = await Product.aggregate([
      { $match: { isActive: true } },
      {
        $group: {
          _id:              null,
          totalCostValue:   { $sum: { $multiply: ['$costPrice', '$totalStock'] } },
          totalRetailValue: { $sum: { $multiply: ['$sellingPrice', '$totalStock'] } },
          totalUnits:       { $sum: '$totalStock' },
          productCount:     { $sum: 1 },
        },
      },
    ]);
    return result[0] || { totalCostValue: 0, totalRetailValue: 0, totalUnits: 0, productCount: 0 };
  },

  async getStockForProduct(productId) {
    const product = await Product.findById(productId)
      .select('name sku totalStock hasVariants variants')
      .lean();
    if (!product) throw new AppError('Product not found.', 404);
    return product;
  },
};

module.exports = inventoryService;
