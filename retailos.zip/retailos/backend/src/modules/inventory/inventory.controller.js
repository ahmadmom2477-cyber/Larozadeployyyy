const inventoryService = require('./inventory.service');
const { asyncHandler, sendSuccess, sendPaginated } = require('../../utils/appError');

const inventoryController = {
  adjust: asyncHandler(async (req, res) => {
    const { productId, variantId, quantityChange, type, reason, unitCost } = req.body;
    const { product, log } = await inventoryService.adjust({
      productId, variantId, quantityChange, type, reason,
      performedBy: req.user._id,
      unitCost,
    });
    sendSuccess(res, { product, log }, 200, { message: 'Inventory adjusted successfully.' });
  }),

  getLogs: asyncHandler(async (req, res) => {
    const { logs, total, page, limit } = await inventoryService.getLogs(req.query);
    sendPaginated(res, logs, total, page, limit);
  }),

  getProductLogs: asyncHandler(async (req, res) => {
    const { logs, total, page, limit } = await inventoryService.getProductLogs(
      req.params.productId, req.query
    );
    sendPaginated(res, logs, total, page, limit);
  }),

  getLowStock: asyncHandler(async (req, res) => {
    const threshold = parseInt(req.query.threshold) || 10;
    const products  = await inventoryService.getLowStockProducts(threshold);
    sendSuccess(res, { products, count: products.length });
  }),

  getValuation: asyncHandler(async (req, res) => {
    const valuation = await inventoryService.getValuation();
    sendSuccess(res, { valuation });
  }),

  getProductStock: asyncHandler(async (req, res) => {
    const stock = await inventoryService.getStockForProduct(req.params.productId);
    sendSuccess(res, { stock });
  }),
};

module.exports = inventoryController;
