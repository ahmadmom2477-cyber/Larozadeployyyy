const router              = require('express').Router();
const inventoryController = require('./inventory.controller');
const { authenticate }    = require('../../middleware/authenticate');
const { authorize }       = require('../../middleware/authorize');

router.use(authenticate);

router.get('/logs',                                                  inventoryController.getLogs);
router.get('/logs/product/:productId',                               inventoryController.getProductLogs);
router.get('/low-stock',                                             inventoryController.getLowStock);
router.get('/stock/:productId',                                      inventoryController.getProductStock);
router.get('/valuation',      authorize('admin','manager'),          inventoryController.getValuation);
router.post('/adjust',        authorize('admin','manager'),          inventoryController.adjust);

module.exports = router;
