const Product  = require('../../models/product.model');
const Sale     = require('../../models/sale.model');
const { AppError } = require('../../utils/appError');

const cashierService = {
  async searchProducts(term) {
    if (!term || term.trim().length < 1) {
      throw new AppError('Search term required.', 400);
    }

    const trimmed = term.trim();

    // Try barcode first (exact match)
    const byBarcode = await Product.findOne({ barcode: trimmed, isActive: true })
      .select('name sku barcode sellingPrice costPrice taxRate totalStock unit images variants hasVariants')
      .lean();
    if (byBarcode) return [byBarcode];

    // Try SKU exact match
    const bySku = await Product.findOne({ sku: trimmed.toUpperCase(), isActive: true })
      .select('name sku barcode sellingPrice costPrice taxRate totalStock unit images variants hasVariants')
      .lean();
    if (bySku) return [bySku];

    // Full-text search
    const byText = await Product.find(
      { $text: { $search: trimmed }, isActive: true },
      { score: { $meta: 'textScore' } }
    )
      .select('name sku barcode sellingPrice costPrice taxRate totalStock unit images variants hasVariants')
      .sort({ score: { $meta: 'textScore' } })
      .limit(24)
      .lean();

    return byText;
  },

  async getMySales(cashierId) {
    const today      = new Date();
    const startOfDay = new Date(today.setHours(0, 0, 0, 0));

    return Sale.find({ cashierId, createdAt: { $gte: startOfDay } })
      .select('receiptNumber grandTotal status createdAt items')
      .sort({ createdAt: -1 })
      .limit(50)
      .lean();
  },

  async getShiftSummary(cashierId) {
    const today      = new Date();
    const startOfDay = new Date(today.setHours(0, 0, 0, 0));

    const [summary] = await Sale.aggregate([
      {
        $match: {
          cashierId,
          createdAt: { $gte: startOfDay },
          status: { $in: ['completed', 'partially_refunded'] },
        },
      },
      {
        $group: {
          _id:          null,
          totalSales:   { $sum: '$grandTotal' },
          transactions: { $sum: 1 },
          totalCash: {
            $sum: {
              $reduce: {
                input: '$payments', initialValue: 0,
                in: { $add: ['$$value', { $cond: [{ $eq: ['$$this.method', 'cash'] }, '$$this.amount', 0] }] },
              },
            },
          },
          totalCard: {
            $sum: {
              $reduce: {
                input: '$payments', initialValue: 0,
                in: { $add: ['$$value', { $cond: [{ $eq: ['$$this.method', 'card'] }, '$$this.amount', 0] }] },
              },
            },
          },
          totalMobile: {
            $sum: {
              $reduce: {
                input: '$payments', initialValue: 0,
                in: { $add: ['$$value', { $cond: [{ $eq: ['$$this.method', 'mobile_money'] }, '$$this.amount', 0] }] },
              },
            },
          },
          avgTransaction: { $avg: '$grandTotal' },
        },
      },
    ]);

    return summary || { totalSales: 0, transactions: 0, totalCash: 0, totalCard: 0, totalMobile: 0, avgTransaction: 0 };
  },
};

module.exports = cashierService;
