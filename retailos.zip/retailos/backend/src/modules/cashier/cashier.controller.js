const cashierService = require('./cashier.service');
const { asyncHandler, sendSuccess } = require('../../utils/appError');

const cashierController = {
  searchProducts: asyncHandler(async (req, res) => {
    const products = await cashierService.searchProducts(req.query.q);
    sendSuccess(res, { products, count: products.length });
  }),

  getMySales: asyncHandler(async (req, res) => {
    const sales = await cashierService.getMySales(req.user._id);
    sendSuccess(res, { sales });
  }),

  getShiftSummary: asyncHandler(async (req, res) => {
    const summary = await cashierService.getShiftSummary(req.user._id);
    sendSuccess(res, { summary });
  }),
};

module.exports = cashierController;
