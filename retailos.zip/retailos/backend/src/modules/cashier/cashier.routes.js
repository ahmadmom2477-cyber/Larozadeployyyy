const router            = require('express').Router();
const cashierController = require('./cashier.controller');
const { authenticate }  = require('../../middleware/authenticate');

router.use(authenticate);

router.get('/products/search', cashierController.searchProducts);  // ?q=term
router.get('/my-sales',        cashierController.getMySales);
router.get('/shift-summary',   cashierController.getShiftSummary);

module.exports = router;
