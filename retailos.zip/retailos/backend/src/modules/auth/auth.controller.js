const { authService, setRefreshCookie } = require('./auth.service');
const { asyncHandler, sendSuccess }     = require('../../utils/appError');

const authController = {
  login: asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    const { user, accessToken, refreshToken } = await authService.login(email, password);
    setRefreshCookie(res, refreshToken);
    sendSuccess(res, { accessToken, user }, 200);
  }),

  refresh: asyncHandler(async (req, res) => {
    const token = req.cookies?.refreshToken;
    const { user, accessToken, refreshToken } = await authService.refreshTokens(token);
    setRefreshCookie(res, refreshToken);
    sendSuccess(res, { accessToken, user });
  }),

  logout: asyncHandler(async (req, res) => {
    await authService.logout(req.user._id);
    res.clearCookie('refreshToken');
    sendSuccess(res, null, 200, { message: 'Logged out successfully.' });
  }),

  me: asyncHandler(async (req, res) => {
    sendSuccess(res, { user: req.user });
  }),

  changePassword: asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    await authService.changePassword(req.user._id, currentPassword, newPassword);
    res.clearCookie('refreshToken');
    sendSuccess(res, null, 200, { message: 'Password updated. Please log in again.' });
  }),
};

module.exports = authController;
