const jwt    = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const User   = require('../../models/user.model');
const { AppError } = require('../../utils/appError');

const signAccessToken  = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '15m' });

const signRefreshToken = (id) =>
  jwt.sign({ id }, process.env.JWT_REFRESH_SECRET, { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' });

const setRefreshCookie = (res, token) => {
  res.cookie('refreshToken', token, {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge:   7 * 24 * 60 * 60 * 1000,
  });
};

const authService = {
  async login(email, password) {
    const user = await User.findOne({ email }).select('+passwordHash +refreshTokenHash');
    if (!user || !(await user.comparePassword(password))) {
      throw new AppError('Invalid email or password.', 401);
    }
    if (!user.isActive) throw new AppError('Your account has been deactivated.', 403);

    const accessToken  = signAccessToken(user._id);
    const refreshToken = signRefreshToken(user._id);

    user.refreshTokenHash = await bcrypt.hash(refreshToken, 10);
    user.lastLogin        = new Date();
    await user.save({ validateBeforeSave: false });

    return { user, accessToken, refreshToken };
  },

  async refreshTokens(incomingRefreshToken) {
    if (!incomingRefreshToken) throw new AppError('Refresh token required.', 401);

    let decoded;
    try {
      decoded = jwt.verify(incomingRefreshToken, process.env.JWT_REFRESH_SECRET);
    } catch {
      throw new AppError('Invalid or expired refresh token. Please log in again.', 401);
    }

    const user = await User.findById(decoded.id).select('+refreshTokenHash');
    if (!user) throw new AppError('User not found.', 401);

    const isValid = await bcrypt.compare(incomingRefreshToken, user.refreshTokenHash || '');
    if (!isValid) throw new AppError('Refresh token has been invalidated. Please log in again.', 401);

    const accessToken  = signAccessToken(user._id);
    const refreshToken = signRefreshToken(user._id);

    user.refreshTokenHash = await bcrypt.hash(refreshToken, 10);
    await user.save({ validateBeforeSave: false });

    return { user, accessToken, refreshToken };
  },

  async logout(userId) {
    await User.findByIdAndUpdate(userId, { refreshTokenHash: null }, { validateBeforeSave: false });
  },

  async changePassword(userId, currentPassword, newPassword) {
    const user = await User.findById(userId).select('+passwordHash');
    if (!user) throw new AppError('User not found.', 404);

    const match = await user.comparePassword(currentPassword);
    if (!match) throw new AppError('Current password is incorrect.', 401);

    user.passwordHash = newPassword;
    await user.save();
  },
};

module.exports = { authService, setRefreshCookie };
