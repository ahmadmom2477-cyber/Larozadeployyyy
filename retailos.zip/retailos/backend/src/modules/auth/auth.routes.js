const router         = require('express').Router();
const authController = require('./auth.controller');
const { authenticate } = require('../../middleware/authenticate');
const validate         = require('../../middleware/validate');
const { loginSchema, changePasswordSchema } = require('./auth.validation');

// Public
router.post('/login',   validate(loginSchema), authController.login);
router.post('/refresh',                        authController.refresh);

// Protected
router.use(authenticate);
router.post('/logout',          authController.logout);
router.get('/me',               authController.me);
router.patch('/change-password', validate(changePasswordSchema), authController.changePassword);

module.exports = router;
