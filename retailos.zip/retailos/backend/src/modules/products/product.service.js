const Product      = require('../../models/product.model');
const InventoryLog = require('../../models/inventoryLog.model');
const { AppError } = require('../../utils/appError');
const { getPagination, getSort } = require('../../utils/queryHelpers');

const productService = {
  async list(query) {
    const { page, limit, skip } = getPagination(query);
    const sort   = getSort(query);
    const filter = {};

    if (query.search)     filter.$text     = { $search: query.search };
    if (query.categoryId) filter.categoryId = query.categoryId;
    if (query.isActive !== undefined) filter.isActive = query.isActive;
    if (query.lowStock)   filter.totalStock = { $lte: 10 };

    const [products, total] = await Promise.all([
      Product.find(filter)
        .populate('categoryId', 'name')
        .populate('supplierId', 'name')
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .lean(),
      Product.countDocuments(filter),
    ]);

    return { products, total, page, limit };
  },

  async findById(id) {
    const product = await Product.findById(id)
      .populate('categoryId', 'name')
      .populate('supplierId', 'name');
    if (!product) throw new AppError('Product not found.', 404);
    return product;
  },

  async findBySku(sku) {
    const product = await Product.findOne({ sku: sku.toUpperCase() })
      .populate('categoryId', 'name');
    if (!product) throw new AppError('Product not found.', 404);
    return product;
  },

  async findByBarcode(barcode) {
    const product = await Product.findOne({ barcode, isActive: true })
      .populate('categoryId', 'name');
    if (!product) throw new AppError('Product not found for barcode.', 404);
    return product;
  },

  async create(data, userId) {
    const product = await Product.create(data);
    if (data.totalStock > 0) {
      await InventoryLog.create({
        productId:      product._id,
        productName:    product.name,
        sku:            product.sku,
        type:           'opening_stock',
        quantityBefore: 0,
        quantityChange: data.totalStock,
        quantityAfter:  data.totalStock,
        reason:         'Initial stock on product creation',
        performedBy:    userId,
        unitCost:       product.costPrice,
      });
    }
    return product;
  },

  async update(id, data) {
    const product = await Product.findByIdAndUpdate(
      id,
      { $set: data },
      { new: true, runValidators: true }
    );
    if (!product) throw new AppError('Product not found.', 404);
    return product;
  },

  async delete(id) {
    const product = await Product.findByIdAndUpdate(
      id,
      { isActive: false },
      { new: true }
    );
    if (!product) throw new AppError('Product not found.', 404);
    return product;
  },

  async getLowStock(threshold = 10) {
    return Product.find({ totalStock: { $lte: threshold }, isActive: true })
      .select('name sku totalStock reorderPoint costPrice sellingPrice categoryId')
      .populate('categoryId', 'name')
      .sort({ totalStock: 1 })
      .lean();
  },
};

module.exports = productService;
