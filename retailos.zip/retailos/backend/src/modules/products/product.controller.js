const productService = require('./product.service');
const { asyncHandler, sendSuccess, sendPaginated } = require('../../utils/appError');

const productController = {
  list: asyncHandler(async (req, res) => {
    const { products, total, page, limit } = await productService.list(req.query);
    sendPaginated(res, products, total, page, limit);
  }),

  findById: asyncHandler(async (req, res) => {
    const product = await productService.findById(req.params.id);
    sendSuccess(res, { product });
  }),

  findBySku: asyncHandler(async (req, res) => {
    const product = await productService.findBySku(req.params.sku);
    sendSuccess(res, { product });
  }),

  findByBarcode: asyncHandler(async (req, res) => {
    const product = await productService.findByBarcode(req.params.barcode);
    sendSuccess(res, { product });
  }),

  create: asyncHandler(async (req, res) => {
    const product = await productService.create(req.body, req.user._id);
    sendSuccess(res, { product }, 201);
  }),

  update: asyncHandler(async (req, res) => {
    const product = await productService.update(req.params.id, req.body);
    sendSuccess(res, { product });
  }),

  delete: asyncHandler(async (req, res) => {
    await productService.delete(req.params.id);
    sendSuccess(res, null, 200, { message: 'Product deactivated successfully.' });
  }),

  getLowStock: asyncHandler(async (req, res) => {
    const threshold = parseInt(req.query.threshold) || 10;
    const products  = await productService.getLowStock(threshold);
    sendSuccess(res, { products, count: products.length });
  }),
};

module.exports = productController;
