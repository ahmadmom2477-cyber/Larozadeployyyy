const router            = require('express').Router();
const productController = require('./product.controller');
const { authenticate }  = require('../../middleware/authenticate');
const { authorize }     = require('../../middleware/authorize');
const validate          = require('../../middleware/validate');
const { createProductSchema, updateProductSchema, listQuerySchema } = require('./product.validation');

router.use(authenticate);

router.get('/',                validate(listQuerySchema, 'query'), productController.list);
router.get('/low-stock',       productController.getLowStock);
router.get('/sku/:sku',        productController.findBySku);
router.get('/barcode/:barcode',productController.findByBarcode);
router.get('/:id',             productController.findById);
router.post('/',               authorize('admin','manager'), validate(createProductSchema), productController.create);
router.put('/:id',             authorize('admin','manager'), validate(updateProductSchema), productController.update);
router.delete('/:id',          authorize('admin'),           productController.delete);

module.exports = router;
