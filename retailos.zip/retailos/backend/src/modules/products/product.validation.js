const Joi = require('joi');

const variantSchema = Joi.object({
  sku:          Joi.string().trim().uppercase().required(),
  attributes:   Joi.object().pattern(Joi.string(), Joi.string()).default({}),
  costPrice:    Joi.number().min(0).required(),
  sellingPrice: Joi.number().min(0).required(),
  barcode:      Joi.string().allow(null, '').default(null),
  imageUrl:     Joi.string().uri().allow(null, '').default(null),
  isActive:     Joi.boolean().default(true),
});

const createProductSchema = Joi.object({
  name:         Joi.string().trim().min(2).max(200).required(),
  description:  Joi.string().trim().max(2000).allow('').default(''),
  sku:          Joi.string().trim().uppercase().required(),
  barcode:      Joi.string().allow(null, '').default(null),
  categoryId:   Joi.string().hex().length(24).required(),
  supplierId:   Joi.string().hex().length(24).allow(null).default(null),
  unit:         Joi.string().valid('piece','kg','gram','liter','ml','box','pack','dozen','meter','other').default('piece'),
  costPrice:    Joi.number().min(0).required(),
  sellingPrice: Joi.number().min(0).required(),
  taxRate:      Joi.number().min(0).max(100).default(0),
  images:       Joi.array().items(Joi.string().uri()).default([]),
  hasVariants:  Joi.boolean().default(false),
  variants:     Joi.array().items(variantSchema).default([]),
  tags:         Joi.array().items(Joi.string()).default([]),
  isActive:     Joi.boolean().default(true),
  totalStock:   Joi.number().integer().min(0).default(0),
  reorderPoint: Joi.number().integer().min(0).default(10),
});

const updateProductSchema = createProductSchema.fork(
  ['name', 'sku', 'categoryId', 'costPrice', 'sellingPrice'],
  (field) => field.optional()
);

const listQuerySchema = Joi.object({
  page:        Joi.number().integer().min(1).default(1),
  limit:       Joi.number().integer().min(1).max(100).default(20),
  search:      Joi.string().trim().allow('').optional(),
  categoryId:  Joi.string().hex().length(24).optional(),
  isActive:    Joi.boolean().optional(),
  sort:        Joi.string().optional(),
  lowStock:    Joi.boolean().optional(),
});

module.exports = { createProductSchema, updateProductSchema, listQuerySchema };
