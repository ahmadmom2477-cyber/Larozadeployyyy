const userService = require('./user.service');
const { asyncHandler, sendSuccess, sendPaginated } = require('../../utils/appError');

const userController = {
  list: asyncHandler(async (req, res) => {
    const { users, total, page, limit } = await userService.list(req.query);
    sendPaginated(res, users, total, page, limit);
  }),

  findById: asyncHandler(async (req, res) => {
    const user = await userService.findById(req.params.id);
    sendSuccess(res, { user });
  }),

  create: asyncHandler(async (req, res) => {
    const user = await userService.create(req.body);
    sendSuccess(res, { user }, 201);
  }),

  update: asyncHandler(async (req, res) => {
    const user = await userService.update(req.params.id, req.body);
    sendSuccess(res, { user });
  }),

  resetPassword: asyncHandler(async (req, res) => {
    await userService.resetPassword(req.params.id, req.body.newPassword, req.user._id);
    sendSuccess(res, null, 200, { message: 'Password reset successfully.' });
  }),

  deactivate: asyncHandler(async (req, res) => {
    const user = await userService.deactivate(req.params.id);
    sendSuccess(res, { user }, 200, { message: 'User deactivated.' });
  }),
};

module.exports = userController;
