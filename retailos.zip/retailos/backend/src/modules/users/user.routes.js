const router         = require('express').Router();
const userController = require('./user.controller');
const { authenticate }   = require('../../middleware/authenticate');
const { authorize, authorizeSelf } = require('../../middleware/authorize');
const validate           = require('../../middleware/validate');
const Joi                = require('joi');

const createUserSchema = Joi.object({
  name:     Joi.string().trim().min(2).max(100).required(),
  email:    Joi.string().email().required(),
  password: Joi.string().min(8).required()
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .message('Password must contain uppercase, lowercase, and a number.'),
  role:     Joi.string().valid('admin','manager','cashier').default('cashier'),
  isActive: Joi.boolean().default(true),
});

const updateUserSchema = Joi.object({
  name:     Joi.string().trim().min(2).max(100).optional(),
  role:     Joi.string().valid('admin','manager','cashier').optional(),
  isActive: Joi.boolean().optional(),
});

const resetPasswordSchema = Joi.object({
  newPassword: Joi.string().min(8).required()
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .message('Password must contain uppercase, lowercase, and a number.'),
});

router.use(authenticate);

router.get('/',    authorize('admin','manager'),      userController.list);
router.get('/:id', authorize('admin','manager'),      userController.findById);
router.post('/',   authorize('admin'),  validate(createUserSchema),    userController.create);
router.put('/:id', authorize('admin'),  validate(updateUserSchema),    userController.update);
router.patch('/:id/reset-password', authorize('admin'), validate(resetPasswordSchema), userController.resetPassword);
router.patch('/:id/deactivate',     authorize('admin'), userController.deactivate);

module.exports = router;
