const User     = require('../../models/user.model');
const { AppError } = require('../../utils/appError');
const { getPagination, getSort } = require('../../utils/queryHelpers');

const userService = {
  async list(query) {
    const { page, limit, skip } = getPagination(query);
    const sort   = getSort(query, { createdAt: -1 });
    const filter = {};

    if (query.role)     filter.role     = query.role;
    if (query.isActive !== undefined) filter.isActive = query.isActive === 'true' || query.isActive === true;

    const [users, total] = await Promise.all([
      User.find(filter).sort(sort).skip(skip).limit(limit).lean(),
      User.countDocuments(filter),
    ]);

    return { users, total, page, limit };
  },

  async findById(id) {
    const user = await User.findById(id);
    if (!user) throw new AppError('User not found.', 404);
    return user;
  },

  async create(data) {
    const existing = await User.findOne({ email: data.email });
    if (existing) throw new AppError('Email already in use.', 409);

    const user = await User.create({
      name:         data.name,
      email:        data.email,
      passwordHash: data.password,
      role:         data.role || 'cashier',
      isActive:     data.isActive !== undefined ? data.isActive : true,
    });
    return user;
  },

  async update(id, data) {
    const allowed = ['name', 'role', 'isActive'];
    const update  = {};
    allowed.forEach(k => { if (data[k] !== undefined) update[k] = data[k]; });

    const user = await User.findByIdAndUpdate(id, { $set: update }, { new: true, runValidators: true });
    if (!user) throw new AppError('User not found.', 404);
    return user;
  },

  async resetPassword(id, newPassword, adminId) {
    const user = await User.findById(id).select('+passwordHash');
    if (!user) throw new AppError('User not found.', 404);
    user.passwordHash = newPassword;
    await user.save();
    return user;
  },

  async deactivate(id) {
    const user = await User.findByIdAndUpdate(id, { isActive: false }, { new: true });
    if (!user) throw new AppError('User not found.', 404);
    return user;
  },
};

module.exports = userService;
